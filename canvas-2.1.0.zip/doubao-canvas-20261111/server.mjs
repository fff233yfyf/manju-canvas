import http from 'node:http';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {
  ROOT,
  DATA_DIR,
  ASSET_DIR,
  UPLOAD_DIR,
  MOCK_DIR,
  WEB_DIR,
  PROJECT_DIR,
  CONFIG_FILE,
  EXAMPLE_CONFIG,
} from './lib/paths.mjs';
import { loadConfig } from './lib/config.mjs';
import { QuotaStore } from './lib/quota.mjs';
import { BridgePool } from './lib/bridge.mjs';
import { extFromType, sizeFromRatio } from './lib/media.mjs';
import { JobQueue } from './lib/jobs.mjs';
import { initFileLogging, LOG_DIR } from './lib/log.mjs';
import { buildDiagnostics, cleanupDiagnostics } from './lib/diagnostics.mjs';
import { readVideoStats } from './lib/stats.mjs';
import { buildEpisodeZip, cleanupEpisode } from './lib/episode.mjs';
import { loadPolicy, isActivated, activate, machineCode, trustedNow, RECORD_FILE, trialState } from './lib/license.mjs';

const PORT = Number(process.env.PORT || 8787);
const HOST = process.env.HOST || '127.0.0.1';

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
  '.mp4': 'video/mp4',
  '.webm': 'video/webm',
  '.mov': 'video/quicktime',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
  '.md': 'text/markdown; charset=utf-8',
};
const mimeOf = (file) => MIME[path.extname(file).toLowerCase()] || 'application/octet-stream';

/* ───────────────────────────── 启动 ───────────────────────────── */
await fsp.mkdir(DATA_DIR, { recursive: true });
await fsp.mkdir(PROJECT_DIR, { recursive: true });
await fsp.mkdir(ASSET_DIR, { recursive: true });
await fsp.mkdir(UPLOAD_DIR, { recursive: true });
await fsp.mkdir(MOCK_DIR, { recursive: true });

// 日志落盘：客户出问题时让他把 logs 发过来就能定位
await initFileLogging().catch(() => {});

if (!fs.existsSync(CONFIG_FILE)) {
  try {
    await fsp.copyFile(EXAMPLE_CONFIG, CONFIG_FILE);
    console.log(`[config] 已从示例创建 ${CONFIG_FILE}`);
  } catch {
    /* 忽略 */
  }
}

const STYLE_FILE = path.join(DATA_DIR, 'style-presets.json');
const PKG = JSON.parse(await fsp.readFile(path.join(ROOT, 'package.json'), 'utf8'));
const VERSION = PKG.version || '0.0.0';
const BUILD_DATE = PKG.buildDate || '';
// 默认更新地址：客户 config.json 里没填时用它（老客户的配置是旧模板，字段是空的）
const DEFAULT_UPDATE_URLS = [
  'https://raw.githubusercontent.com/fff233yfyf/manju-canvas/main/update.json',
];

/** 把配置里的地址和默认地址合成一个有序列表 */
function updateUrlList() {
  const cfg = config.update || {};
  const arr = Array.isArray(cfg.urls) ? cfg.urls : [];
  const one = String(cfg.url || '').trim();
  const list = [...arr.map((x) => String(x || '').trim()), one].filter(Boolean);
  return list.length ? [...new Set(list)] : DEFAULT_UPDATE_URLS;
}

/** 依次尝试所有更新地址，返回第一个能读到的 JSON */
async function fetchUpdateInfo() {
  const urls = updateUrlList();
  let lastErr = null;
  for (const u of urls) {
    try {
      const bust = u + (u.includes('?') ? '&' : '?') + 't=' + Date.now();
      const r = await fetch(bust, { signal: AbortSignal.timeout(8000) });
      if (!r.ok) {
        lastErr = new Error('HTTP ' + r.status);
        continue;
      }
      return await r.json();
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr || new Error('没有可用的更新地址');
}
let config = await loadConfig(CONFIG_FILE);
const quota = new QuotaStore(path.join(DATA_DIR, 'quota.json'));
await quota.load();
const bridges = new BridgePool(config, quota);
await bridges.warm?.();
const jobs = new JobQueue({ config, bridges, quota });

for (const w of config.warnings) console.warn(`[config] ${w}`);

/* ───────────────────────────── 工具 ───────────────────────────── */
const json = (res, code, obj) => {
  const body = JSON.stringify(obj);
  res.writeHead(code, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Content-Length': Buffer.byteLength(body),
  });
  res.end(body);
};
const fail = (res, code, message) => json(res, code, { ok: false, error: message });

async function readBody(req, limit = 32 * 1024 * 1024) {
  const chunks = [];
  let size = 0;
  for await (const c of req) {
    size += c.length;
    if (size > limit) throw Object.assign(new Error('请求体过大'), { status: 413 });
    chunks.push(c);
  }
  return Buffer.concat(chunks);
}

async function readJson(req, limit) {
  const buf = await readBody(req, limit);
  if (!buf.length) return {};
  return JSON.parse(buf.toString('utf8'));
}

/** 支持 Range 的静态文件响应（视频拖进度条必需） */
async function sendFile(req, res, file, { cache = false } = {}) {
  let stat;
  try {
    stat = await fsp.stat(file);
  } catch {
    return fail(res, 404, '文件不存在');
  }
  if (!stat.isFile()) return fail(res, 404, '不是文件');

  const type = mimeOf(file);
  const range = req.headers.range;
  const headers = {
    'Content-Type': type,
    'Accept-Ranges': 'bytes',
    'Cache-Control': cache ? 'public, max-age=31536000, immutable' : 'no-cache',
  };

  if (range) {
    const m = /^bytes=(\d*)-(\d*)$/.exec(range);
    if (m) {
      let start = m[1] ? Number(m[1]) : 0;
      let end = m[2] ? Number(m[2]) : stat.size - 1;
      if (Number.isNaN(start) || Number.isNaN(end) || start > end || start >= stat.size) {
        res.writeHead(416, { 'Content-Range': `bytes */${stat.size}` });
        return res.end();
      }
      end = Math.min(end, stat.size - 1);
      headers['Content-Range'] = `bytes ${start}-${end}/${stat.size}`;
      headers['Content-Length'] = end - start + 1;
      res.writeHead(206, headers);
      return fs.createReadStream(file, { start, end }).pipe(res);
    }
  }

  headers['Content-Length'] = stat.size;
  res.writeHead(200, headers);
  if (req.method === 'HEAD') return res.end();
  fs.createReadStream(file).pipe(res);
}

function safeJoin(root, rel) {
  const target = path.resolve(root, '.' + path.sep + rel.replace(/^[/\\]+/, ''));
  const rootWithSep = root.endsWith(path.sep) ? root : root + path.sep;
  if (target !== root && !target.startsWith(rootWithSep)) return null;
  return target;
}

const PROJ_ID = /^[A-Za-z0-9_-]{1,64}$/;

/* ───────────────────────────── 业务 ───────────────────────────── */
function capabilities() {
  const kinds = new Set();
  for (const b of bridges.list) for (const k of b.kinds || []) kinds.add(k);
  if (!kinds.size) {
    // 配置里没写 kinds 时，按桥自报的能力算
    for (const s of bridges.status().endpoints) for (const k of s.kinds || []) kinds.add(k);
  }
  return { image: kinds.has('image'), video: kinds.has('video') || kinds.size === 0 };
}

async function publicState() {
  return {
    ok: true,
    version: VERSION,
    buildDate: BUILD_DATE,
    root: ROOT,
    configFile: CONFIG_FILE,
    defaults: config.defaults,
    provider: {
      mode: config.provider?.mode || 'bridge',
      ...bridges.status(),
    },
    capabilities: capabilities(),
    jobs: jobs.stats(),
    stats: await readVideoStats().catch(() => ({ today: 0, total: 0 })),
    quota: { date: quota.data.date },
  };
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const { pathname } = url;
  const method = req.method || 'GET';

  try {
    if (pathname === '/api/license' && method === 'GET') {
      const policy = await loadPolicy();
      const clock = policy.mode === 'machine' ? await trustedNow() : { tampered: false };
      const body = {
        ok: true,
        enabled: policy.enabled,
        mode: policy.mode,
        activated: await isActivated(policy),
        tampered: !!clock.tampered,
      };
      if (policy.mode === 'machine') {
          body.machineCode = await machineCode();
          // 卡密里的到期时间（exp 是毫秒时间戳，0 = 永久）
          try {
            const rec = JSON.parse(await fsp.readFile(RECORD_FILE, 'utf8'));
            const raw = String(rec?.token || '').split('.')[0];
            const payload = JSON.parse(Buffer.from(raw, 'base64url').toString('utf8'));
            body.name = payload.n || '';
            body.issuedAt = Number(payload.iat) || 0;
            body.expiresAt = Number(payload.exp) || 0;
            body.daysLeft = payload.exp ? Math.ceil((payload.exp - Date.now()) / 86400000) : 0;
          } catch {
            /* 没激活或记录读不出来 */
          }
        }
        body.trial = await trialState().catch(() => null);
        // 有没有真正的卡密记录（试用不算卡）
        try {
          const rec = JSON.parse(await fsp.readFile(RECORD_FILE, 'utf8'));
          body.hasCard = !!(rec && (rec.token || rec.hash));
        } catch {
          body.hasCard = false;
        }
          // 有卡、不是永久、且已过期 → 让前端明确提示「哪天到期」
          body.expired = !!(body.hasCard && body.expiresAt && Number(body.expiresAt) < Date.now());
          body.expiredAt = body.expired ? Number(body.expiresAt) : 0;
        return json(res, 200, body);
    }

    if (pathname === '/api/license/activate' && method === 'POST') {
      const body = await readJson(req);
      const policy = await loadPolicy();
      const r = await activate(policy, body.key);
      if (!r.ok) {
        // 记进日志：客户导出诊断包时就能看到到底哪一步没过
          const mc = policy.mode === 'machine' ? await machineCode().catch(() => '?') : '-';
          console.log(
            `[授权] 激活失败：${r.error || '未知原因'}｜模式=${policy.mode}｜机器码=${mc}｜系统时间=${new Date().toLocaleString('zh-CN')}｜卡密长度=${String(body.key || '').trim().length}`,
          );
          // 错一次等 800ms，挡住最笨的暴力破解
        await new Promise((s) => setTimeout(s, 800));
        return fail(res, 403, r.error || '卡密不正确');
      }
      console.log(`[授权] 激活成功：${r.name || '(无名)'}｜模式=${policy.mode}`);
      return json(res, 200, { ok: true });
    }

    if (pathname === '/api/health') {
      await bridges.healthAll();
      const st = bridges.status();
      const online = st.endpoints.filter((e) => e.online && e.loggedIn).length;
      return json(res, 200, { ok: true, bridges: st.endpoints.length, online });
    }

    // 导出诊断包：日志 + 脱敏配置 + 健康状态，打包成 zip 给作者
    if (pathname === '/api/diagnostics.zip' && method === 'GET') {
      try {
        await bridges.healthAll({ fresh: true });
        const policy = await loadPolicy().catch(() => null);
        const zipPath = await buildDiagnostics({
          version: VERSION,
          buildDate: BUILD_DATE,
          config,
          plan: { mode: policy?.mode || '', activated: await isActivated(policy).catch(() => false) },
          quota: { date: quota.data.date, endpoints: bridges.status().endpoints },
          bridges: bridges.status(),
          jobs: jobs.list().slice(0, 30),
        });
        const buf = await fsp.readFile(zipPath);
        res.writeHead(200, {
          'content-type': 'application/zip',
          'content-disposition': `attachment; filename="diagnostics-${Date.now()}.zip"`,
          'content-length': buf.length,
          'cache-control': 'no-store',
        });
        res.end(buf);
        setTimeout(() => cleanupDiagnostics().catch(() => {}), 3000);
        return;
      } catch (e) {
        return fail(res, 500, '打包诊断信息失败：' + e.message);
      }
    }

    // 版本号 + 可选检查更新（update.url 指向一个 {version,url,notes} 的 JSON）
    // 全局画风预设（用户自己加的，跨画布复用）
    if (pathname === '/api/styles' && method === 'GET') {
      const list = JSON.parse(await fsp.readFile(STYLE_FILE, 'utf8').catch(() => '[]'));
      return json(res, 200, { ok: true, items: Array.isArray(list) ? list : [] });
    }

    if (pathname === '/api/styles' && method === 'POST') {
      const body = await readJson(req).catch(() => ({}));
      const name = String(body.name || '').trim().slice(0, 20);
      const text = String(body.text || '').trim().slice(0, 300);
      if (!name || !text) return fail(res, 400, '名字和画风都要填');
      const raw = await fsp.readFile(STYLE_FILE, 'utf8').catch(() => '[]');
      const list = JSON.parse(raw).filter((x) => x && x.name !== name);
      list.unshift({ name, text, at: Date.now() });
      await fsp.mkdir(DATA_DIR, { recursive: true });
      await fsp.writeFile(STYLE_FILE, JSON.stringify(list.slice(0, 30), null, 2) + '\n', 'utf8');
      return json(res, 200, { ok: true, items: list.slice(0, 30) });
    }

    if (pathname === '/api/styles/delete' && method === 'POST') {
      const body = await readJson(req).catch(() => ({}));
      const name = String(body.name || '').trim();
      const raw = await fsp.readFile(STYLE_FILE, 'utf8').catch(() => '[]');
      const list = JSON.parse(raw).filter((x) => x && x.name !== name);
      await fsp.writeFile(STYLE_FILE, JSON.stringify(list, null, 2) + '\n', 'utf8').catch(() => {});
      return json(res, 200, { ok: true, items: list });
    }

    // 购买卡密：套餐、收款码、机器码
    if (pathname === '/api/shop' && method === 'GET') {
      const shop = config.shop || {};
      const items = Array.isArray(shop.items) ? shop.items : [];
      const policy = await loadPolicy();
      // 支付通道：老配置只有 qrImage 的话，当成支付宝一条
      let channels = Array.isArray(shop.channels) && shop.channels.length
        ? shop.channels
        : [{ id: 'alipay', label: '支付宝', qrImage: shop.qrImage || '' }];
      channels = channels.map((c) => ({
        id: String(c.id || 'alipay'),
        label: String(c.label || c.id || '支付宝'),
        hasQr: !!(c.qrImage && fs.existsSync(path.join(ROOT, String(c.qrImage)))),
      }));
      return json(res, 200, {
        ok: true,
        enabled: shop.enabled !== false && items.length > 0,
        items,
        channels,
        contact: shop.contact || '',
        payNote: shop.payNote || '',
        uniqueAmount: shop.uniqueAmount !== false,
        hasQr: channels.some((c) => c.hasQr),
        machineCode: policy.mode === 'machine' ? await machineCode() : '',
        trial: await trialState().catch(() => null),
      });
    }

    // 收款码图片
    if (pathname === '/api/shop/qr' && method === 'GET') {
      const want = String(new URL(req.url, 'http://x').searchParams.get('channel') || '');
      const shop = config.shop || {};
      const list = Array.isArray(shop.channels) && shop.channels.length
        ? shop.channels
        : [{ id: 'alipay', qrImage: shop.qrImage || '' }];
      const hit = want ? list.find((c) => String(c.id) === want) : list[0];
      const rel = String(hit?.qrImage || '');
      const target = rel ? path.join(ROOT, rel) : '';
      if (!target || !fs.existsSync(target)) return fail(res, 404, '还没有放收款码图片');
      return sendFile(req, res, target);
    }

    if (pathname === '/api/version' && method === 'GET') {
      const wantCheck = url.searchParams.get('check') === '1';
      const out = { ok: true, version: VERSION };
      if (wantCheck) {
        try {
          const remote = await fetchUpdateInfo();
          const latest = String(remote.version || '').trim();
          const cmp = (a, b) => {
            const pa = String(a).split('.').map(Number);
            const pb = String(b).split('.').map(Number);
            for (let i = 0; i < 3; i++) {
              if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0) ? 1 : -1;
            }
            return 0;
          };
          out.latest = latest;
          out.outdated = !!latest && cmp(latest, VERSION) > 0;
          out.downloadUrl = String(remote.url || '');
          out.notes = String(remote.notes || '').slice(0, 300);
        } catch (e) {
          out.checkError = e.message;
        }
      }
      return json(res, 200, out);
    }

    // 一键更新：下载新包 → 覆盖程序文件（保留配置/数据/登录态）
    if (pathname === '/api/update/apply' && method === 'POST') {
      try {
        const remote = await fetchUpdateInfo();
        const zipUrl = String(remote.url || '');
        if (!zipUrl) return fail(res, 400, '更新信息里没有下载地址');

        const tmpDir = path.join(ROOT, 'data', '_update');
        await fsp.rm(tmpDir, { recursive: true, force: true });
        await fsp.mkdir(tmpDir, { recursive: true });
        const zipPath = path.join(tmpDir, 'pkg.zip');
        const bin = Buffer.from(await (await fetch(zipUrl, { signal: AbortSignal.timeout(180000) })).arrayBuffer());
        await fsp.writeFile(zipPath, bin);

        const outDir = path.join(tmpDir, 'new');
        await fsp.mkdir(outDir, { recursive: true });
        const ps = "Expand-Archive -LiteralPath '" + zipPath + "' -DestinationPath '" + outDir + "' -Force";
        const { spawnSync } = await import('node:child_process');
        const rr = spawnSync('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', ps], { encoding: 'utf8' });
        if (rr.status !== 0) return fail(res, 500, '解压失败：' + String(rr.stderr || '').slice(0, 200));

        let src = outDir;
        const tops = (await fsp.readdir(outDir)).filter((x) => !x.startsWith('__'));
        if (tops.length === 1) {
          const maybe = path.join(outDir, tops[0]);
          if ((await fsp.stat(maybe)).isDirectory()) src = maybe;
        }

        const SKIP = new Set(['config', 'data', 'assets', 'logs', 'node_modules']);
        let copied = 0;
        const walk = async (dir, base) => {
          for (const e of await fsp.readdir(dir, { withFileTypes: true })) {
            const rel = base ? path.join(base, e.name) : e.name;
            if (SKIP.has(rel.split(path.sep)[0])) continue;
            if (e.name.startsWith('.profile')) continue;
            const from = path.join(dir, e.name);
            const to = path.join(ROOT, rel);
            if (e.isDirectory()) {
              await fsp.mkdir(to, { recursive: true });
              await walk(from, rel);
            } else {
              await fsp.mkdir(path.dirname(to), { recursive: true });
              await fsp.copyFile(from, to);
              copied++;
            }
          }
        };
        await walk(src, '');

        await fsp.rm(tmpDir, { recursive: true, force: true }).catch(() => {});
        return json(res, 200, { ok: true, copied, version: String(remote.version || ''), needRestart: true });
      } catch (e) {
        return fail(res, 500, '更新失败：' + e.message);
      }
    }


    if (pathname === '/api/state' && method === 'GET') {
      bridges.healthAll().catch(() => {});
      return json(res, 200, await publicState());
    }

    if (pathname === '/api/quota' && method === 'GET') {
      // 默认用 5 秒缓存：前端会轮询这个接口，每次都强刷 15 个桥太浪费。
      // 只有点「重新检测」时才带 ?fresh=1。
      const fresh = url.searchParams.get('fresh') === '1';
      await bridges.healthAll({ fresh });
      return json(res, 200, { ok: true, ...bridges.status(), date: quota.data.date });
    }

    if (pathname === '/api/bridges' && method === 'GET') {
      await bridges.healthAll({ fresh: true });
      return json(res, 200, { ok: true, ...bridges.status() });
    }

    // 手动恢复被停用的账号（自动停用记录 + 配置里的 enabled:false）
    if (pathname.startsWith('/api/bridges/') && pathname.endsWith('/enable') && method === 'POST') {
      const id = decodeURIComponent(pathname.slice('/api/bridges/'.length, -'/enable'.length));
      const b = bridges.get(id);
      if (!b) return fail(res, 404, `没有 id 为 ${id} 的桥`);
      await bridges.enableAccount?.(b);
      if (b.enabled === false) {
        b.enabled = true;
        delete b.disabledReason;
        try {
          const cfg = JSON.parse(await fsp.readFile(CONFIG_FILE, 'utf8'));
          const row = (cfg.provider?.bridges || []).find((x) => x.id === id);
          if (row) {
            row.enabled = true;
            delete row.disabledReason;
            await fsp.writeFile(CONFIG_FILE, JSON.stringify(cfg, null, 2) + '\n', 'utf8');
          }
        } catch {
          /* 配置写不进去也不影响本次运行 */
        }
      }
      try {
        const r = await fetch(`${b.url}/enable`, { method: 'POST', signal: AbortSignal.timeout(8000) }).then((x) => x.json());
        bridges.healthCache.delete(id);
        return json(res, 200, { ok: true, ...r });
      } catch (e) {
        return fail(res, 502, e.message);
      }
    }

    if (pathname.startsWith('/api/bridges/') && pathname.endsWith('/challenge-done') && method === 'POST') {
      const id = decodeURIComponent(pathname.slice('/api/bridges/'.length, -'/challenge-done'.length));
      const b = bridges.get(id);
      if (!b) return fail(res, 404, `没有 id 为 ${id} 的桥`);
      try {
        const r = await bridges.challengeDone(b);
        return json(res, 200, { ok: true, ...r });
      } catch (e) {
        return fail(res, 502, e.message);
      }
    }

    if (pathname.startsWith('/api/bridges/') && pathname.endsWith('/login') && method === 'POST') {
      const id = decodeURIComponent(pathname.slice('/api/bridges/'.length, -'/login'.length));
      const b = bridges.get(id);
      if (!b) return fail(res, 404, `没有 id 为 ${id} 的桥`);
      try {
        const r = await bridges.login(b);
        return json(res, 200, { ok: true, ...r });
      } catch (e) {
        return fail(
          res,
          502,
          `连不上桥 ${id}（${b.url}）—— 先在终端里跑 node bridge/run-pool.mjs，别关那个窗口`
        );
      }
    }

    if (pathname.startsWith('/api/bridges/') && pathname.endsWith('/login-status') && method === 'GET') {
      const id = decodeURIComponent(pathname.slice('/api/bridges/'.length, -'/login-status'.length));
      const b = bridges.get(id);
      if (!b) return fail(res, 404, `没有 id 为 ${id} 的桥`);
      try {
        const r = await bridges.loginStatus(b);
        return json(res, 200, { ok: true, ...r });
      } catch (e) {
        return fail(res, 502, `连不上桥 ${id}（${b.url}）—— 桥进程没在跑`);
      }
    }

    if (pathname.startsWith('/api/bridges/') && pathname.endsWith('/close') && method === 'POST') {
      const id = decodeURIComponent(pathname.slice('/api/bridges/'.length, -'/close'.length));
      const b = bridges.get(id);
      if (!b) return fail(res, 404, `没有 id 为 ${id} 的桥`);
      try {
        const r = await fetch(`${String(b.url).replace(/\/+$/, '')}/close`, {
          method: 'POST',
          signal: AbortSignal.timeout(8000),
        });
        const j = await r.json().catch(() => ({}));
        return json(res, 200, { ok: true, ...j });
      } catch (e) {
        return fail(res, 502, `关不掉 ${id} 的浏览器：${e.message}`);
      }
    }

    if (pathname.startsWith('/api/bridges/') && pathname.endsWith('/window') && method === 'POST') {
      const id = decodeURIComponent(pathname.slice('/api/bridges/'.length, -'/window'.length));
      const b = bridges.get(id);
      if (!b) return fail(res, 404, `没有 id 为 ${id} 的桥`);
      const body = await readJson(req).catch(() => ({}));
      try {
        const r = await fetch(`${String(b.url).replace(/\/+$/, '')}/window`, {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ state: body.state === 'normal' ? 'normal' : 'minimized' }),
          signal: AbortSignal.timeout(8000),
        });
        const j = await r.json().catch(() => ({}));
        return json(res, 200, { ok: true, ...j });
      } catch (e) {
        return fail(res, 502, `调整 ${id} 的窗口失败：${e.message}`);
      }
    }

    if (pathname === '/api/config/reload' && method === 'POST') {
      config = await loadConfig(CONFIG_FILE);
      bridges.config = config;
      jobs.config = config;
      for (const w of config.warnings) console.warn(`[config] ${w}`);
      return json(res, 200, {
        ok: true,
        bridges: bridges.list.map((b) => ({ id: b.id, label: b.label, url: b.url })),
        warnings: config.warnings,
      });
    }

    if (pathname === '/api/generate' && method === 'POST') {
      // 没激活就别让它真的去消耗额度（前端那张门只是门帘，这里才是锁）
      const policy = await loadPolicy();
      if (policy.enabled && !(await isActivated(policy))) return fail(res, 403, '这个画布还没激活，请先输入卡密');
      const body = await readJson(req);
      const kind = body.kind === 'video' ? 'video' : 'image';
      const payload = { ...(body.payload || {}) };
      if (body.ratio && !payload.size) payload.size = sizeFromRatio(body.ratio);
      if (!payload.prompt || !String(payload.prompt).trim()) return fail(res, 400, 'prompt 不能为空');

      // 视频按秒计费额度；图片不计秒（前端会钳制 4~15，接口这里也兜一层）
      const rawSecs = Math.round(Number(payload.duration) || Number(config.defaults.videoDuration) || 5);
      const seconds = kind === 'video' ? Math.min(15, Math.max(4, rawSecs)) : 0;
      if (kind === 'video') payload.duration = seconds;

      const r = jobs.submit({
        kind,
        seconds,
        nodeId: body.nodeId || null,
        title: body.title || '',
        payload,
      });

      const caps = capabilities();
      return json(res, 200, { ok: true, ...r, seconds, capabilities: caps });
    }

    if (pathname === '/api/jobs' && method === 'GET') {
      const activeOnly = url.searchParams.get('active') === '1';
      const limit = Math.min(Number(url.searchParams.get('limit')) || 60, 200);
      return json(res, 200, { ok: true, jobs: jobs.list({ activeOnly, limit }), stats: jobs.stats() });
    }

    if (pathname.startsWith('/api/jobs/') && method === 'GET') {
      const id = pathname.slice('/api/jobs/'.length);
      const job = jobs.get(id);
      return job ? json(res, 200, { ok: true, job }) : fail(res, 404, '任务不存在');
    }

    if (pathname.startsWith('/api/jobs/') && pathname.endsWith('/cancel') && method === 'POST') {
      const id = pathname.slice('/api/jobs/'.length, -'/cancel'.length);
      return json(res, 200, { ok: jobs.cancel(id) });
    }

    if (pathname === '/api/upload' && method === 'POST') {
      const buf = await readBody(req, 40 * 1024 * 1024);
      if (!buf.length) return fail(res, 400, '空文件');
      const rawName = decodeURIComponent(String(req.headers['x-file-name'] || 'upload.bin'));
      const ext = path.extname(rawName).toLowerCase().replace(/^\./, '') || extFromType(req.headers['content-type'], 'png');
      const safeExt = /^[a-z0-9]{2,5}$/.test(ext) ? ext : 'png';
      const name = `u-${Date.now()}-${crypto.randomBytes(3).toString('hex')}.${safeExt}`;
      await fsp.writeFile(path.join(UPLOAD_DIR, name), buf);
      return json(res, 200, { ok: true, url: `/assets/uploads/${name}`, bytes: buf.length });
    }

    // 整集导出：镜头按画布顺序打包（清单 + 视频）
    if (pathname === '/api/export-episode' && method === 'POST') {
      const body = await readJson(req).catch(() => ({}));
      try {
        const zipPath = await buildEpisodeZip({
          title: String(body.title || '未命名画布').slice(0, 60),
          shots: Array.isArray(body.shots) ? body.shots : [],
        });
        const buf = await fsp.readFile(zipPath);
        const name = `episode-${new Date().toISOString().slice(0, 10)}.zip`;
        res.writeHead(200, {
          'content-type': 'application/zip',
          'content-disposition': `attachment; filename="${encodeURIComponent(name)}"`,
          'content-length': buf.length,
          'cache-control': 'no-store',
        });
        res.end(buf);
        setTimeout(() => cleanupEpisode().catch(() => {}), 3000);
        return;
      } catch (e) {
        return fail(res, 500, '导出失败：' + e.message);
      }
    }

    if (pathname === '/api/projects' && method === 'GET') {
      const files = await fsp.readdir(PROJECT_DIR).catch(() => []);
      const list = [];
      for (const f of files) {
        if (!f.endsWith('.json')) continue;
        try {
          const p = JSON.parse((await fsp.readFile(path.join(PROJECT_DIR, f), 'utf8')).replace(/^\uFEFF/, ''));
          list.push({
            id: p.id || f.replace(/\.json$/, ''),
            title: p.title || '未命名',
            updatedAt: p.updatedAt || 0,
            nodes: Array.isArray(p.nodes) ? p.nodes.length : 0,
          });
        } catch {
          /* 跳过坏文件 */
        }
      }
      list.sort((a, b) => b.updatedAt - a.updatedAt);
      return json(res, 200, { ok: true, projects: list });
    }

    if (pathname.startsWith('/api/projects/')) {
      const id = pathname.slice('/api/projects/'.length);
      if (!PROJ_ID.test(id)) return fail(res, 400, '非法项目 id');
      const file = path.join(PROJECT_DIR, `${id}.json`);

      if (method === 'GET') {
        try {
          const p = JSON.parse((await fsp.readFile(file, 'utf8')).replace(/^\uFEFF/, ''));
          return json(res, 200, { ok: true, project: p });
        } catch {
          return fail(res, 404, '项目不存在');
        }
      }
      if (method === 'PUT' || method === 'POST') {
        const body = await readJson(req, 64 * 1024 * 1024);
        const project = { ...body, id, updatedAt: Date.now() };
        await fsp.writeFile(file, JSON.stringify(project, null, 2), 'utf8');
        return json(res, 200, { ok: true, id, updatedAt: project.updatedAt });
      }
      if (method === 'DELETE') {
        await fsp.rm(file, { force: true });
        return json(res, 200, { ok: true });
      }
    }

    if (pathname.startsWith('/assets/')) {
      const target = safeJoin(ASSET_DIR, pathname.slice('/assets/'.length));
      if (!target) return fail(res, 400, '非法路径');
      return sendFile(req, res, target, { cache: true });
    }

    if (pathname === '/' || pathname === '/index.html') {
      return sendFile(req, res, path.join(WEB_DIR, 'index.html'));
    }

    const target = safeJoin(WEB_DIR, pathname);
    if (target && fs.existsSync(target) && fs.statSync(target).isFile()) return sendFile(req, res, target);

    return fail(res, 404, `未找到 ${pathname}`);
  } catch (e) {
    const code = e?.status || 500;
    if (code >= 500) console.error('[server]', e);
    if (!res.headersSent) return fail(res, code, e?.message || '服务器内部错误');
    res.end();
  }
});

server.listen(PORT, HOST, async () => {
  const line = '─'.repeat(58);
  console.log(`\n${line}`);
  console.log('  豆包2.0 Fast 免费额度专用画布 · 网页额度版');
  console.log(`  地址：http://${HOST}:${PORT}`);
  console.log(`  配置：${CONFIG_FILE}`);
  await bridges.healthAll({ fresh: true });
  const st = bridges.status();
  if (!st.endpoints.length) {
    console.log('  ⚠ 还没有配置任何桥（provider.bridges 为空）');
  } else {
    for (const e of st.endpoints) {
      const limit = e.dailySeconds ? `${e.usedSeconds}/${e.dailySeconds}s` : '不限';
      const state = !e.online ? '未连接' : e.loggedIn ? '已登录' : '未登录';
      console.log(`  · ${e.label.padEnd(12)} ${e.url}  ${state}  今日 ${limit}`);
    }
  }
  console.log(`${line}\n`);
});

const shutdown = async () => {
  console.log('\n[server] 保存额度账本并退出…');
  await quota.flush();
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 1500).unref();
};
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
process.on('uncaughtException', (e) => console.error('[uncaught]', e));
process.on('unhandledRejection', (e) => console.error('[unhandled]', e));
