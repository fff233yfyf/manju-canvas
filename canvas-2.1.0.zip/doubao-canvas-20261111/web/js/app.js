/* 应用外壳：工具栏 / 侧栏 / 菜单 / 快捷键 */

import {
  state,
  api,
  esc,
  toast,
  on,
  emit,
  applyProject,
  setSaveState,
  saveCanvasNow,
  undo,
  redo,
  clearHistory,
  historyState,
  beginEdit,
  commitEdit,
  refreshServerState,
  markDirty,
  fitBounds,
  setZoom,
  applyView,
  closeModal,
  showModal,
  download,
  formatTime,
  startPolling,
  blankProject,
  normalizeProject,
  $,
  $$,
} from './core.js';

import {
  initCanvas,
  renderAll,
  addNode,
  deleteSelection,
  duplicateSelection,
  getBounds,
  reconcileNodeVideos,
  generateAll,
  panToNode,
  syncAll,
  clearSelection,
  selectOnly,
  selectedIds,
} from './nodes.js';
import { initMinimap } from './minimap.js';

let activeTab = 'pool';
let sideVisible = true;

/* ───────────────────────── 卡密门禁 ───────────────────────── */
function showLicenseGate(lic) {
  const machine = lic?.mode === 'machine';
  const code = lic?.machineCode || '';

  const wrap = document.createElement('div');
  wrap.className = 'license-gate';
  wrap.innerHTML = `
    <div class="lg-card${machine ? ' lg-wide' : ''}">
      <div class="lg-logo">豆</div>
      <div class="lg-title">${lic?.expired ? '卡密已到期' : machine ? '本机授权' : '输入卡密'}</div>
      ${lic?.expired ? `<div class="lg-warn lg-expired">
          你的卡密已于 <b>${new Date(lic.expiredAt).toLocaleDateString('zh-CN')}</b> 到期${lic.name ? `（${esc(lic.name)}）` : ''}。<br />
          续费后把新卡密粘在下面就能继续用，画布里的内容都在。
        </div>` : ''}
      ${
        machine
          ? `<div class="lg-sub">把下面这串<b>机器码</b>发给作者，换一张卡密回来。</div>
             ${lic?.tampered ? '<div class="lg-warn">检测到系统时间被改过（比实际时间早）。请把系统时间调回正确值，否则卡密会一直判定为失效。</div>' : ''}
             <div class="lg-code"><span>${esc(code)}</span><button class="btn sm" data-copy>复制</button></div>
             <textarea class="lg-input lg-token" rows="4" placeholder="把作者给你的卡密整段粘在这里"></textarea>`
          : `<div class="lg-sub">这个画布需要卡密才能打开。<br />输入正确后永久记住，下次不用再输。</div>
             <input class="lg-input" type="text" placeholder="请输入卡密" autocomplete="off" spellcheck="false" />`
      }
      <button class="btn primary lg-btn">${machine ? '激活' : '进入画布'}</button>
      ${lic?.expired ? '<button class="btn lg-shop">购买 / 续费</button>' : ''}
      <div class="lg-err"></div>
    </div>`;
  document.body.appendChild(wrap);

  const input = wrap.querySelector('.lg-input');
  const btn = wrap.querySelector('.lg-btn');
  const err = wrap.querySelector('.lg-err');
  const shopBtn = wrap.querySelector('.lg-shop');
  if (shopBtn) shopBtn.onclick = () => openShop();
  const copyBtn = wrap.querySelector('[data-copy]');
  if (copyBtn) {
    copyBtn.onclick = () => {
      navigator.clipboard?.writeText(code).then(
        () => toast('机器码已复制', 'ok', 1600),
        () => toast('复制失败，手动选中吧', 'warn', 2000)
      );
    };
  }

  const submit = async () => {
    const key = input.value.trim();
    if (!key) {
      err.textContent = '请输入卡密';
      input.focus();
      return;
    }
    btn.disabled = true;
    err.textContent = '';
    btn.textContent = '校验中…';
    try {
      await api.activateLicense(key);
      wrap.remove();
      boot();
    } catch (e) {
      err.textContent = e.message || '卡密不正确';
      btn.disabled = false;
      btn.textContent = machine ? '激活' : '进入画布';
      input.select?.();
    }
  };

  btn.onclick = submit;
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !machine) submit();
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) submit();
  });
  setTimeout(() => input.focus(), 60);
}

/** 需要卡密且没激活 → 显示门禁并返回 true（调用方就别继续 boot 了） */
async function licenseBlocksBoot() {
  try {
    const lic = await api.license();
    // 记住这张卡的信息（名字/到期），供设置页显示
    state.license = lic || null;
    if (!lic.enabled || lic.activated) return false;
    showLicenseGate(lic);
    return true;
  } catch {
    return false; // 服务端异常时不把人挡在外面
  }
}

/* ───────────────────────── 启动 ───────────────────────── */
async function boot() {
  if (await licenseBlocksBoot()) return;
  initCanvas();
  bindUI();
  await refreshServerState();
  await loadQuota();
  startPoolWatch();

  // 每次打开都是一张全新画布：不自动恢复上次的内容。
  // 想接着上次做，用左上角「打开」导入保存过的文件。
  applyProject(blankProject('未命名画布'));
  renderAll();

  // 恢复刷新前仍在跑的任务
  try {
    const r = await api.jobs(true);
    if (r.jobs.length) {
      for (const j of r.jobs) state.jobs.set(j.id, j);
      emit('jobs:updated');
      startPolling();
    }
  } catch {
    /* 离线 */
  }

  // 对账：任务可能在页面没开着的时候完成了，节点上不会自己出现视频。
  // 打开画布先补一次，之后每 10 秒补一次（新完成的任务也会落上）。
  reconcileNodeVideos().catch(() => {});
  if (!window.__reconcileTimer) {
    window.__reconcileTimer = setInterval(() => {
      reconcileNodeVideos().catch(() => {});
    }, 5000);
  }

  renderSide();
  const b = getBounds();
  if (b) fitBounds(b, { padding: 120, maxScale: 0.95 });
  else fitBounds({ minX: 0, minY: 0, maxX: 900, maxY: 600 }, { padding: 80, maxScale: 1 });

  if (new URLSearchParams(location.search).get('sample') === '1') {
    setTimeout(loadSample, 120);
  }

  setInterval(() => {
    if (document.hidden) return;
    if (activeTab === 'pool' && sideVisible) refreshServerState();
  }, 15000);
}

/* ───────────────────────── 顶栏 ───────────────────────── */
function bindUI() {
  // 关标签页 / 刷新时，有未保存的改动就让浏览器拦一下（原生提示，文案改不了）
  window.addEventListener('beforeunload', (e) => {
    if (!state.dirty) return;
    e.preventDefault();
    e.returnValue = '这张画布还没保存，确定离开吗？';
    return e.returnValue;
  });

  const sub = document.getElementById('add-sub');
  const imgBtn = document.querySelector('.addbar button[data-menu="image"]');

  $$('#addbar button[data-add]').forEach((b) => {
    // 「图片」主按钮只是打开子菜单
    if (b.dataset.menu) {
      b.onclick = (e) => {
        e.stopPropagation();
        sub.hidden = !sub.hidden;
        b.classList.toggle('open', !sub.hidden);
      };
      return;
    }
    const kind = b.dataset.kind || '';
    b.onclick = () => {
      sub.hidden = true;
      imgBtn?.classList.remove('open');
      addNode(b.dataset.add, { data: kind ? { kind } : {} });
    };
    // 也可以直接从菜单拖到画布上松手
    b.addEventListener('dragstart', (e) => {
      e.dataTransfer.setData('text/manju-node', JSON.stringify({ type: b.dataset.add, kind }));
      e.dataTransfer.effectAllowed = 'copy';
    });
  });

  document.addEventListener('click', (e) => {
    if (!sub.contains(e.target) && !e.target.closest('.add-split')) {
      sub.hidden = true;
      imgBtn?.classList.remove('open');
    }
  });

  const vp = document.getElementById('viewport');

  // 画布上按住左键拖动时，浏览器会顺手选中文字，松手就变成「拖去搜索」。
  // 这里统一掐掉：除了「添加节点」菜单和输入框，其他一律不许起拖拽。
  document.addEventListener(
    'dragstart',
    (e) => {
      const t = e.target;
      if (!(t instanceof Element)) return;
      if (t.closest('[data-add]')) return; // 从菜单拖节点出来，保留
      if (t.closest('input, textarea, [contenteditable="true"]')) return; // 输入框里选字，保留
      e.preventDefault();
    },
    true,
  );

  // 拖画布/节点时别让浏览器选中文字（双击、三击也会触发）
  vp.addEventListener('selectstart', (e) => {
    const t = e.target;
    if (!(t instanceof Element)) return;
    if (t.closest('input, textarea, [contenteditable="true"]')) return;
    e.preventDefault();
  });

  // 关键一道：长按左键/拖动时根本别开始选区。
  // Edge 一有选区就弹「AI 搜索 / 复制 / 翻译 / 朗读 / 总结」那条浮动菜单，
  // 画画布时非常烦。在 mousedown 上直接掐掉，选区起不来，菜单就不会出现。
  const EDITABLE = 'input, textarea, select, [contenteditable="true"]';
  vp.addEventListener(
    'mousedown',
    (e) => {
      if (e.button !== 0) return; // 右键、中键不拦
      const t = e.target;
      if (!(t instanceof Element)) return;
      if (t.closest(EDITABLE)) return; // 输入框里正常点选文字
      e.preventDefault();
    },
    true,
  );

  // 保险：canvas 区域里右键菜单也别弹（节点上还是保留，方便用户用浏览器功能）
  vp.addEventListener('contextmenu', (e) => {
    const t = e.target;
    if (!(t instanceof Element)) return;
    if (t.closest(EDITABLE) || t.closest('.node')) return;
    e.preventDefault();
  });

  vp.addEventListener('dragover', (e) => {
    if (e.dataTransfer?.types?.includes('text/manju-node')) {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'copy';
    }
  });
  vp.addEventListener('drop', (e) => {
    const raw = e.dataTransfer?.getData('text/manju-node');
    if (!raw) return;
    e.preventDefault();
    try {
      const { type, kind } = JSON.parse(raw);
      addNode(type, { at: { x: e.clientX, y: e.clientY }, data: kind ? { kind } : {} });
      sub.hidden = true;
      imgBtn?.classList.remove('open');
    } catch {
      /* ignore */
    }
  });

  $('#btn-list').onclick = () => showCanvases();
  $('#btn-new').onclick = () => newCanvas();
  $('#btn-genall').onclick = async () => {
  if (!state.project?.nodes?.length) return toast('画布是空的，先加点节点', 'warn', 2500);
  await generateAll();
};

$('#btn-save').onclick = async () => {
    // 顶栏「保存」= 存进本地「画布」列表（以前是自动存的，现在完全手动）
    if (!state.project?.nodes?.length) return toast('画布是空的，先加点东西再存', 'warn', 2500);
    const ok = await saveCanvasNow().catch(() => false);
    if (ok) toast('已保存到「画布」列表', 'ok', 2500);
    else toast('保存失败，看看后台服务还在不在', 'err', 4000);
  };
  $('#btn-open').onclick = () => importProject();

  const undoBtn = $('#btn-undo');
  const redoBtn = $('#btn-redo');
  undoBtn.onclick = () => {
    if (!undo()) return toast('没有可撤销的操作', 'warn', 1600);
  };
  redoBtn.onclick = () => {
    if (!redo()) return toast('没有可重做的操作', 'warn', 1600);
  };
  on('history:changed', (ev) => {
    const { canUndo, canRedo } = ev.detail || {};
    undoBtn.disabled = !canUndo;
    redoBtn.disabled = !canRedo;
  });
  const hs = historyState();
  undoBtn.disabled = !hs.canUndo;
  redoBtn.disabled = !hs.canRedo;

  const title = $('#project-title');
  title.addEventListener('input', () => {
    if (!state.project) return;
    state.project.title = title.value.trim() || '未命名画布';
    document.title = `${state.project.title} · 豆包2.0 Fast 免费额度专用画布`;
    beginEdit();
    markDirty();
  });
  title.addEventListener('blur', () => commitEdit());

  $('#btn-fit').onclick = () => {
    const b = getBounds();
    if (b) fitBounds(b, { padding: 110, maxScale: 1 });
    else toast('画布还是空的', 'warn');
  };
  $('#btn-zoom-in').onclick = () => setZoom(state.view.k * 1.2);
  $('#btn-zoom-out').onclick = () => setZoom(state.view.k / 1.2);
  $('#btn-pool').onclick = () => {
    if (sideVisible && activeTab === 'pool') {
      sideVisible = false;
    } else {
      sideVisible = true;
      activeTab = 'pool';
    }
    syncSideVisibility();
    renderSide();
  };
  $('#btn-menu').onclick = (e) => openMenu(e.currentTarget);

  $$('#side-tabs button').forEach((b) => {
    b.onclick = () => {
      activeTab = b.dataset.tab;
      $$('#side-tabs button').forEach((x) => x.classList.toggle('on', x === b));
      renderSide();
    };
  });

  on('server:updated', () => {
    if (activeTab === 'pool' && sideVisible) renderSide();
    syncAll();
  });
  on('jobs:updated', () => {
    if (activeTab === 'queue' && sideVisible) renderSide();
    const badge = $('#btn-pool');
    const active = [...state.jobs.values()].filter((j) => j.status === 'queued' || j.status === 'running').length;
    badge.textContent = active ? `额度 · ${active}` : '额度';
    badge.classList.toggle('on', active > 0);
  });
  on('job:done', () => {
    if (activeTab === 'queue') renderSide();
  });
  on('project:loaded', () => {
    document.title = `${state.project.title} · 豆包2.0 Fast 免费额度专用画布`;
    renderSide();
  });

  window.addEventListener('keydown', onKeyDown);
  window.addEventListener('resize', () => renderEdgesSoon());
}

let edgeTimer = null;
function renderEdgesSoon() {
  if (edgeTimer) return;
  edgeTimer = setTimeout(() => {
    edgeTimer = null;
    import('./nodes.js').then((m) => m.renderEdges());
  }, 120);
}

function syncSideVisibility() {
  const side = $('#side');
  side.hidden = !sideVisible;
  $('#btn-pool').classList.toggle('on', sideVisible && activeTab === 'pool');
}

/* ───────────────────────── 侧栏 ───────────────────────── */
function renderSide() {
  syncSideVisibility();
  const body = $('#side-body');
  if (!body) return;
  if (!sideVisible) return;
  const scroll = body.scrollTop;
  if (activeTab === 'pool') body.innerHTML = poolHtml();
  else if (activeTab === 'queue') body.innerHTML = queueHtml();
  else body.innerHTML = settingsHtml();
  body.scrollTop = scroll;
  wireSide(body);
}

/** 每条桥一张卡：连接状态 + 今日秒数 + 登录 */
function bridgeCardsHtml() {
  const eps = state.server?.provider?.endpoints || [];
  if (!eps.length) {
    return `<div class="mock-banner">
      <b>还没有配置桥</b>：现在出不了片。<br />
      先跑 <code>node bridge/doubao-bridge.mjs</code>，再在 <code>config/config.json</code> 里登记。
    </div>`;
  }
  return eps
    .map((e) => {
      const known = e.health?.checked !== false;
      const dot = !e.online ? 'off' : e.loggedIn ? '' : 'cool';
      const stateText = !e.online ? '未连接' : e.loggedIn ? '已登录' : known ? '未登录' : '待确认';
      const limit = Number(e.dailySeconds) || 0;
      const used = Number(e.usedSeconds) || 0;
      const width = limit ? Math.min(100, Math.round((used / limit) * 100)) : 0;
      const empty = limit > 0 && used >= limit;
      const kinds = (e.kinds || []).map((k) => (k === 'video' ? '视频' : '图片')).join('/');
      const fp = e.loggedIn && e.health?.fingerprint ? ` · #${e.health.fingerprint}` : '';
      // 豆包自己说过「今日额度用完」—— 这是它那边的真实状态，比本地记账准
      const exhaustedAt = Number(e.quotaExhaustedAt) || 0;
      const exhaustedToday = exhaustedAt && new Date(exhaustedAt).toDateString() === new Date().toDateString();
      return `<div class="acc">
        <div class="acc-top">
          <span class="acc-dot ${dot}"></span>
          <span class="acc-name">${esc(e.label)}</span>
          <span class="acc-tag">${stateText}</span>
        </div>
        <div class="bar-row">
          <span class="lbl">今日</span>
          <span class="bar"><i class="${empty ? 'full' : ''}" style="width:${width}%"></i></span>
          <span class="num">${used} / ${limit ? `${limit}s` : '不限'}</span>
        </div>
        ${exhaustedToday
          ? `<div class="quota-real">豆包说：今日额度已用完 · ${new Date(exhaustedAt).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })} · 今天不再派活给它</div>`
          : ''}
        <div class="set-hint">${esc(e.url)}${e.account ? ` · ${esc(e.account)}` : ''}${fp}${kinds ? ` · ${kinds}` : ''}</div>
        ${e.health?.challenge ? `<div class="challenge-banner">
            <b>豆包要求${esc(e.health.challenge.label || '人机验证')}</b><br />
            ${esc(e.health.challenge.hint || '去那个窗口里完成验证')}。窗口已经自动弹出来了。
            <div class="n-row" style="margin-top:6px">
              <button class="btn primary" data-side="challenge-done" data-id="${esc(e.id)}">我已完成</button>
              <button class="btn" data-side="challenge-focus" data-id="${esc(e.id)}">把窗口叫出来</button>
            </div>
          </div>` : ''}
        ${!e.loggedIn && e.online && !known ? `<div class="set-hint">还没打开浏览器，登录态未知 —— 点「登录豆包」确认，一般不用再扫码</div>` : ''}
        ${!e.loggedIn && e.health?.loginReason ? `<div class="set-hint">${esc(e.health.loginReason)}</div>` : ''}
        <div class="n-row">
          <button class="btn" data-side="bridge-refresh" title="重新探测在线/登录状态，不会重置额度">重新检测</button>
          <button class="btn primary" data-side="bridge-login" data-id="${esc(e.id)}">${e.loggedIn ? '重新登录' : '登录豆包'}</button>
        </div>
      </div>`;
    })
    .join('');
}

async function loadQuota({ fresh = false } = {}) {
  try {
    state.bridge = await api.quota(fresh);
  } catch (e) {
    state.bridge = { ok: false, error: e.message };
  }
  {
    // 额度预测：只算「在线且已登录」的号，其他号今天指望不上
    const eps = state.bridge?.endpoints || [];
    const usable = eps.filter((e) => e.online && e.loggedIn).reduce((s, e) => s + (Number(e.remainingSeconds) || 0), 0);
    const total = eps.reduce((s, e) => s + (Number(e.remainingSeconds) || 0), 0);
    state.quota = { usable, total, at: Date.now() };
  }
  if (sideVisible && activeTab === 'pool') renderSide();
}

/**
 * 启动后盯一会儿：桥在自动唤醒浏览器，登录态恢复后卡片要自己变绿，
 * 不用用户逐个点「登录豆包」或「重新检测」。
 */
function startPoolWatch() {
  let ticks = 0;
  const timer = setInterval(async () => {
    ticks += 1;
    const eps = state.bridge?.endpoints || [];
    // 只要还有「浏览器没起来 / 还没查过登录态」的账号，就继续刷新
    const waiting = eps.some((e) => e.online && e.health?.checked !== true);
    if (!eps.length || !waiting || ticks > 100) {
      clearInterval(timer);
      return;
    }
    await loadQuota();
  }, 3000);
}

/** 等某个桥的登录结果（扫码成功后返回 true） */
function waitForLogin(id, timeoutMs = 180000) {
  return new Promise((resolve) => {
    const t0 = Date.now();
    const timer = setInterval(async () => {
      if (Date.now() - t0 > timeoutMs) {
        clearInterval(timer);
        resolve(false);
        return;
      }
      try {
        const r = await api.bridgeLoginStatus(id);
        if (r.status === 'logged_in') {
          clearInterval(timer);
          resolve(true);
        } else if (r.status === 'failed') {
          clearInterval(timer);
          resolve(false);
        }
      } catch {
        /* 网络抖动，继续等 */
      }
    }, 2000);
  });
}

/** 一键登录：把还没登录的账号逐个弹窗扫码，扫完自动收回任务栏 */
async function loginAllMissing() {
  const eps = (state.bridge?.endpoints || []).filter((e) => e.online && !e.loggedIn);
  if (!eps.length) return toast('所有账号都已经登录了，不用扫', 'ok');
  if (!confirm(`有 ${eps.length} 个账号没登录。\n\n会一个接一个弹出窗口，扫完一个自动收起再弹下一个。开始吗？`)) return;

  let done = 0;
  for (let i = 0; i < eps.length; i++) {
    const e = eps[i];
    toast(`[${i + 1}/${eps.length}] ${e.label}：请在弹出的窗口里扫码`, '', 6000);
    try {
      await api.bridgeLogin(e.id);
    } catch (err) {
      toast(`${e.label} 打不开窗口：${err.message}`, 'err', 5000);
      continue;
    }
    const ok = await waitForLogin(e.id);
    if (ok) {
      done += 1;
      toast(`${e.label} 登录成功`, 'ok', 2200);
      // 扫完把它缩回任务栏，别一直挡着
      await api.bridgeWindow(e.id, 'minimized').catch(() => {});
    } else {
      toast(`${e.label} 超时，先跳过`, 'warn', 3000);
    }
    await loadQuota();
  }
  await loadQuota();
  toast(`一键登录结束：成功 ${done} / ${eps.length}`, done ? 'ok' : 'warn', 4000);
}

async function bridgeLogin(id) {  try {
    await api.bridgeLogin(id);
    toast('已请求桥打开登录窗口，请在弹出的窗口里扫码登录豆包', '', 5000);
  } catch (e) {
    return toast(`启动登录失败：${e.message}`, 'err', 6000);
  }
  const t0 = Date.now();
  const timer = setInterval(async () => {
    if (Date.now() - t0 > 180000) {
      clearInterval(timer);
      toast('等待登录超时，可以再点一次「登录豆包」', 'warn');
      return;
    }
    try {
      const r = await api.bridgeLoginStatus(id);
      if (r.status === 'logged_in') {
        clearInterval(timer);
        toast(`登录成功：${r.account || '豆包账号'}`, 'ok');
        await loadQuota();
      } else if (r.status === 'failed') {
        clearInterval(timer);
        toast(`登录失败：${r.error || '桥报告失败'}`, 'err', 7000);
      }
    } catch {
      /* 桥可能还没起来，继续等 */
    }
  }, 2000);
}

function poolHtml() {
  const s = state.server;
  if (!s) {
    return `<div class="set-hint">正在连接本地服务…<br />如果一直停在这里，请确认 <code>node server.mjs</code> 正在运行。</div>`;
  }
  const eps = s.provider?.endpoints || [];
  const limit = eps.reduce((n, e) => n + (Number(e.dailySeconds) || 0), 0);
  const used = eps.reduce((n, e) => n + (Number(e.usedSeconds) || 0), 0);
  const online = eps.filter((e) => e.online && e.loggedIn).length;
  const reachable = eps.filter((e) => e.online).length;
  const width = limit ? Math.min(100, Math.round((used / limit) * 100)) : 0;

  const banner =
    eps.length && reachable === 0
      ? `<div class="mock-banner">
          <b>桥还没启动</b>：${eps.length} 个账号一个都连不上。<br />
          在你自己的终端里跑 <code>node bridge/run-pool.mjs</code>（别关那个窗口），再点下面「刷新」。
        </div>`
      : '';

  const pending = eps.filter((e) => e.online && e.health?.checked !== true).length;
  const waking = pending
    ? `<div class="set-hint waking"><span class="spin"></span>正在自动唤醒 ${pending} 个账号的浏览器，登录态会自动恢复，不用点…</div>`
    : '';

  const summary = `<div class="acc">
    <div class="acc-top"><span class="acc-name">今日视频额度</span><span class="acc-tag">${esc(s.quota?.date || '')}</span></div>
    <div class="bar-row"><span class="lbl">合计</span><span class="bar"><i class="${limit > 0 && used >= limit ? 'full' : ''}" style="width:${width}%"></i></span><span class="num">${used} / ${limit || '不限'}s</span></div>
    <div class="set-hint">${online} / ${eps.length} 个账号在线 · 每号每天 30 秒，按秒扣（10 秒镜头 = 每号 3 条）</div>
    <div class="set-hint">本地按秒记账，每天 0 点自动归零；真实额度以豆包网页为准。</div>
    ${waking}
  </div>`;

  return `${banner}${summary}
    <div class="sec-title"><span>豆包账号（桥）</span><button data-side="bridge-login-all" title="把还没登录的账号逐个打开窗口扫码，扫完自动收起">一键登录</button><button data-side="bridge-refresh" title="重新探测桥的在线/登录状态，不会重置额度">重新检测</button></div>
    ${bridgeCardsHtml()}
    <div class="sec-title"><span>任务</span></div>
    <div class="set-hint">排队 ${s.jobs?.queued ?? 0} · 生成中 ${s.jobs?.running ?? 0} · 并发 ${s.jobs?.concurrency ?? 0}</div>`;
}

function queueHtml() {
  const jobs = [...state.jobs.values()].sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0)).slice(0, 40);
  if (!jobs.length) return `<div class="set-hint">还没有任务。在文本卡上点「出视频」开始。</div>`;
  const items = jobs
    .map((j) => {
      const cls = j.status;
      const label =
        j.status === 'queued'
          ? j.queuePosition > 0
            ? `排队 ${j.queuePosition}`
            : '排队中'
          : j.status === 'running'
            ? `生成中${j.progress ? ` ${j.progress}%` : ''}`
            : j.status === 'succeeded'
              ? `完成 · ${j.accountLabel || ''}`
              : j.status === 'cancelled'
                ? '已取消'
                : '失败';
      const canCancel = j.status === 'queued' || j.status === 'running';
      return `<div class="job" data-job="${j.id}" data-node="${j.nodeId || ''}">
        <div class="job-top">
          <span class="job-kind ${j.kind}">${j.kind === 'video' ? '视频' : '图片'}${j.provider === 'bridge' ? '·网页' : ''}</span>
          <span class="job-prompt">${esc(j.title || j.prompt || '')}</span>
        </div>
        <div class="job-sub"><span>${esc(label)}</span><span>${j.finishedAt ? formatTime(j.finishedAt) : ''}</span></div>
        ${j.error ? `<div class="job-sub"><span class="err">${esc(j.error)}</span></div>` : ''}
        ${canCancel ? `<div class="job-sub"><button class="mini-btn" data-cancel="${j.id}">取消这一条</button></div>` : ''}
      </div>`;
    })
    .join('');
  return `<div class="sec-title"><span>任务队列</span><button data-side="refreshJobs">刷新</button></div>${items}`;
}

function settingsHtml() {
  const s = state.project?.settings || {};
  const sv = state.server || {};
  return `
    <div class="sec-title"><span>画布默认</span></div>
    <div class="set-group">
      <div class="set-row"><label>画幅（文本卡默认）</label>
        <select data-set="ratio">
          ${[
            ['auto', '自动（跟随首帧）'],
            ['16:9', '16:9 横屏'],
            ['9:16', '9:16 竖屏'],
            ['1:1', '1:1 方形'],
            ['4:3', '4:3'],
            ['3:4', '3:4'],
            ['21:9', '21:9 宽银幕'],
          ]
            .map(([v, t]) => `<option value="${v}"${s.ratio === v ? ' selected' : ''}>${t}</option>`)
            .join('')}
        </select>
      </div>
      <div class="set-row"><label>全局画风（会拼进每条视频提示词）</label>
        <textarea data-set="style" rows="3" placeholder="例如：日式赛璐璐动画风，干净线稿，高饱和，电影级光影">${esc(s.style || '')}</textarea>
        <div class="style-actions">
          <select id="style-pick"><option value="">— 我的画风 —</option></select>
          <button class="btn sm" id="style-save" title="把当前这段画风存成一个常用项">存为常用</button>
          <button class="btn sm ghost" id="style-del" title="删掉选中的常用画风" disabled>删除</button>
        </div>
      </div>
    </div>

    <div class="sec-title"><span>视频</span></div>
    <div class="set-group">
      <div class="set-row"><label>默认时长（秒）<b class="dur-val" id="set-dur-val">${Number(s.duration) || 5} 秒</b></label>
        <input type="range" class="dur-range" data-set="duration" id="set-dur" min="4" max="15" step="1" value="${Number(s.duration) || 5}" />
        <div class="dur-chips" id="set-dur-chips">
          <span class="dur-quick">快速选择</span>
          ${[10, 15].map((v) => `<button class="dur-chip${Number(s.duration) === v ? ' on' : ''}" data-setdur="${v}">${v} 秒</button>`).join('')}
        </div>
      </div>
      <div class="set-fixed">网页端是 4–15 秒的滑杆。额度按秒扣：30 ÷ 时长 = 每号每天能出几条</div>
      <div class="set-row"><label>分辨率</label>
        <div class="set-fixed">720p · 豆包网页版固定，改不了</div>
      </div>
      <div class="set-row"><label>原生音频</label>
        <div class="set-fixed">网页端没有开关，默认带音频</div>
      </div>
      <div class="set-hint">文本卡自己也能单独改时长和画幅，留空就跟随这里的默认。</div>
    </div>

    <div class="sec-title"><span>服务</span></div>
    <div class="set-hint">
      版本：<b id="ver-now">读取中…</b><br />
      授权：<b id="lic-now">读取中…</b><br />
      配置：<code>${esc(sv.configFile || 'config/config.json')}</code><br />
      改桥的地址 / 额度后点下面「重载配置」；改桥自己的代码要重启桥进程。
    </div>
    <div class="n-row">
      <button class="btn" data-side="reload">重载配置</button>
      <button class="btn" data-side="update" title="检查有没有新版本">检查更新</button>
      <button class="btn primary" data-side="shop" title="买/续卡密">购买 / 续费</button>
    </div>
    <div class="n-row">
      <button class="btn" data-side="export" title="把镜头按画布顺序打包成 zip（清单 + 视频）">导出整集</button>
    </div>
    <div class="n-row">
      <button class="btn" data-side="diag" title="把日志和环境信息打包下载，出问题时发给作者">导出诊断包</button>
    </div>
    <div class="n-row">
      <button class="btn" data-side="help">快捷键</button>
      <button class="btn" data-side="sample">示例项目</button>
    </div>`;
}

function wireSide(root) {
  root.querySelectorAll('[data-set]').forEach((el) => {
    const apply = () => {
      if (!state.project) return;
      const k = el.dataset.set;
      let v = el.value;
      if (k === 'generateAudio' || k === 'watermark') v = el.value === '1';
      else if (k === 'duration') v = Math.min(15, Math.max(4, Number(el.value) || 5));
      else if (el.type === 'number') v = Number(el.value);
      state.project.settings[k] = v;
      markDirty();
      syncAll();
    };
    el.addEventListener(el.tagName === 'SELECT' ? 'change' : 'input', apply);
  });

  // 默认时长：滑杆 + 常用值按钮联动
  {
    const range = root.querySelector('#set-dur');
    const label = root.querySelector('#set-dur-val');
    const chips = root.querySelector('#set-dur-chips');
    if (range && label) {
      const paint = (v) => {
        label.textContent = v + ' 秒';
        for (const b of chips?.querySelectorAll('[data-setdur]') || []) {
          b.classList.toggle('on', Number(b.dataset.setdur) === v);
        }
      };
      range.addEventListener('input', () => paint(Number(range.value) || 5));
      chips?.querySelectorAll('[data-setdur]').forEach((b) => {
        b.onclick = () => {
          const v = Number(b.dataset.setdur) || 5;
          range.value = String(v);
          paint(v);
          range.dispatchEvent(new Event('input', { bubbles: true }));
        };
      });
    }
  }

  // 设置页里出现画风输入框时，把「我的画风」接上
  if (root.querySelector('textarea[data-set="style"]')) wireStyleActions();

  // 顺便把版本号填上（客户报问题时能直接说是哪个版本）
  {
    const el = root.querySelector('#ver-now');
    if (el) {
      const serverVer = state.server?.version || '';
      if (serverVer) el.textContent = serverVer + (state.server?.buildDate ? ' · ' + state.server.buildDate : '');
      else
        fetch('/api/version')
          .then((r) => r.json())
          .then((j) => {
            el.textContent = j.version || '未知';
          })
          .catch(() => {
            el.textContent = '读取失败';
          });
    }
  }

  // 授权状态 / 到期时间
  {
    const el = root.querySelector('#lic-now');
    if (el) {
      const lic = state.license;
      const tr = lic?.trial;
      if (lic && lic.enabled && !lic.activated === false) {
        /* 已激活，走下面的正常分支 */
      }
      if (lic?.enabled && !lic?.hasCard && tr?.active) {
        const d = new Date(tr.endsAt);
        const dateStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
        el.innerHTML = `试用中 · 还剩 <b>${tr.daysLeft}</b> 天（${dateStr} 到期）<span class="lic-warn">　到期后需要卡密</span>`;
      } else if (!lic || !lic.enabled) el.textContent = '不需要卡密（无限期）';
      else if (!lic.activated) el.textContent = '未激活';
      else if (!lic.expiresAt) el.textContent = `${lic.name || '已激活'} · 永久`;
      else {
        const d = new Date(lic.expiresAt);
        const days = lic.daysLeft;
        const dateStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
        el.innerHTML =
          `${esc(lic.name || '已激活')} · 到期 <b>${dateStr}</b> ` +
          (days <= 0
            ? '<span class="lic-bad">（今天到期）</span>'
            : days <= 7
              ? `<span class="lic-warn">（还剩 ${days} 天，记得续费）</span>`
              : `<span class="lic-ok">（还剩 ${days} 天）</span>`);
      }
    }
  }

  root.querySelectorAll('[data-side]').forEach((btn) => {
    const act = btn.dataset.side;
    btn.onclick = async () => {
      if (act === 'reload') {
        try {
          const r = await api.reloadConfig();
          await refreshServerState();
          if (r.mock) toast('重载完成，但还没有可用账号（仍在模拟模式）', 'warn');
          else toast(`重载完成，${r.accounts?.length ?? 0} 个账号就绪`, 'ok');
          renderSide();
        } catch (e) {
          toast(e.message, 'err');
        }
      } else if (act === 'refreshJobs') {
        try {
          const r = await api.jobs();
          for (const j of r.jobs) state.jobs.set(j.id, j);
          renderSide();
        } catch (e) {
          toast(e.message, 'err');
        }
      } else if (act === 'bridge-login-all') {
        await loginAllMissing();
      } else if (act === 'bridge-refresh') {
        await loadQuota({ fresh: true });
        toast('已重新探测：这里只更新在线/登录状态，额度按本地账本显示', 'ok', 4000);
      } else if (act === 'bridge-login') {
        await bridgeLogin(btn.dataset.id);
      } else if (act === 'challenge-done') {
        try {
          await api.bridgeChallengeDone(btn.dataset.id);
          toast('收到，正在重新检查页面…', 'ok', 2500);
          setTimeout(() => loadQuota({ fresh: true }), 1500);
          setTimeout(() => loadQuota(), 4500);
        } catch (e) {
          toast(e.message, 'err');
        }
      } else if (act === 'challenge-focus') {
        try {
          await api.bridgeWindow(btn.dataset.id, 'normal');
          toast('窗口已叫出来，去那个窗口里完成验证', 'ok', 3000);
        } catch (e) {
          toast(e.message, 'err');
        }
      } else if (act === 'shop') {
        openShop();
      } else if (act === 'update') {
        checkUpdate();
      } else if (act === 'export') {
        exportEpisode();
      } else if (act === 'diag') {
        toast('正在打包诊断信息…', '', 2500);
        window.open('/api/diagnostics.zip', '_blank');
      } else if (act === 'help') showHelp();
      else if (act === 'sample') loadSample();
    };
  });

  root.querySelectorAll('[data-job]').forEach((el) => {
    el.onclick = () => {
      if (el.dataset.node) panToNode(el.dataset.node);
    };
  });

  // 取消这条任务（排队中的会直接撤掉；生成中的会通知桥停手）
  root.querySelectorAll('[data-cancel]').forEach((btn) => {
    btn.onclick = async (ev) => {
      ev.stopPropagation();
      const id = btn.dataset.cancel;
      btn.disabled = true;
      btn.textContent = '正在取消…';
      try {
        await api.cancel(id);
        toast('已发送取消请求', 'ok', 2500);
      } catch (e) {
        toast('取消失败：' + e.message, 'err', 3000);
      } finally {
        startPolling(); // 让队列里的状态尽快刷新
      }
    };
  });
}

/* ───────────────────────── 菜单 ───────────────────────── */
function openMenu(anchor) {
  const pop = $('#menu-pop');
  pop.innerHTML = `
    <button data-m="new">新建画布 <span>清空</span></button>
    <button data-m="open">打开画布文件… <span>Ctrl O</span></button>
    <button data-m="save">保存到… <span>Ctrl S</span></button>
    <hr />
    <button data-m="sample">载入示例项目</button>
    <button data-m="help">快捷键 & 说明 <span>?</span></button>`;
  const r = anchor.getBoundingClientRect();
  pop.hidden = false;
  pop.style.left = `${Math.min(r.left, window.innerWidth - 200)}px`;
  pop.style.top = `${r.bottom + 6}px`;

  const close = (e) => {
    if (!pop.contains(e.target) && e.target !== anchor) {
      pop.hidden = true;
      document.removeEventListener('pointerdown', close);
    }
  };
  setTimeout(() => document.addEventListener('pointerdown', close), 0);

  pop.querySelectorAll('[data-m]').forEach((b) => {
    b.onclick = () => {
      pop.hidden = true;
      const m = b.dataset.m;
      if (m === 'new') newCanvas();
      else if (m === 'open') importProject();
      else if (m === 'save') saveToFile();
      else if (m === 'sample') loadSample();
      else if (m === 'help') showHelp();
    };
  });
}

/** 换一张空白画布（不再触发保存） */
function resetToBlank() {
  clearHistory();
  applyProject(blankProject('未命名画布'));
  renderAll();
  fitBounds({ minX: 0, minY: 0, maxX: 900, maxY: 600 }, { padding: 60, maxScale: 1 });
  state.dirty = false;
  setSaveState('', '新画布');
}

/**
 * 有未保存的改动时问一下：保存 / 不保存 / 取消
 * @returns {'save'|'discard'|'cancel'}
 */
function confirmUnsaved(actionText = '继续') {
  return new Promise((resolve) => {
    if (!state.dirty) return resolve('discard');
    const root = showModal({
      title: '这张画布还没保存',
      html: `
        <div class="set-hint" style="line-height:1.8">
          ${esc(actionText)}之后，这张画布上的改动就没了。<br />
          要先把当前画布存进「画布」列表吗？
        </div>
        <div class="n-row" style="margin-top:16px;justify-content:flex-end;gap:8px">
          <button class="btn" data-cu="cancel">取消</button>
          <button class="btn" data-cu="discard">不保存</button>
          <button class="btn primary" data-cu="save">保存并继续</button>
        </div>`,
      actions: [],
    });
    if (!root) return resolve('discard');

    const finish = (v) => {
      closeModal();
      resolve(v);
    };
    root.querySelectorAll('[data-cu]').forEach((b) => {
      b.onclick = () => finish(b.dataset.cu);
    });
    // 点右上角 × 或背景 = 取消
    const x = root.querySelector('[data-close]');
    if (x) x.onclick = () => finish('cancel');
  });
}

/** 新建画布：先问要不要存，再开一张新的（旧的不会被顶掉） */
async function newCanvas(force = false) {
  if (!force) {
    const choice = await confirmUnsaved('新建画布');
    if (choice === 'cancel') return;
    if (choice === 'save') {
      const ok = await saveCanvasNow().catch(() => false);
      if (!ok) return toast('保存失败，先别新建了', 'err', 4000);
    }
  }
  resetToBlank();
  toast('已新建空白画布', 'ok', 2500);
}

/** 画布列表：打开 / 删除（不再自动保存当前画布） */
async function showCanvases() {
  let list = [];
  try {
    const r = await api.listProjects();
    list = r.projects || [];
  } catch (e) {
    return toast(`读取画布列表失败：${e.message}`, 'err');
  }

  const cur = state.project?.id;
  const html = list.length
    ? `<div class="proj-tools">
         <label class="pt-all"><input type="checkbox" id="proj-all" /> 全选</label>
         <span class="pt-count" id="proj-count">已选 0 张</span>
         <span style="flex:1"></span>
         <button class="btn" id="proj-del-sel" disabled>删除选中</button>
         <button class="btn danger" id="proj-del-all">全部删除</button>
       </div>
       <div class="proj-list">${list
         .map(
           (p) => `<div class="proj-item${p.id === cur ? ' cur' : ''}" data-pid="${esc(p.id)}">
             <input type="checkbox" class="pi-check" data-check="${esc(p.id)}" />
             <div style="flex:1">
               <div class="pi-title">${esc(p.title)}${p.id === cur ? ' <span class="cur-tag">当前</span>' : ''}</div>
               <div class="pi-sub">${p.nodes} 个节点 · ${p.updatedAt ? new Date(p.updatedAt).toLocaleString('zh-CN') : ''}</div>
             </div>
             <button class="pi-del" data-del="${esc(p.id)}" title="删除这张画布">×</button>
           </div>`
         )
         .join('')}</div>`
    : `<div class="set-hint">还没有存过的画布。点左上角「保存」会把当前画布存到这里。</div>`;

  const root = showModal({
    title: '画布列表',
    html: `${html}<div class="set-hint" style="margin-top:8px">点一行就打开它；勾选可以批量删除，删了就找不回来。</div>`,
    actions: [{ label: '关闭', primary: true }],
  });

  /* ── 勾选 / 批量删除 ── */
  const refreshSel = () => {
    const checks = [...root.querySelectorAll('[data-check]')];
    const n = checks.filter((c) => c.checked).length;
    const cnt = root.querySelector('#proj-count');
    if (cnt) cnt.textContent = `已选 ${n} / ${checks.length} 张`;
    const btn = root.querySelector('#proj-del-sel');
    if (btn) btn.disabled = n === 0;
    const all = root.querySelector('#proj-all');
    if (all) all.checked = n > 0 && n === checks.length;
  };

  const removeProjects = async (ids) => {
    const deletedCurrent = ids.includes(state.project?.id);
    let okCount = 0;
    for (const id of ids) {
      try {
        await api.deleteProject(id);
        root.querySelector(`.proj-item[data-pid="${id}"]`)?.remove();
        okCount++;
      } catch (e) {
        toast(`删除失败：${e.message}`, 'err');
      }
    }
    if (deletedCurrent) resetToBlank();
    refreshSel();
    if (!root.querySelector('[data-check]')) {
      const listEl = root.querySelector('.proj-list');
      if (listEl) listEl.outerHTML = `<div class="set-hint">画布列表空了。</div>`;
    }
    toast(`已删除 ${okCount} 张画布`, okCount ? 'ok' : 'warn', 2000);
  };

  root.querySelectorAll('[data-check]').forEach((c) => {
    c.onchange = refreshSel;
  });

  const allBox = root.querySelector('#proj-all');
  if (allBox) {
    allBox.onchange = () => {
      root.querySelectorAll('[data-check]').forEach((c) => (c.checked = allBox.checked));
      refreshSel();
    };
  }

  const delSel = root.querySelector('#proj-del-sel');
  if (delSel) {
    delSel.onclick = async () => {
      const ids = [...root.querySelectorAll('[data-check]')].filter((c) => c.checked).map((c) => c.dataset.check);
      if (!ids.length) return;
      if (!confirm(`删除选中的 ${ids.length} 张画布？删了就找不回来了。`)) return;
      await removeProjects(ids);
    };
  }

  const delAll = root.querySelector('#proj-del-all');
  if (delAll) {
    delAll.onclick = async () => {
      const ids = [...root.querySelectorAll('[data-check]')].map((c) => c.dataset.check);
      if (!ids.length) return;
      if (!confirm(`确定删除全部 ${ids.length} 张画布？这个操作不可恢复。`)) return;
      await removeProjects(ids);
    };
  }

  root.querySelectorAll('[data-pid]').forEach((el) => {
    el.onclick = async (e) => {
      // 点勾选框 / 删除按钮不算「打开」
      if (e.target.closest('[data-del], input, button')) return;
      // 打开别的画布会替换当前这张 —— 有未保存改动先问
      if (el.dataset.pid !== state.project?.id) {
        const choice = await confirmUnsaved('打开这张画布');
        if (choice === 'cancel') return;
        if (choice === 'save') {
          const ok = await saveCanvasNow().catch(() => false);
          if (!ok) return toast('保存失败，先别切走', 'err', 4000);
        }
      }
      try {
        const r = await api.getProject(el.dataset.pid);
        clearHistory();
        applyProject(r.project);
        renderAll();
        const b = getBounds();
        if (b) fitBounds(b, { padding: 110, maxScale: 1 });
        state.dirty = false;
        setSaveState('saved', '已打开');
        closeModal();
        toast(`已打开：${r.project?.title || ''}`, 'ok');
      } catch (err) {
        toast(err.message, 'err');
      }
    };
  });

  root.querySelectorAll('[data-del]').forEach((btn) => {
    btn.onclick = async (e) => {
      e.stopPropagation();
      const id = btn.dataset.del;
      const isCur = id === state.project?.id;
      const msg = isCur
        ? '这是当前打开的这张画布，删除后会自动给你一张空白的新画布。确定删除？'
        : '删除这张画布？删了就找不回来了。';
      if (!confirm(msg)) return;
      try {
        await api.deleteProject(id);
        btn.closest('.proj-item')?.remove();
        toast('已删除', 'ok', 1600);
        if (isCur) resetToBlank();
      } catch (err) {
        toast(err.message, 'err');
      }
    };
  });
}

/** 保存到用户自己选的位置（浏览器支持「另存为」对话框时用它） */
async function saveToFile() {
  if (!state.project) return;
  state.project.view = { ...state.view };
  const data = JSON.stringify({ ...state.project, updatedAt: Date.now() }, null, 2);
  const base = String(state.project.title || '豆包2.0 Fast 免费额度专用画布')
    .replace(/[\\/:*?"<>|\s]+/g, '_')
    .slice(0, 60);
  const name = `${base || '豆包2.0 Fast 免费额度专用画布'}.json`;

  if (window.showSaveFilePicker) {
    try {
      const handle = await window.showSaveFilePicker({
        suggestedName: name,
        types: [{ description: '豆包2.0 Fast 免费额度专用画布', accept: { 'application/json': ['.json'] } }],
      });
      const w = await handle.createWritable();
      await w.write(data);
      await w.close();
      state.dirty = false;
      setSaveState('saved', `已保存 · ${handle.name}`);
      toast(`已保存：${handle.name}`, 'ok', 3500);
      return;
    } catch (e) {
      if (e?.name === 'AbortError') return; // 用户点了取消
      console.warn('另存为失败，退回下载', e);
    }
  }

  download(name, data, 'application/json');
  state.dirty = false;
  setSaveState('saved', '已下载');
  toast('这个浏览器不支持选目录，已下载到默认下载文件夹', 'warn', 4500);
}

function importProject() {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = '.json,application/json';
  input.onchange = async () => {
    const f = input.files?.[0];
    if (!f) return;
    // 导入会替换当前画布，有未保存改动先问
    const choice = await confirmUnsaved('导入这个文件');
    if (choice === 'cancel') return;
    if (choice === 'save') {
      const ok = await saveCanvasNow().catch(() => false);
      if (!ok) return toast('保存失败，先别导入', 'err', 4000);
    }
    try {
      const p = JSON.parse(await f.text());
      clearHistory();
      applyProject(normalizeProject(p));
      renderAll();
      const b = getBounds();
      if (b) fitBounds(b, { padding: 110, maxScale: 1 });
      state.dirty = false;
      setSaveState('saved', '已打开 · ' + f.name);
      toast('已打开：' + f.name, 'ok');
    } catch (e) {
      toast(`导入失败：${e.message}`, 'err');
    }
  };
  input.click();
}

/* ───────────────────────── 示例 ───────────────────────── */
function loadSample(force = false) {
  if (!force && state.project?.nodes.length && !confirm('载入示例会替换当前画布内容，继续？')) return;
  const p = blankProject('雨夜 · 第一话（示例）');
  const textId = 'n_demo_text';
  const charId = 'n_demo_char';
  const sceneId = 'n_demo_scene';
  const propId = 'n_demo_prop';

  p.nodes = [
    {
      id: textId,
      type: 'text',
      x: 500,
      y: 60,
      w: 420,
      data: {
        text: '林小雨（@人物1）站在便利店门口的雨里（@场景1），手里攥着那把红伞（@道具1），抬头看霓虹招牌，雨水顺着发梢滴落。冷蓝色调，招牌的暖光打亮半张脸，镜头缓慢推近。',
        duration: 5,
        ratio: '16:9',
        videoUrl: '',
        meta: '',
      },
    },
    {
      id: charId,
      type: 'image',
      x: 40,
      y: 40,
      w: 292,
      data: { kind: 'character', name: '林小雨', url: '', note: '' },
    },
    {
      id: sceneId,
      type: 'image',
      x: 40,
      y: 330,
      w: 292,
      data: { kind: 'scene', name: '便利店门口 · 雨夜', url: '', note: '' },
    },
    {
      id: propId,
      type: 'image',
      x: 40,
      y: 620,
      w: 292,
      data: { kind: 'prop', name: '红伞', url: '', note: '' },
    },
  ];
  p.edges = [];
  p.settings.style = '日式赛璐璐动画风，干净线稿，冷蓝夜景，电影级光影';
  clearHistory();
  applyProject(p);
  renderAll();
  const b = getBounds();
  if (b) fitBounds(b, { padding: 100, maxScale: 0.95 });
  state.dirty = true;
  setSaveState('dirty', '未保存');
  toast('示例已载入：三张图先上传，再点文本卡的「出视频」', 'ok', 4200);
}

/* ───────────────────────── 帮助 ───────────────────────── */
function showHelp() {
  showModal({
    title: '快捷键 & 使用说明',
    html: `
      <table class="kbd-table">
        <tr><td>「保存」按钮</td><td>把当前画布存进「画布」列表。<b>不会自动保存</b>，什么时候存由你决定</td></tr>
        <tr><td>「新建」「打开」「导入」</td><td>如果当前画布有未保存的改动，会先问你要不要存</td></tr>
        <tr><td>关闭页面 / 刷新</td><td>有未保存的改动时浏览器会拦一下确认</td></tr>
        <tr><td><kbd>滚轮</kbd></td><td>以光标为中心缩放</td></tr>
        <tr><td><kbd>空格</kbd> / 中键 / 右键 + 拖</td><td>平移画布</td></tr>
        <tr><td><kbd>Shift</kbd> + 拖空白</td><td>框选多个节点</td></tr>
        <tr><td><kbd>右键</kbd> 空白</td><td>弹出添加菜单（文本 / 人物图 / 场景图 / 道具图），点哪个就在光标处加哪个</td></tr>
        <tr><td><kbd>右键拖</kbd></td><td>平移画布（按住不放拖，跟单击右键不冲突）</td></tr>
        <tr><td><kbd>双击</kbd> 空白</td><td>原地新建一张文本卡</td></tr>
        <tr><td>拖动右侧圆点 → 另一节点</td><td>连线（接进文本卡的图片会被引用）</td></tr>
        <tr><td>鼠标移到连线上 → 点中点的 <b>×</b></td><td>删掉这条连线（也可以点线选中后按 Delete）</td></tr>
        <tr><td>点两个「文本」之间连线上的开关</td><td><b>尾帧→首帧</b>：上一段视频的最后一帧会自动成为下一段的开头</td></tr>
        <tr><td><kbd>Delete</kbd></td><td>删除选中的节点 / 连线</td></tr>
        <tr><td><kbd>Ctrl</kbd>+<kbd>D</kbd></td><td>复制选中节点</td></tr>
        <tr><td><kbd>Ctrl</kbd>+<kbd>Z</kbd></td><td>撤销（打字/拖动/增删节点都能撤，打字算一步）</td></tr>
        <tr><td><kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>Z</kbd></td><td>重做（也可以 Ctrl+Y）</td></tr>
        <tr><td><kbd>Ctrl</kbd>+<kbd>S</kbd></td><td>保存画布（会弹出「另存为」让你选位置）</td></tr>
        <tr><td><kbd>Ctrl</kbd>+<kbd>O</kbd></td><td>打开之前保存的画布文件</td></tr>
        <tr><td><kbd>F</kbd></td><td>适应画布</td></tr>
        <tr><td><kbd>0</kbd></td><td>缩放回 100%</td></tr>
        <tr><td><kbd>Esc</kbd></td><td>取消选择 / 关闭弹窗</td></tr>
      </table>
      <div class="set-hint" style="margin-top:10px">
        三种节点：<b>文本</b>（就是发给视频模型的提示词，带「出视频」）、
        <b>图片</b>（人物图 / 场景图 / 道具图）。<br />
        每个节点右侧有个 ✎ 拉手，点一下能拉出注释框，给自己写备注（不会发给模型）。<br />
        文本节点右侧还有 <b>首</b> / <b>尾</b> 两个拉手：分别设置这一段的首帧、尾帧参考图（上传，或从图片节点里选）。<br />
        图片没有「生成」按钮——你上传什么，模型就用什么。<br />
        引用图片有两种方式：正文里写 <code>@人物1</code>、<code>@场景2</code>、<code>@道具1</code>，
        或者把图片节点连线到文本卡。引用只影响提示词里的描述，<b>不会自动变成首帧</b>——首帧要用「首」拉手单独设置。<br />
        点文本卡上的「提示词」可以看到最终发出去的文本（@引用会自动剥掉）。
      </div>`,
    actions: [{ label: '知道了', primary: true }],
  });
}

/* ───────────────────────── 键盘 ───────────────────────── */
function onKeyDown(e) {
  const typing = ['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName) || e.target.isContentEditable;
  const mod = e.ctrlKey || e.metaKey;

  if (e.key === 'Escape') {
    closeModal();
    $('#menu-pop').hidden = true;
    clearSelection();
    return;
  }
  if (typing) return;

  if (e.key === 'Delete' || e.key === 'Backspace') {
    e.preventDefault();
    deleteSelection();
  } else if (mod && e.key.toLowerCase() === 's') {
    e.preventDefault();
    saveToFile();
  } else if (mod && e.key.toLowerCase() === 'o') {
    e.preventDefault();
    importProject();
  } else if (mod && e.key.toLowerCase() === 'z') {
    e.preventDefault();
    const did = e.shiftKey ? redo() : undo();
    if (!did) toast(e.shiftKey ? '没有可重做的操作' : '没有可撤销的操作', 'warn', 1500);
  } else if (mod && e.key.toLowerCase() === 'y') {
    e.preventDefault();
    if (!redo()) toast('没有可重做的操作', 'warn', 1500);
  } else if (mod && e.key.toLowerCase() === 'd') {
    e.preventDefault();
    duplicateSelection();
  } else if (mod && e.key.toLowerCase() === 'a') {
    e.preventDefault();
    selectOnly(state.project.nodes.map((n) => n.id));
  } else if (e.key === 'f' || e.key === 'F') {
    const b = getBounds();
    if (b) fitBounds(b, { padding: 110, maxScale: 1 });
  } else if (e.key === '0') {
    setZoom(1);
  } else if (e.key === '1') {
    setZoom(1);
  } else if (e.key === '?' || (e.key === '/' && e.shiftKey)) {
    showHelp();
  } else if (e.key === '=' || e.key === '+') {
    setZoom(state.view.k * 1.2);
  } else if (e.key === '-') {
    setZoom(state.view.k / 1.2);
  }
}

boot().catch((e) => {
  console.error(e);
  toast(`启动失败：${e.message}`, 'err', 8000);
});

/* ───────────────────────── 选中浮动条 ───────────────────────── */
function refreshSelBar() {
  const bar = $('#sel-bar');
  if (!bar) return;
  const ids = selectedIds();
  const n = ids.length;
  if (!n) {
    bar.hidden = true;
    return;
  }
  bar.hidden = false;
  const count = $('#sel-count');
  if (count) count.textContent = `已选 ${n} 个`;
  const hasText = (state.project?.nodes || []).some((x) => ids.includes(x.id) && x.type === 'text');
  const gen = $('#sel-gen');
  if (gen) gen.hidden = !hasText;
}

on('selection:changed', refreshSelBar);
on('project:loaded', refreshSelBar);

function wireSelBar() {
  refreshSelBar();
  $('#sel-gen')?.addEventListener('click', async () => {
    const ids = selectedIds();
    if (!ids.length) return;
    await generateAll(ids);
  });
  $('#sel-dup')?.addEventListener('click', () => {
    if (selectedIds().length) duplicateSelection();
  });
  $('#sel-del')?.addEventListener('click', () => {
    if (selectedIds().length) deleteSelection();
  });
  $('#sel-clear')?.addEventListener('click', () => clearSelection());
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', wireSelBar);
} else {
  wireSelBar();
}

// Ctrl/Cmd+A 全选、Esc 取消选择
document.addEventListener('keydown', (e) => {
  const t = e.target;
  const typing = t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable);
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'a' && !typing) {
    e.preventDefault();
    if (state.project?.nodes?.length) selectOnly(state.project.nodes.map((n) => n.id));
    return;
  }
  if (e.key === 'Escape' && !typing && selectedIds().length) {
    clearSelection();
  }
});

/* ───────────────────────── 节点搜索 ───────────────────────── */
function nodeSearchText(n) {
  const parts = [];
  if (n.kind === 'image') parts.push(n.data?.name || '', n.data?.handle || '');
  parts.push(n.data?.text || '');
  const t = String(n.data?.text || '').replace(/\s+/g, ' ').trim();
  if (t) parts.push(t.slice(0, 40));
  return parts.join(' ').toLowerCase();
}

function renderSearchPop(q) {
  const pop = $('#search-pop');
  if (!pop) return;
  const s = String(q || '').trim().toLowerCase();
  if (!s) {
    pop.hidden = true;
    pop.innerHTML = '';
    return;
  }
  const hits = (state.project?.nodes || []).filter((n) => nodeSearchText(n).includes(s)).slice(0, 8);
  if (!hits.length) {
    pop.hidden = false;
    pop.innerHTML = '<div class="search-empty">没有匹配的节点</div>';
    return;
  }
  const kindLabel = (n) => (n.kind === 'image' ? n.data?.kind === 'scene' ? '场景' : n.data?.kind === 'prop' ? '道具' : '人物' : '文本');
  const label = (n) => {
    if (n.kind === 'image') return (n.data?.name || '').trim() || '图片节点';
    const t = String(n.data?.text || '').replace(/\s+/g, ' ').trim();
    return t ? t.slice(0, 30) : '（空提示词）';
  };
  pop.hidden = false;
  pop.innerHTML = hits
    .map(
      (n, i) => `<div class="search-item" data-hit="${i}">
        <span class="si-kind">${kindLabel(n)}</span>
        <span class="si-text">${esc(label(n))}</span>
      </div>`,
    )
    .join('');

  pop.querySelectorAll('[data-hit]').forEach((el) => {
    el.onclick = () => {
      const n = hits[Number(el.dataset.hit)];
      if (!n) return;
      panToNode(n.id);
      selectOnly([n.id]);
      pop.hidden = true;
      const input = $('#node-search');
      if (input) input.value = '';
    };
  });
}

function wireNodeSearch() {
  const input = $('#node-search');
  if (!input) return;
  input.addEventListener('input', () => renderSearchPop(input.value));
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      input.value = '';
      renderSearchPop('');
      input.blur();
      return;
    }
    if (e.key === 'Enter') {
      const first = $('#search-pop .search-item');
      if (first) first.click();
    }
  });
  input.addEventListener('blur', () => {
    setTimeout(() => {
      const pop = $('#search-pop');
      if (pop) pop.hidden = true;
    }, 150);
  });
  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'f') {
      e.preventDefault();
      input.focus();
      input.select();
    }
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', wireNodeSearch);
} else {
  wireNodeSearch();
}

/* 小地图 */
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => initMinimap());
} else {
  initMinimap();
}

/** 整集导出：镜头按画布顺序打包成 zip（清单 + 视频） */
async function exportEpisode() {
  const nodes = state.project?.nodes || [];
  const shots = nodes
    .filter((n) => n.type === 'text')
    .map((n) => ({
      title: (String(n.data?.text || '').replace(/\s+/g, ' ').trim() || '空镜头').slice(0, 40),
      prompt: String(n.data?.text || ''),
      duration: Number(n.data?.duration) || Number(state.project?.settings?.duration) || 5,
      ratio: n.data?.ratio || state.project?.settings?.ratio || '',
      videoUrl: n.data?.videoUrl || '',
      x: n.x || 0,
      y: n.y || 0,
    }));
  if (!shots.length) {
    toast('画布上还没有文本镜头', 'warn', 3000);
    return;
  }
  const withVideo = shots.filter((x) => x.videoUrl).length;
  toast(`正在打包 ${shots.length} 个镜头（已出片 ${withVideo} 个）…`, '', 3000);
  try {
    const res = await fetch('/api/export-episode', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ title: state.project?.title || '未命名画布', shots }),
    });
    if (!res.ok) {
      const t = await res.json().catch(() => ({}));
      throw new Error(t.error || `HTTP ${res.status}`);
    }
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${(state.project?.title || '整集').slice(0, 30)}-${new Date().toISOString().slice(0, 10)}.zip`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
    toast(`已导出 ${shots.length} 个镜头`, 'ok', 3500);
  } catch (e) {
    toast('导出失败：' + e.message, 'err', 4000);
  }
}

/** 检查更新：读 config.update.url 指向的 JSON */
async function checkUpdate() {
  toast('正在检查版本…', '', 2000);
  try {
    const r = await fetch('/api/version?check=1').then((x) => x.json());
    if (r.checkError) {
      toast(`当前版本 ${r.version} · ${r.checkError}`, 'warn', 5000);
      return;
    }
    if (!r.latest) {
      toast(`当前版本 ${r.version}（没有可比较的版本信息）`, '', 3500);
      return;
    }
    if (!r.outdated) {
      toast(`已是最新版 ${r.version}`, 'ok', 3500);
      return;
    }

    const yes = confirm(
      `有新版本 ${r.latest}（当前 ${r.version}）\n\n${r.notes || ''}\n\n` +
        '现在更新吗？\n\n会保留：账号配置、画布、登录态\n更新完需要重启一次（start-all.bat）',
    );
    if (!yes) return;

    toast('正在下载更新，别关窗口…', '', 60000);
    const res = await fetch('/api/update/apply', { method: 'POST' }).then((x) => x.json());
    if (!res.ok) throw new Error(res.error || '更新失败');
    toast(`已更新到 ${res.version || r.latest}（${res.copied} 个文件），请重启程序`, 'ok', 12000);
    alert('更新完成。\n\n请关掉黑窗口（Ctrl+C），再双击 start-all.bat 重新启动。');
  } catch (e) {
    toast('检查更新失败：' + e.message, 'err', 4000);
  }
}

/* ───────────────────────── 我的画风（全局预设） ───────────────────────── */
let stylePresets = [];

async function loadStyles() {
  try {
    const r = await fetch('/api/styles').then((x) => x.json());
    stylePresets = Array.isArray(r.items) ? r.items : [];
  } catch {
    stylePresets = [];
  }
  renderStylePick();
}

function renderStylePick() {
  const sel = $('#style-pick');
  if (!sel) return;
  const cur = sel.value;
  sel.innerHTML =
    '<option value="">— 我的画风 —</option>' +
    stylePresets.map((p, i) => `<option value="${i}">${esc(p.name)}</option>`).join('');
  if (cur && Number(cur) < stylePresets.length) sel.value = cur;
  const del = $('#style-del');
  if (del) del.disabled = !sel.value;
}

function wireStyleActions() {
  const sel = $('#style-pick');
  const ta = document.querySelector('textarea[data-set="style"]');
  if (!sel || !ta) return;

  loadStyles();

  // 选一个常用画风 → 填进输入框（同时写进项目设置）
  sel.onchange = () => {
    const p = stylePresets[Number(sel.value)];
    if (!p) {
      const del = $('#style-del');
      if (del) del.disabled = true;
      return;
    }
    ta.value = p.text;
    ta.dispatchEvent(new Event('input', { bubbles: true }));
    const del = $('#style-del');
    if (del) del.disabled = false;
    toast(`已套用画风「${p.name}」`, 'ok', 2200);
  };

  // 存为常用
  $('#style-save')?.addEventListener('click', async () => {
    const text = String(ta.value || '').trim();
    if (!text) {
      toast('先在上面写一段画风，再存', 'warn', 3000);
      return;
    }
    const name = prompt('给这段画风起个名字（比如「日式赛璐璐」）：', text.slice(0, 8));
    if (!name) return;
    try {
      const r = await fetch('/api/styles', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ name: name.trim().slice(0, 20), text }),
      }).then((x) => x.json());
      if (!r.ok) throw new Error(r.error || '保存失败');
      stylePresets = r.items || [];
      renderStylePick();
      toast('已存进「我的画风」', 'ok', 2500);
    } catch (e) {
      toast('保存失败：' + e.message, 'err', 3500);
    }
  });

  // 删除
  $('#style-del')?.addEventListener('click', async () => {
    const p = stylePresets[Number(sel.value)];
    if (!p) return;
    if (!confirm(`删掉画风「${p.name}」？`)) return;
    try {
      await fetch('/api/styles/delete', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ name: p.name }),
      });
      sel.value = '';
      await loadStyles();
      toast('已删除', 'ok', 2000);
    } catch (e) {
      toast('删除失败：' + e.message, 'err', 3000);
    }
  });
}

// 设置面板每次重绘都会重建这些元素 —— 由 wireSide 在渲染后调用 wireStyleActions()

/* ───────────────────────── 购买卡密 ───────────────────────── */
async function openShop() {
  let shop = null;
  try {
    shop = await fetch('/api/shop').then((r) => r.json());
  } catch (e) {
    toast('读取套餐失败：' + e.message, 'err', 3000);
    return;
  }
  if (!shop || !shop.enabled) {
    toast('还没有配置套餐（config.json 里的 shop）', 'warn', 3500);
    return;
  }

  const items = shop.items || [];
  let picked = items[0];

  const m = document.createElement('div');
  m.className = 'modal-root';
  m.innerHTML = `
    <div class="modal shop-modal">
      <div class="modal-head">购买 / 续费卡密<button class="x" data-close>×</button></div>
      <div class="modal-body">
        <div class="shop-plans">
          ${items
            .map(
              (it, i) => `<button class="plan${i === 0 ? ' on' : ''}" data-plan="${i}">
                <b>${esc(it.label)}</b><span>¥ ${esc(it.price)}</span>
              </button>`,
            )
            .join('')}
        </div>

        <div class="shop-pay">
          <div class="shop-amount">¥ <b id="shop-price">${esc(picked.price)}</b><span id="shop-label">${esc(picked.label)}</span></div>
          <div class="shop-channels" id="shop-channels">
            ${(shop.channels || [])
              .map(
                (c, i) =>
                  `<button class="chan${i === 0 ? ' on' : ''}" data-chan="${esc(c.id)}">${esc(c.label)}</button>`,
              )
              .join('')}
          </div>
          <div id="shop-qr-box"></div>
          <div class="shop-tip">
            扫码付款 → 点下面的按钮 → 把这段发给作者 → 收到卡密后粘进输入框
          </div>
        </div>

        <div class="shop-order" id="shop-order" hidden>
          <textarea rows="4" readonly id="shop-order-text"></textarea>
          <button class="btn primary" id="shop-copy">复制订单信息</button>
        </div>

        <div class="shop-activate">
          <input id="shop-key" placeholder="把作者发你的卡密粘在这里" spellcheck="false" />
          <button class="btn primary" id="shop-act">激活</button>
        </div>
        <div class="shop-hint" id="shop-hint">${esc(shop.contact || '')}${shop.payNote ? '<br />' + esc(shop.payNote) : ''}</div>
      </div>
    </div>`;
  document.body.appendChild(m);

  let channel = (shop.channels && shop.channels[0]) || { id: 'alipay', label: '支付宝', hasQr: false };

  const renderShopQr = () => {
    const box = m.querySelector('#shop-qr-box');
    if (!box) return;
    box.innerHTML = channel.hasQr
      ? `<img class="shop-qr" src="/api/shop/qr?channel=${encodeURIComponent(channel.id)}&t=${Date.now()}" alt="${esc(channel.label)}收款码" />`
      : `<div class="shop-noqr">还没有放${esc(channel.label)}收款码<br /><small>把图片存成 <code>config/${channel.id === 'wechat' ? 'wechat' : 'alipay'}-qr.png</code></small></div>`;
  };
  renderShopQr();

  m.querySelectorAll('[data-chan]').forEach((b) => {
    b.onclick = () => {
      m.querySelectorAll('[data-chan]').forEach((x) => x.classList.remove('on'));
      b.classList.add('on');
      channel = (shop.channels || []).find((c) => c.id === b.dataset.chan) || channel;
      renderShopQr();
      m.querySelector('#shop-order').hidden = true;
    };
  });

  const close = () => m.remove();
  m.addEventListener('click', (e) => {
    if (e.target === m) close();
    if (e.target.closest('[data-close]')) close();
  });

  let pendingPay = null; // { id, amount }

  const orderText = () => {
    const id = 'ORD-' + Math.random().toString(36).slice(2, 6).toUpperCase() + Math.random().toString(36).slice(2, 6).toUpperCase();
    const base = Number(picked.price) || 0;
    // 尾数法：加 1~9 分钱随机尾数 → 作者看到 9.93 到账就知道是这单
    const cents = shop.uniqueAmount ? 1 + Math.floor(Math.random() * 9) : 0;
    const amount = (Math.round(base * 100 + cents) / 100).toFixed(2);
    pendingPay = { id, amount };

    const lines = [
      '订单 ' + id,
      '机器码 ' + (shop.machineCode || '（未读到）'),
      '套餐 ' + picked.label + '（原价 ¥' + base + '）',
      '应付 ¥' + amount + (cents ? '（含 ' + cents + ' 分钱尾数，方便对账）' : ''),
      '付款方式 ' + channel.label,
    ];
    const curExp = Number(state.license?.expiresAt) || 0;
    if (curExp) {
      const dstr = new Date(curExp).toLocaleDateString('zh-CN');
      if (curExp > Date.now()) {
        lines.push('当前到期 ' + dstr + '（续费请从这天往后加）');
      } else {
        lines.push('上一张到期 ' + dstr + '（已过期，续费从今天算）');
      }
    } else if (state.license?.hasCard) {
      lines.push('上一张是永久卡');
    } else {
      lines.push('还没有卡（新买）');
    }
    if (shop.payNote) lines.push('备注 ' + id.slice(-4) + '（付款时填在备注里）');
    lines.push('已付款，请核对到账后发我卡密，谢谢');
    return lines.join('\n');
  };

  // 选套餐
  m.querySelectorAll('[data-plan]').forEach((b) => {
    b.onclick = () => {
      m.querySelectorAll('[data-plan]').forEach((x) => x.classList.remove('on'));
      b.classList.add('on');
      picked = items[Number(b.dataset.plan)];
      m.querySelector('#shop-price').textContent = picked.price;
      m.querySelector('#shop-label').textContent = picked.label;
      m.querySelector('#shop-order').hidden = true;
    };
  });

  // 我已付款 → 显示订单信息
  const pay = document.createElement('button');
  pay.className = 'btn shop-paid';
  pay.textContent = '我已付款，生成订单信息';
  m.querySelector('.shop-pay').appendChild(pay);
  pay.onclick = () => {
    const box = m.querySelector('#shop-order');
    box.hidden = false;
    m.querySelector('#shop-order-text').value = orderText();
    const hint = m.querySelector('#shop-hint');
    if (hint && pendingPay) {
      hint.innerHTML =
        '请按上面的金额付款（<b>¥' + pendingPay.amount + '</b>），备注写 <b>' +
        pendingPay.id.slice(-4) +
        '</b>，然后点「复制订单信息」发给作者。' +
        (shop.contact ? '<br />' + esc(shop.contact) : '');
    }
    m.querySelector('#shop-copy').focus();
  };

  m.querySelector('#shop-copy').onclick = async () => {
    const ta = m.querySelector('#shop-order-text');
    try {
      await navigator.clipboard.writeText(ta.value);
      toast('订单信息已复制，发给作者就行', 'ok', 3000);
    } catch {
      ta.select();
      document.execCommand('copy');
      toast('已复制', 'ok', 2000);
    }
  };

  // 粘卡密激活
  m.querySelector('#shop-act').onclick = async () => {
    const key = String(m.querySelector('#shop-key').value || '').trim();
    if (!key) return toast('先把卡密粘进来', 'warn', 2500);
    try {
      const r = await api.activateLicense(key);
      if (!r.ok) throw new Error(r.error || '激活失败');
      toast('激活成功', 'ok', 2500);
      close();
      location.reload();
    } catch (e) {
      toast(e.message, 'err', 4000);
    }
  };
}
