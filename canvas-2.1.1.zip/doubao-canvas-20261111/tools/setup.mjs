/**
 * 首次配置向导：问你有几个豆包账号，生成 config/config.json
 *
 *   node tools/setup.mjs            交互式
 *   node tools/setup.mjs --n=3      直接指定 3 个账号
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import readline from 'node:readline/promises';
import { stdin, stdout } from 'node:process';
import { CONFIG_DIR } from '../lib/paths.mjs';

const CONFIG = path.join(CONFIG_DIR, 'config.json');
const EXAMPLE = path.join(CONFIG_DIR, 'config.example.json');
const BASE_PORT = 8788;

const arg = process.argv.find((a) => a.startsWith('--n='));
let n = arg ? Number(arg.split('=')[1]) : 0;

if (!n) {
  console.log('');
  console.log('  首次配置');
  console.log('  ────────────────────────────────');
  console.log('  一个豆包账号每天有 30 秒免费视频额度。');
  console.log('  你有几个账号？（1-15，越多额度越多）');
  console.log('');
  const rl = readline.createInterface({ input: stdin, output: stdout });
  const answer = await rl.question('  账号数量：');
  rl.close();
  n = Number(String(answer).trim());
}

if (!Number.isFinite(n) || n < 1 || n > 15) {
  console.log('  需要一个 1~15 之间的数字。');
  process.exit(1);
}

let base = {};
try {
  base = JSON.parse(await fs.readFile(EXAMPLE, 'utf8'));
} catch {
  base = { defaults: { videoDuration: 5, videoRatio: '16:9' }, provider: {}, pool: {} };
}

base.provider = base.provider || {};
base.provider.pollMs = base.provider.pollMs || 2000;
base.provider.timeoutMs = base.provider.timeoutMs || 900000;
base.provider.bridges = Array.from({ length: n }, (_, i) => ({
  id: `web-${String(i + 1).padStart(2, '0')}`,
  label: `豆包${i + 1}`,
  url: `http://127.0.0.1:${BASE_PORT + i}`,
  dailySeconds: 30,
  kinds: ['video'],
  enabled: true,
}));
base.update = base.update || { url: '' };
  base.pool = { jobConcurrency: Math.min(4, n), maxAttempts: 2 };

await fs.mkdir(CONFIG_DIR, { recursive: true });
await fs.writeFile(CONFIG, JSON.stringify(base, null, 2) + '\n', 'utf8');

console.log('');
console.log(`  已生成配置：${n} 个账号，端口 ${BASE_PORT}~${BASE_PORT + n - 1}`);
console.log(`  文件：${CONFIG}`);
console.log(`  每天可用额度：${n * 30} 秒`);
console.log('');
console.log('  下一步：');
console.log('    1. 双击 start-all.bat（会弹出一个黑窗口，别关）');
console.log('    2. 浏览器会打开画布');
console.log('    3. 右侧「额度」里点「一键登录」，逐个扫码登录豆包');
console.log('    4. 扫完就能出片了');
console.log('');
