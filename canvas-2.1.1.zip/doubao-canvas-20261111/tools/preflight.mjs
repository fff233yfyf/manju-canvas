/**
 * 启动前端口体检：node tools/preflight.mjs
 *
 * 检查画布端口(8787)、每个账号桥的端口(8788+)、以及浏览器调试端口(9222+)，
 * 把「被别的程序占了」这种情况在启动前就说清楚，而不是让客户对着白屏猜。
 */
import fs from 'node:fs/promises';
import net from 'node:net';
import path from 'node:path';
import { CONFIG_FILE } from '../lib/paths.mjs';

const CANVAS_PORT = Number(process.env.PORT || 8787);
const BASE_BRIDGE_PORT = 8788;
const BASE_DEBUG_PORT = 9222;

const ok = (m, e = '') => ({ level: 'ok', m, e });
const warn = (m, e = '') => ({ level: 'warn', m, e });
const bad = (m, e = '') => ({ level: 'bad', m, e });
const out = [];

/** 端口上有没有人在监听 */
function inUse(port, host = '127.0.0.1') {
  return new Promise((res) => {
    const s = net.connect({ port, host, timeout: 900 });
    s.once('connect', () => {
      s.destroy();
      res(true);
    });
    s.once('timeout', () => {
      s.destroy();
      res(false);
    });
    s.once('error', () => res(false));
  });
}

async function getJson(url, ms = 1200) {
  try {
    return await fetch(url, { signal: AbortSignal.timeout(ms) }).then((r) => r.json());
  } catch {
    return null;
  }
}

/* ── 画布端口 ── */
const canvasAlive = await getJson(`http://127.0.0.1:${CANVAS_PORT}/api/health`);
if (canvasAlive?.ok) {
  out.push(ok(`画布端口 ${CANVAS_PORT}：已经在运行`, '这次启动会直接用它，不会重复开'));
} else if (await inUse(CANVAS_PORT)) {
  out.push(
    bad(
      `画布端口 ${CANVAS_PORT} 被别的程序占用了`,
      '关掉占用它的程序（常见是另一个画布/其它网页服务），或者重启电脑再试'
    )
  );
} else {
  out.push(ok(`画布端口 ${CANVAS_PORT}：空闲`));
}

/* ── 账号桥端口 ── */
let bridges = [];
try {
  const cfg = JSON.parse(await fs.readFile(CONFIG_FILE, 'utf8'));
  bridges = (cfg.provider?.bridges || []).filter((b) => b.enabled !== false);
} catch {
  out.push(bad(`读不到配置：${path.basename(CONFIG_FILE)}`, '先双击「初始化配置.bat」'));
}

const portOf = (url) => Number(String(url || '').split(':').pop()) || 0;

let conflicts = 0;
let bridgesRunning = 0;
const bridgeIssues = [];

for (let i = 0; i < bridges.length; i++) {
  const b = bridges[i];
  const bp = portOf(b.url) || BASE_BRIDGE_PORT + i;
  const dp = BASE_DEBUG_PORT + i;
  const label = b.label || b.id || `账号 ${i + 1}`;

  const alive = await getJson(`http://127.0.0.1:${bp}/health`, 900);
  if (alive?.ok) {
    bridgesRunning++;
  } else if (await inUse(bp)) {
    conflicts++;
    bridgeIssues.push(bad(`${label} 桥端口 ${bp} 被别的程序占用`, `改 config\\config.json 里这个账号的 url 端口，或关掉占用它的程序`));
  }

  // 调试端口被占（常见：有人开过 Chrome 调试）
  if (!alive?.ok && (await inUse(dp)) && !(await getJson(`http://127.0.0.1:${dp}/json/version`, 900))) {
    bridgeIssues.push(warn(`浏览器调试端口 ${dp} 被占用`, `${label} 可能起不来：关掉占用它的程序（常见是另一个开着调试端口的 Chrome/Edge）`));
  }
}

if (bridges.length && !bridgeIssues.length) {
  const where = bridgesRunning === bridges.length ? '全都在运行' : bridgesRunning === 0 ? '全部空闲，待启动' : `${bridgesRunning} 个在运行，其余待启动`;
  out.push(ok(`${bridges.length} 个账号桥端口（${BASE_BRIDGE_PORT}~${BASE_BRIDGE_PORT + bridges.length - 1}）：${where}`));
} else {
  out.push(...bridgeIssues);
}

if (!bridges.length) {
  out.push(warn('配置里没有启用的账号', '配置里一个账号都没开，出片会失败'));
}

/* ── 输出 ── */
const icon = { ok: '✅', warn: '⚠️ ', bad: '❌' };
console.log('');
console.log('  启动前检查');
console.log('  ' + '─'.repeat(50));
for (const r of out) {
  console.log(`  ${icon[r.level]} ${r.m}`);
  if (r.e) console.log(`      ${r.e}`);
}
console.log('  ' + '─'.repeat(50));

const hasBad = out.some((r) => r.level === 'bad');
if (hasBad) {
  console.log('  ❌ 有端口冲突，先按上面的提示处理再启动。');
  process.exit(1);
}
const hasWarn = out.some((r) => r.level === 'warn');
console.log(hasWarn ? '  ⚠️ 有提醒，但可以先启动试试。' : '  ✅ 端口都正常。');
process.exit(0);
