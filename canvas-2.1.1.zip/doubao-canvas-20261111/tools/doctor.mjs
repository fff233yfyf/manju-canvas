/**
 * 环境自检：node 检查环境.mjs
 *
 * 一次性告诉用户：Node 版本、浏览器、配置、端口、授权、目录权限有没有问题。
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import net from 'node:net';
import { ROOT, CONFIG_DIR, DATA_DIR, ASSET_DIR } from '../lib/paths.mjs';
import { loadPolicy, isActivated, machineCode } from '../lib/license.mjs';

const results = [];
const ok = (msg, extra = '') => results.push({ level: 'ok', msg, extra });
const bad = (msg, extra = '') => results.push({ level: 'bad', msg, extra });
const warn = (msg, extra = '') => results.push({ level: 'warn', msg, extra });

/* ── 1. Node 版本 ── */
const major = Number(process.versions.node.split('.')[0]);
if (major >= 22) ok(`Node.js ${process.versions.node}`);
else bad(`Node.js ${process.versions.node} 太旧（需要 22 或更高）`, '去 https://nodejs.org 装 LTS 版');

/* ── 2. 浏览器 ── */
const EDGE_CANDIDATES = [
  process.env.EDGE_PATH,
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  path.join(process.env.LOCALAPPDATA || '', 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
].filter(Boolean);

let browser = null;
for (const p of EDGE_CANDIDATES) {
  try {
    await fs.access(p);
    browser = p;
    break;
  } catch {
    /* 下一个 */
  }
}
if (browser) ok('浏览器已安装', browser);
else bad('找不到 Edge / Chrome', 'Windows 自带的 Edge 一般都有，没有就装一个');

/* ── 3. 配置 ── */
const CONFIG = path.join(CONFIG_DIR, 'config.json');
let bridges = [];
try {
  const cfg = JSON.parse(await fs.readFile(CONFIG, 'utf8'));
  bridges = (cfg.provider?.bridges || []).filter((b) => b.enabled !== false);
  if (bridges.length) {
    const ports = bridges.map((b) => Number(String(b.url).split(':').pop()));
    ok(`配置：${bridges.length} 个账号`, `端口 ${Math.min(...ports)}~${Math.max(...ports)}，每天 ${bridges.length * 30} 秒`);
  } else {
    warn('配置里一个账号都没有', '双击「初始化配置.bat」重新配');
  }
} catch {
  bad('还没有 config\\config.json', '先双击「初始化配置.bat」');
}

/* ── 4. 授权 ── */
const policy = await loadPolicy();
if (policy.mode === 'off') {
  ok('授权：未启用（不需要卡密）');
} else {
  const code = await machineCode();
  const act = await isActivated(policy);
  if (act) ok(`授权：已激活`, `机器码 ${code}`);
  else bad(`授权：未激活`, `机器码 ${code} —— 把这个发给作者换卡密`);
}

/* ── 5. 端口 / 服务 ── */
const portFree = (p) =>
  new Promise((res) => {
    const s = net.createServer();
    s.once('error', () => res(false));
    s.once('listening', () => s.close(() => res(true)));
    s.listen(p, '127.0.0.1');
  });

const getJson = async (url, ms = 1500) => {
  try {
    return await fetch(url, { signal: AbortSignal.timeout(ms) }).then((r) => r.json());
  } catch {
    return null;
  }
};

const canvas = await getJson('http://127.0.0.1:8787/api/health');
if (canvas?.ok) ok('画布服务：正在运行', 'http://127.0.0.1:8787');
else if (await portFree(8787)) warn('画布服务：没启动', '双击 start-all.bat');
else bad('8787 被别的程序占了', '关掉占用它的程序，或者重启电脑');

if (bridges.length) {
  let up = 0;
  for (const b of bridges) {
    const h = await getJson(`${String(b.url).replace(/\/+$/, '')}/health`, 900);
    if (h?.ok) up++;
  }
  if (up === 0) warn(`账号桥：0/${bridges.length} 在线`, '双击 start-all.bat（黑窗口别关）');
  else if (up < bridges.length) warn(`账号桥：${up}/${bridges.length} 在线`, '没起来的那些点「重新检测」或看黑窗口报错');
  else ok(`账号桥：${up}/${bridges.length} 全部在线`);
}

/* ── 6. 目录可写（数据 + 素材 + 桥的临时文件）── */
try {
  await fs.mkdir(DATA_DIR, { recursive: true });
  await fs.mkdir(ASSET_DIR, { recursive: true });
  const outDir = path.join(ROOT, 'bridge', 'out');
  await fs.mkdir(outDir, { recursive: true });

  // 三处都要能写：数据、素材、桥下载完的落地点
  for (const [label, dir] of [
    ['数据', DATA_DIR],
    ['素材', ASSET_DIR],
    ['桥下载', outDir],
  ]) {
    const probe = path.join(dir, `.write-test-${Date.now()}`);
    await fs.writeFile(probe, 'ok');
    await fs.rm(probe, { force: true });
    void label;
  }
  ok('目录可写', ROOT);
} catch (e) {
  bad(
    '目录不可写',
    e.code === 'EACCES' || e.code === 'EPERM'
      ? '把程序文件夹挪到 D 盘这种普通目录，别放 C:\\Program Files 下面'
      : e.message,
  );
}

/* ── 输出 ── */
const icon = { ok: '✅', warn: '⚠️ ', bad: '❌' };
console.log('');
console.log('  豆包2.0 Fast 免费额度专用画布 · 环境检查');
console.log('  ' + '─'.repeat(46));
for (const r of results) {
  console.log(`  ${icon[r.level]} ${r.msg}`);
  if (r.extra) console.log(`      ${r.extra}`);
}
console.log('  ' + '─'.repeat(46));

const bads = results.filter((r) => r.level === 'bad');
const warns = results.filter((r) => r.level === 'warn');
if (bads.length) {
  console.log(`  结论：有 ${bads.length} 个问题要修，看上面 ❌ 的说明`);
  process.exit(1);
} else if (warns.length) {
  console.log('  结论：基本就绪，按上面 ⚠️ 的提示操作一下');
  process.exit(0);
} else {
  console.log('  结论：一切正常，可以用');
  process.exit(0);
}
