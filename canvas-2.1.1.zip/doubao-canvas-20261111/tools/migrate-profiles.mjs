/**
 * 把浏览器配置目录从程序目录搬出去（程序目录立刻从 ~10 GB 缩到几十 MB）。
 *
 *   node tools/migrate-profiles.mjs              直接搬（会先检查浏览器有没有在跑）
 *   node tools/migrate-profiles.mjs --to=系统     搬到 %LOCALAPPDATA%\manju-canvas\profiles
 *   node tools/migrate-profiles.mjs --to=同级     搬到程序目录旁边的 manju-canvas-profiles
 *   node tools/migrate-profiles.mjs --check       只看现在多大、能不能搬
 *
 * 注意：Edge 正在使用这些目录时搬不动（Windows 会锁）。关掉池子和所有豆包窗口再跑。
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import net from 'node:net';
import { fileURLToPath } from 'node:url';
import { loadConfig } from '../lib/config.mjs';
import { CONFIG_FILE } from '../lib/paths.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const BRIDGE_DIR = path.join(HERE, '..', 'bridge');
const PROJECT_ROOT = path.join(HERE, '..');

const args = process.argv.slice(2);
const checkOnly = args.includes('--check');
const toArg = args.find((a) => a.startsWith('--to='));
const target = toArg ? toArg.slice('--to='.length) : '同级';

const systemRoot = path.join(
  process.env.LOCALAPPDATA || path.join(process.env.USERPROFILE || PROJECT_ROOT, 'AppData', 'Local'),
  'manju-canvas',
  'profiles',
);
const siblingRoot = path.join(path.dirname(PROJECT_ROOT), `${path.basename(PROJECT_ROOT)}-profiles`);
const destRoot = target === '系统' ? systemRoot : siblingRoot;

const sizeOf = async (dir) => {
  let total = 0;
  let count = 0;
  const walk = async (d) => {
    const entries = await fs.readdir(d, { withFileTypes: true }).catch(() => []);
    for (const e of entries) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) await walk(p);
      else {
        const st = await fs.stat(p).catch(() => null);
        if (st) {
          total += st.size;
          count++;
        }
      }
    }
  };
  await walk(dir);
  return { total, count };
};

/** 某个端口上有没有浏览器在跑（有就说明配置目录被占用） */
const portAlive = (port) =>
  new Promise((resolve) => {
    const s = net.connect({ host: '127.0.0.1', port }, () => {
      s.destroy();
      resolve(true);
    });
    s.on('error', () => resolve(false));
    s.setTimeout(400, () => {
      s.destroy();
      resolve(false);
    });
  });

const cfg = await loadConfig(CONFIG_FILE);
const list = (cfg.provider?.bridges || []).filter((b) => b.url);

console.log('');
console.log('  目标目录：' + destRoot);
console.log('');

let moved = 0;
let skipped = 0;
let locked = 0;
let freed = 0;

for (const [i, b] of list.entries()) {
  const oldDir = path.join(BRIDGE_DIR, `.profile-${b.id}`);
  const st = await fs.stat(oldDir).catch(() => null);
  if (!st) continue;

  const size = await sizeOf(oldDir);
  const debugPort = 9222 + i;
  const busy = await portAlive(debugPort);

  const mb = (size.total / 1024 / 1024).toFixed(0);
  if (checkOnly) {
    console.log(`  ${b.id.padEnd(7)} ${mb.padStart(6)} MB  ${busy ? '（浏览器在跑，搬不了）' : '（可以搬）'}`);
    freed += size.total;
    continue;
  }

  if (busy) {
    console.log(`  ${b.id.padEnd(7)} ${mb.padStart(6)} MB  ✗ 浏览器还在跑（调试端口 ${debugPort}）`);
    locked++;
    continue;
  }

  const newDir = path.join(destRoot, b.id);
  try {
    await fs.mkdir(path.dirname(newDir), { recursive: true });
    await fs.rename(oldDir, newDir);
    console.log(`  ${b.id.padEnd(7)} ${mb.padStart(6)} MB  ✓ 已搬走`);
    moved++;
    freed += size.total;
  } catch (e) {
    console.log(`  ${b.id.padEnd(7)} ${mb.padStart(6)} MB  ✗ ${e.code || e.message}`);
    skipped++;
  }
}

console.log('');
if (checkOnly) {
  console.log(`  合计 ${(freed / 1024 / 1024 / 1024).toFixed(2)} GB 在程序目录里`);
  console.log('  想搬就关掉池子和所有豆包窗口，然后不带 --check 再跑一次。');
} else {
  if (moved) {
    await fs.mkdir(path.join(PROJECT_ROOT, 'data'), { recursive: true }).catch(() => {});
    await fs.writeFile(path.join(PROJECT_ROOT, 'data', 'profile-root.txt'), destRoot + '\n', 'utf8');
    console.log(`  搬走 ${moved} 个，腾出 ${(freed / 1024 / 1024 / 1024).toFixed(2)} GB`);
    console.log('  以后新配置也会放在这个目录（启动池子时会自动沿用）。');
  }
  if (locked) console.log(`  ${locked} 个搬不了：先停掉池子（Ctrl+C），再关掉所有豆包浏览器窗口。`);
  if (skipped) console.log(`  ${skipped} 个出错，多半是权限或被占用。`);
  if (!moved && !locked && !skipped) console.log('  没有需要搬的（程序目录里已经没有配置目录了）。');
}
console.log('');
