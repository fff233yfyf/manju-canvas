/**
 * 关掉所有豆包浏览器窗口（也可以顺带停掉桥）。
 *
 *   node tools/stop-all.mjs            关掉 15 个浏览器窗口
 *   node tools/stop-all.mjs --check    只看现在开着几个
 *
 * 它是通过调试端口（9222~9236）发 Browser.close 关的，
 * 只影响程序自己起的那 15 个浏览器，不会动你日常用的 Edge。
 */
import fs from 'node:fs/promises';
import { loadConfig } from '../lib/config.mjs';
import { CONFIG_FILE } from '../lib/paths.mjs';
import { closeBrowserByPort } from '../lib/cdp-close.mjs';

const args = process.argv.slice(2);
const checkOnly = args.includes('--check');

const cfg = await loadConfig(CONFIG_FILE);
const list = (cfg.provider?.bridges || []).filter((b) => b.url);

const BASE_DEBUG_PORT = 9222;

const results = [];
for (const [i, b] of list.entries()) {
  const port = BASE_DEBUG_PORT + i;
  if (checkOnly) {
    const alive = await fetch(`http://127.0.0.1:${port}/json/version`, { signal: AbortSignal.timeout(600) })
      .then(() => true)
      .catch(() => false);
    results.push({ id: b.id, port, open: alive });
    continue;
  }
  const ok = await closeBrowserByPort(port, { timeoutMs: 6000 });
  const r = { port, closed: ok, reason: ok ? '已关闭' : '没关掉' };
  results.push({ id: b.id, port, ...r });
}

if (checkOnly) {
  const open = results.filter((r) => r.open).length;
  console.log('');
  for (const r of results) console.log(`  ${r.id.padEnd(7)} :${r.port}  ${r.open ? '开着' : '—'}`);
  console.log('');
  console.log(`  一共 ${open} 个浏览器开着`);
} else {
  const closed = results.filter((r) => r.closed).length;
  for (const r of results) {
    if (r.closed) console.log(`  ${r.id.padEnd(7)} :${r.port}  ✓ ${r.reason}`);
  }
  console.log('');
  console.log(`  关掉 ${closed} 个，跳过 ${results.length - closed} 个（本来就没开）`);
}
process.exit(0);
