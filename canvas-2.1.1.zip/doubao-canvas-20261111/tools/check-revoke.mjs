/**
 * 检查「吊销」链路上到底哪一环没通。
 *
 *   node tools/check-revoke.mjs
 *   node tools/check-revoke.mjs --url=https://xxx.netlify.app/revoked.json
 *
 * 会逐项告诉你：
 *   1. 本地有没有记录被停用的卡
 *   2. 客户端 / 客户包里有没有配吊销地址
 *   3. 那个地址能不能访问、里面有没有这些哈希
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { DATA_DIR, ROOT } from '../lib/paths.mjs';

const arg = process.argv.find((a) => a.startsWith('--url='));
const argUrl = arg ? arg.slice('--url='.length) : '';

const ok = (c) => (c ? '✓' : '✗');
const line = (mark, text, extra = '') => console.log(`  ${mark} ${text}${extra ? '  ' + extra : ''}`);

console.log('');
console.log('  吊销链路自检');
console.log('  ' + '─'.repeat(56));

/* 1. 本地吊销记录 */
let revoked = [];
try {
  revoked = JSON.parse(await fs.readFile(path.join(DATA_DIR, 'revoked-licenses.json'), 'utf8'));
} catch {
  revoked = [];
}
line(ok(revoked.length), '发卡台里的吊销记录', revoked.length ? `${revoked.length} 张` : '（空）');

/* 2. 本机配置里的吊销地址（客户端用的） */
const cfgPath = path.join(ROOT, 'config', 'config.json');
let ownUrl = '';
try {
  const cfg = JSON.parse(await fs.readFile(cfgPath, 'utf8'));
  ownUrl = String(cfg?.license?.revokeUrl || '').trim();
} catch {
  /* 没有配置文件 */
}
line(ok(ownUrl), '本机 config 的 license.revokeUrl', ownUrl || '（空 = 客户端不会去检查！）');

/* 3. 内置默认地址（打包时写进代码，客户不用配） */
const lic = await fs.readFile(path.join(ROOT, 'lib', 'license.mjs'), 'utf8');
const builtin = (lic.match(/const DEFAULT_REVOKE_URL = '([^']*)'/) || [])[1] || '';
line(ok(builtin), '代码里的默认吊销地址', builtin || '（空）');

const url = argUrl || ownUrl || builtin;

/* 4. 发布出去的 revoked.json */
const published = path.join(ROOT, '发卡台资料', 'netlify-拖这个文件夹', 'revoked.json');
let pubHashes = [];
try {
  pubHashes = JSON.parse(await fs.readFile(published, 'utf8')).hashes || [];
} catch {
  /* 没有 */
}
line(ok(pubHashes.length), '准备上传的 revoked.json', pubHashes.length ? `${pubHashes.length} 条哈希` : '（没有或者为空）');

/* 5. 地址能不能访问 */
console.log('');
if (!url) {
  console.log('  ✗ 没有任何吊销地址 —— 客户端的 isRevoked() 会直接返回 false，');
  console.log('    也就是「停用了照样能用」。这就是问题所在。');
  console.log('');
  console.log('  要修：把 发卡台资料\\netlify-拖这个文件夹 传到 Netlify，');
  console.log('  拿到地址后跑： node tools/check-revoke.mjs --url=https://你的地址/revoked.json');
  console.log('');
  process.exit(0);
}

console.log(`  正在访问：${url}`);
try {
  // 网络偶尔抖一下，重试 3 次再判失败
  let res = null;
  let lastErr = null;
  for (let i = 0; i < 3 && !res; i++) {
    try {
      res = await fetch(url, { signal: AbortSignal.timeout(20000), cache: 'no-store' });
    } catch (e) {
      lastErr = e;
      await new Promise((r) => setTimeout(r, 800));
    }
  }
  if (!res) throw lastErr || new Error('连不上');
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const j = await res.json();
  const hashes = Array.isArray(j?.hashes) ? j.hashes : [];
  line(true, '地址可访问', `返回 ${hashes.length} 条哈希`);
  const missing = revoked.map((r) => r.hash).filter((h) => !hashes.includes(h));
  if (missing.length) {
    line(false, `${missing.length} 张停用的卡不在线上名单里`, '重新上传 revoked.json');
  } else {
    line(true, '本机所有停用的卡都在线上名单里');
  }
  console.log('');
  console.log('  结论：客户端 config 里填这个地址（或把它写进 DEFAULT_REVOKE_URL），');
  console.log('        10 分钟内就会把被停用的卡判失效。');
} catch (e) {
  line(false, '地址访问失败', e.message);
  console.log('');
  console.log('  常见原因：文件没上传、地址写错、站点是私有的。');
}
console.log('');
process.exit(0);
