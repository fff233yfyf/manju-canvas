/**
 * 假桥：用来验证画布 ↔ 桥 的契约，不需要任何账号。
 *
 * 单独跑：  node tools/mock-bridge.mjs            （默认 8788）
 * 换端口：  PORT=8899 node tools/mock-bridge.mjs
 * 模拟失败：MOCK_FAIL=1 node tools/mock-bridge.mjs
 *
 * 它会在 data/bridge-out/ 下生成一个 SVG 占位文件，并通过 { path } 返回，
 * 用来验证「桥给本地路径 → 画布搬进 assets/」这条链路。
 */
import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { DATA_DIR } from '../lib/paths.mjs';
import { mockSvg } from '../lib/media.mjs';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export async function startMockBridge({ port = 8788, fail = false, latencyMs = 1500, loggedIn = true } = {}) {
  const outDir = path.join(DATA_DIR, 'bridge-out');
  await fs.mkdir(outDir, { recursive: true });

  const session = { loggedIn, account: loggedIn ? '模拟豆包账号' : '', loginAt: loggedIn ? Date.now() : 0 };
  const tasks = new Map();

  const json = (res, code, obj) => {
    const body = JSON.stringify(obj);
    res.writeHead(code, { 'content-type': 'application/json; charset=utf-8', 'content-length': Buffer.byteLength(body) });
    res.end(body);
  };

  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://localhost');
    const { pathname } = url;
    const method = req.method || 'GET';

    if (pathname === '/health') {
      return json(res, 200, {
        ok: true,
        name: 'mock-doubao-bridge',
        version: '1.0.0',
        loggedIn: session.loggedIn,
        account: session.account,
        kinds: ['video', 'image'],
        // 测试用：MOCK_CHALLENGE=1 时假装豆包弹了滑块验证
        challenge: process.env.MOCK_CHALLENGE
          ? { type: 'slider', label: '豆包要求拖动滑块验证', evidence: '测试注入', since: Date.now() }
          : null,
        queue: { pending: [...tasks.values()].filter((t) => t.status === 'queued').length, running: 0 },
        quota: { today: 0, limit: 10 },
      });
    }

    if (pathname === '/challenge/done' && method === 'POST') {
      return json(res, 200, { ok: true });
    }

    if (pathname === '/login' && method === 'POST') {
      session.loggedIn = true;
      session.account = '模拟豆包账号';
      session.loginAt = Date.now();
      return json(res, 200, { ok: true, status: 'opened' });
    }

    if (pathname === '/login/status') {
      return json(res, 200, {
        ok: true,
        status: session.loggedIn ? 'logged_in' : 'pending',
        account: session.account,
      });
    }

    if (pathname === '/generate' && method === 'POST') {
      if (!session.loggedIn) return json(res, 200, { ok: false, error: '没有登录态，请先登录' });

      const chunks = [];
      for await (const c of req) chunks.push(c);
      let body = {};
      try {
        body = JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}');
      } catch {
        return json(res, 200, { ok: false, error: '请求体不是 JSON' });
      }
      if (!body.prompt || !String(body.prompt).trim()) return json(res, 200, { ok: false, error: 'prompt 为空' });

      const taskId = `mt_${crypto.randomBytes(4).toString('hex')}`;
      tasks.set(taskId, {
        id: taskId,
        status: 'queued',
        progress: 0,
        kind: body.kind || 'video',
        prompt: body.prompt,
        createdAt: Date.now(),
      });

      // 异步跑：模拟网页上点生成、等出片
      (async () => {
        const t = tasks.get(taskId);
        t.status = 'running';
        t.progress = 30;
        await sleep(latencyMs / 2);
        t.progress = 70;
        await sleep(latencyMs / 2);

        if (fail) {
          t.status = 'failed';
          t.error = '模拟失败：网页端提示「今日次数已用完」';
          return;
        }
        const name = `${taskId}.svg`;
        const file = path.join(outDir, name);
        await fs.writeFile(file, mockSvg(String(t.prompt), '1280x720', '桥·占位'), 'utf8');
        t.path = file;
        t.status = 'succeeded';
        t.progress = 100;
      })();

      return json(res, 200, { ok: true, taskId });
    }

    if (pathname.startsWith('/tasks/')) {
      const id = decodeURIComponent(pathname.slice('/tasks/'.length));
      const t = tasks.get(id);
      if (!t) return json(res, 200, { ok: false, error: '任务不存在' });
      if (method === 'DELETE') {
        t.status = 'cancelled';
        return json(res, 200, { ok: true, cancelled: true });
      }
      return json(res, 200, {
        ok: true,
        status: t.status,
        progress: t.progress,
        path: t.path || '',
        url: '',
        error: t.error || '',
        kind: t.kind,
        model: 'mock-doubao-web',
      });
    }

    return json(res, 404, { ok: false, error: `未知路径 ${pathname}` });
  });

  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(port, '127.0.0.1', resolve);
  });

  return {
    port,
    url: `http://127.0.0.1:${port}`,
    close: () => new Promise((r) => server.close(r)),
    session,
    tasks,
  };
}

/* 直接运行时启动 */
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const port = Number(process.env.PORT || 8788);
  const fail = process.env.MOCK_FAIL === '1';
  const loggedIn = process.env.MOCK_LOGGED_IN !== '0';
  const bridge = await startMockBridge({ port, fail, loggedIn });
  console.log(`假桥已启动：${bridge.url}  （失败模式：${fail ? '开' : '关'}）`);
  console.log('画布那边把 config 的 provider.bridge.url 指到这里即可。');
}
