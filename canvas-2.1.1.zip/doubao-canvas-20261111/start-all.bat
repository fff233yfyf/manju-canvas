@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Doubao 2.0 Fast Canvas - one click start

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  [X] Node.js not found.
  echo      Install Node.js 22+ from https://nodejs.org then run this again.
  echo.
  pause
  exit /b 1
)

for /f "tokens=*" %%v in ('node -p "process.versions.node.split('.')[0]"') do set NODEMAJOR=%%v
if %NODEMAJOR% LSS 22 (
  echo.
  echo  [X] Node.js %NODEMAJOR% is too old. This app needs 22 or newer.
  echo      Download the LTS installer from https://nodejs.org and reinstall.
  echo.
  pause
  exit /b 1
)

if not exist "config\config.json" (
  echo.
  echo  [X] config\config.json is missing.
  echo      Double-click "初始化配置.bat" first ^(it asks how many accounts you have^).
  echo.
  pause
  exit /b 1
)

REM ---------- 0. port preflight ----------
node "tools\preflight.mjs"
if errorlevel 1 (
  echo.
  echo  Fix the port conflicts above, then start again.
  echo.
  pause
  exit /b 1
)

echo.
echo  ============================================================
echo    Doubao 2.0 Fast Canvas - starting everything
echo  ============================================================
echo.

REM ---------- 1. canvas server on 8787 ----------
netstat -ano | findstr /R /C:":8787 .*LISTENING" >nul
if errorlevel 1 (
  echo  [1/3] starting canvas server on 8787 ...
  start "Doubao 2.0 Fast Canvas Server" cmd /c "cd /d "%~dp0" && node server.mjs"
  timeout /t 3 /nobreak >nul
) else (
  echo  [1/3] canvas server already running on 8787
)

REM ---------- 2. open the canvas ----------
echo  [2/3] opening http://127.0.0.1:8787
start "" http://127.0.0.1:8787

REM ---------- 3. bridge pool (stays in this window) ----------
echo  [3/3] starting bridge pool ...
echo.
echo  ------------------------------------------------------------
echo   KEEP THIS WINDOW OPEN.
echo   Browsers wake up automatically (minimized).
echo   First time: click "一键登录" in the canvas and scan the QR
echo   codes one by one.
echo   Press Ctrl+C to stop everything.
echo  ------------------------------------------------------------
echo.

node bridge\run-pool.mjs %*

echo.
echo  Bridge pool stopped.
pause
