/**
 * 小地图：右下角一块缩略图，显示所有节点和当前视野。
 * 点一下就能跳过去 —— 节点多了之后不用靠「适应画布」瞎猜。
 */
import { state, on } from './core.js';

const W = 200;
const H = 132;
let canvas = null;
let ctx = null;
let timer = null;

function nodeBounds() {
  const nodes = state.project?.nodes || [];
  if (!nodes.length) return null;
  let x1 = Infinity;
  let y1 = Infinity;
  let x2 = -Infinity;
  let y2 = -Infinity;
  for (const n of nodes) {
    x1 = Math.min(x1, n.x);
    y1 = Math.min(y1, n.y);
    x2 = Math.max(x2, n.x + (n.w || 260));
    y2 = Math.max(y2, n.y + (n.h || 200));
  }
  return { x1, y1, x2, y2 };
}

function draw() {
  if (!canvas || !ctx) return;
  const nodes = state.project?.nodes || [];
  ctx.clearRect(0, 0, W, H);
  if (!nodes.length) {
    canvas.hidden = true;
    return;
  }

  const b = nodeBounds();
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  // 视野也要算进去，否则缩小到很远时会看不见自己
  const viewWorld = {
    x1: -state.view.x / state.view.k,
    y1: -state.view.y / state.view.k,
    x2: (vw - state.view.x) / state.view.k,
    y2: (vh - state.view.y) / state.view.k,
  };
  const x1 = Math.min(b.x1, viewWorld.x1) - 80;
  const y1 = Math.min(b.y1, viewWorld.y1) - 80;
  const x2 = Math.max(b.x2, viewWorld.x2) + 80;
  const y2 = Math.max(b.y2, viewWorld.y2) + 80;
  const bw = Math.max(1, x2 - x1);
  const bh = Math.max(1, y2 - y1);
  const scale = Math.min((W - 8) / bw, (H - 8) / bh);
  const ox = 4 + ((W - 8) - bw * scale) / 2;
  const oy = 4 + ((H - 8) - bh * scale) / 2;
  const px = (x) => ox + (x - x1) * scale;
  const py = (y) => oy + (y - y1) * scale;

  canvas.hidden = false;

  // 视野框
  ctx.strokeStyle = 'rgba(124,156,255,.65)';
  ctx.lineWidth = 1;
  ctx.strokeRect(px(viewWorld.x1), py(viewWorld.y1), (viewWorld.x2 - viewWorld.x1) * scale, (viewWorld.y2 - viewWorld.y1) * scale);
  ctx.fillStyle = 'rgba(124,156,255,.08)';
  ctx.fillRect(px(viewWorld.x1), py(viewWorld.y1), (viewWorld.x2 - viewWorld.x1) * scale, (viewWorld.y2 - viewWorld.y1) * scale);

  // 节点
  for (const n of nodes) {
    const sel = state.selection?.has(n.id);
    const hasVideo = !!(n.type === 'text' ? n.data?.videoUrl : n.data?.url);
    if (sel) ctx.fillStyle = 'rgba(255,176,94,.95)';
    else if (hasVideo) ctx.fillStyle = 'rgba(110,231,183,.8)';
    else ctx.fillStyle = n.type === 'image' ? 'rgba(124,156,255,.55)' : 'rgba(180,190,220,.5)';
    const rw = Math.max(1.5, (n.w || 260) * scale);
    const rh = Math.max(1.5, (n.h || 200) * scale);
    ctx.fillRect(px(n.x), py(n.y), rw, rh);
  }
}

/** 点小地图 → 把视野移到那个世界坐标 */
function jump(clientX, clientY) {
  if (!canvas) return;
  const rect = canvas.getBoundingClientRect();
  const b = nodeBounds();
  if (!b) return;
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  const viewWorld = {
    x1: -state.view.x / state.view.k,
    y1: -state.view.y / state.view.k,
    x2: (vw - state.view.x) / state.view.k,
    y2: (vh - state.view.y) / state.view.k,
  };
  const x1 = Math.min(b.x1, viewWorld.x1) - 80;
  const y1 = Math.min(b.y1, viewWorld.y1) - 80;
  const x2 = Math.max(b.x2, viewWorld.x2) + 80;
  const y2 = Math.max(b.y2, viewWorld.y2) + 80;
  const bw = Math.max(1, x2 - x1);
  const bh = Math.max(1, y2 - y1);
  const scale = Math.min((W - 8) / bw, (H - 8) / bh);
  const ox = 4 + ((W - 8) - bw * scale) / 2;
  const oy = 4 + ((H - 8) - bh * scale) / 2;

  const worldX = x1 + (clientX - rect.left - ox) / scale;
  const worldY = y1 + (clientY - rect.top - oy) / scale;
  state.view.x = Math.round(vw / 2 - worldX * state.view.k);
  state.view.y = Math.round(vh / 2 - worldY * state.view.k);
  // 复用画布的 applyView（通过事件让 core 自己刷）
  import('./core.js').then((m) => m.applyView());
  draw();
}

export function initMinimap() {
  canvas = document.getElementById('minimap');
  if (!canvas) return;
  canvas.width = W;
  canvas.height = H;
  ctx = canvas.getContext('2d');

  canvas.addEventListener('mousedown', (e) => {
    e.preventDefault();
    jump(e.clientX, e.clientY);
  });

  on('project:loaded', draw);
  on('selection:changed', draw);
  on('nodes:changed', draw);
  draw();

  // 拖动/缩放不会发事件，用低频重绘兜底（4 次/秒，开销很小）
  if (!timer) {
    timer = setInterval(() => {
      if (!canvas.isConnected) {
        clearInterval(timer);
        timer = null;
        return;
      }
      draw();
    }, 250);
  }
}
