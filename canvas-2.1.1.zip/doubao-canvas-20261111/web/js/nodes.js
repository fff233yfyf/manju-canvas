/* 画布节点：文本（提示词） / 图片（人物·场景·道具），节点右侧可拉出注释框 */

import {
  state,
  emit,
  on,
  $,
  $$,
  uid,
  clamp,
  esc,
  getNode,
  composeVideoPrompt,
  collectRefs,
  imageHandles,
  IMAGE_KINDS,
  runGeneration,
  screenToWorld,
  viewportCenterWorld,
  applyView,
  zoomAt,
  panBy,
  markDirty,
  formatTime,
  showModal,
  toast,
  api,
  pushHistory,
  beginEdit,
  commitEdit,
  snapshotNow,
  pushHistorySnapshot,
} from './core.js';

const SVG_NS = 'http://www.w3.org/2000/svg';
const nodeEls = new Map();
let zTop = 2;
let drag = null;
let spaceDown = false;

/* ───────────────────────── 类型 ───────────────────────── */
export const NODE_TYPES = {
  text: {
    label: '文本 / 提示词',
    badge: '文本',
    w: 400,
    defaults: () => ({
      text: '',
      duration: 0, // 0 = 跟随项目默认
      ratio: '', // 空 = 跟随项目默认
      jobId: '',
      videoUrl: '',
      meta: '',
      time: 0,
      lastError: '',
      note: '',
      noteOpen: false,
      // 首帧 / 尾帧参考图：用户自己指定，和 @引用 无关
      firstFrame: '',
      frameOpen: false,
      lastFrame: '',
      lastOpen: false,
    }),
  },
  image: {
    label: '图片',
    badge: '图片',
    w: 292,
    defaults: () => ({ kind: 'character', name: '', url: '', note: '', noteOpen: false }),
  },
};

// 常用时长（一秒一下点，比敲数字快）
const DUR_CHOICES = [10, 15];

const RATIO_OPTS = [
  ['auto', '自动'],
  ['16:9', '16:9'],
  ['9:16', '9:16'],
  ['1:1', '1:1'],
  ['4:3', '4:3'],
  ['3:4', '3:4'],
  ['21:9', '21:9'],
];

/* ───────────────────────── 模板 ───────────────────────── */
const badgeOf = (n) =>
  n.type === 'image' ? IMAGE_KINDS[n.data.kind]?.label || '图片' : NODE_TYPES[n.type].badge;

const headTpl = (n) => `
  <div class="n-head">
    <span class="n-badge">${badgeOf(n)}</span>
    <span class="n-title"></span>
    <button class="n-del" title="删除节点（Delete）">×</button>
  </div>`;

/** 节点右侧的注释拉手 + 注释框 */
const noteTpl = () => `
  <button class="n-note-tab" title="拉出注释框">✎</button>
  <div class="n-note" hidden>
    <textarea data-f="note" rows="4" placeholder="给这个节点写点注释…"></textarea>
  </div>`;

/** 文本节点右侧的首帧 / 尾帧参考图拉手 + 面板 */
const FRAME_KINDS = {
  first: { key: 'firstFrame', openKey: 'frameOpen', label: '首帧', tab: '首', hint: '作为这一段视频的首帧' },
  last: { key: 'lastFrame', openKey: 'lastOpen', label: '尾帧', tab: '尾', hint: '作为这一段视频的尾帧' },
};

const frameTpl = (n) => {
  if (n.type !== 'text') return '';
  return Object.entries(FRAME_KINDS)
    .map(
      ([kind, cfg]) => `
  <button class="n-frame-tab n-frame-tab-${kind}" data-frame-tab="${kind}" title="设置${cfg.label}参考图">${cfg.tab}</button>
  <div class="n-frame n-frame-${kind}" data-frame-panel="${kind}" hidden>
    <div class="nf-title">${cfg.label}参考图</div>
    <div class="nf-preview" data-role="frame-preview"></div>
    <div class="n-row">
      <button class="btn primary" data-act="frame-upload" data-frame-kind="${kind}">上传</button>
      <button class="btn" data-act="frame-clear" data-frame-kind="${kind}">清除</button>
    </div>
    <select class="ref-picker" data-role="frame-pick" data-frame-kind="${kind}">
      <option value="">从图片节点里选…</option>
    </select>
    <div class="set-hint nf-hint">这张图会${cfg.hint}发给模型。</div>
  </div>`
    )
    .join('');
};

const bodyTpl = (n) => {
  const d = n.data;
  if (n.type === 'image') {
    return `
    <div class="n-body">
      <div class="preview" data-role="preview"></div>
      <div class="n-row">
        <button class="btn primary" data-act="upload">上传图片</button>
        <button class="btn" data-act="copy-ref" title="复制 @引用">复制引用</button>
      </div>
      <div class="n-field"><span class="n-label">名称（可留空）</span>
        <input type="text" data-f="name" placeholder="林小雨 / 雨夜街道 / 红伞" /></div>
      <div class="n-meta"><span data-role="handle">—</span><span data-role="meta-size"></span></div>
    </div>`;
  }

  // 文本 / 提示词
  return `
  <div class="n-body">
    <textarea data-f="text" rows="5" placeholder="写这一镜要什么：谁、在哪、在做什么、什么光。可以用 @人物1 引用图片。"></textarea>
    <div class="n-row ref-row">
      <select data-role="ref-picker" class="ref-picker">
        <option value="">＋ 插入图片引用…</option>
      </select>
    </div>
    <div class="n-grid">
      <div class="n-field n-field-dur">
        <span class="n-label">时长（秒）<b class="dur-val" data-role="dur-val">默认</b></span>
        <input type="range" class="dur-range" data-role="dur-range" min="4" max="15" step="1" value="5" />
        <div class="dur-chips" data-role="dur-chips">
          <span class="dur-quick">快速选择</span>
          ${DUR_CHOICES.map((v) => `<button class="dur-chip" data-dur="${v}">${v} 秒</button>`).join('')}
          <button class="dur-chip dur-reset" data-dur="0">默认</button>
        </div></div>
      <div class="n-field n-field-ratio"><span class="n-label">画幅</span>
        <select data-f="ratio">${RATIO_OPTS.map(
          ([v, t]) => `<option value="${v}"${d.ratio === v ? ' selected' : ''}>${t === '自动' ? '自动（默认）' : t}</option>`
        ).join('')}</select></div>
    </div>
    <div class="chips" data-role="refs"></div>
    <div class="preview" data-role="preview"></div>
    <div class="versions" data-role="versions" hidden></div>
    <div class="status" data-role="status"></div>
    <div class="n-row">
      <button class="btn primary" data-act="gen-vid">出视频</button>
      <button class="btn ghost" data-act="show-prompt" title="查看最终提示词">提示词</button>
    </div>
    <div class="n-meta"><span data-role="meta-acc">未生成</span><span data-role="meta-ref">0 引用</span></div>
  </div>`;
};

function nodeTitle(n) {
  if (n.type === 'image') {
    const h = imageHandles().get(n.id) || '';
    return `${h}${n.data.name ? ' · ' + n.data.name : ''}`;
  }
  const t = String(n.data.text || '').replace(/\s+/g, ' ').trim();
  return t ? t.slice(0, 14) + (t.length > 14 ? '…' : '') : '文本 / 提示词';
}

/* ───────────────────────── 渲染 ───────────────────────── */
export function renderAll() {
  const world = document.getElementById('world');
  if (!world || !state.project) return;
  $$('.node', world).forEach((el) => el.remove());
  nodeEls.clear();
  zTop = 2;
  for (const n of state.project.nodes) createNodeEl(n);
  renderEdges();
  updateEmptyHint();
}

function createNodeEl(n) {
  const world = document.getElementById('world');
  const el = document.createElement('div');
  el.className = 'node';
  el.dataset.id = n.id;
  el.dataset.type = n.type;
  el.style.left = `${n.x}px`;
  el.style.top = `${n.y}px`;
  el.style.width = `${n.w}px`;
  el.style.zIndex = String(zTop++);
  el.innerHTML =
    headTpl(n) +
    bodyTpl(n) +
    noteTpl() +
    frameTpl(n) +
    `<div class="port port-in" title="输入"></div><div class="port port-out" title="拖出去连线"></div><div class="n-resize"></div>`;
  world.appendChild(el);
  nodeEls.set(n.id, el);
  syncNode(n);
  return el;
}

export function syncNode(n) {
  const el = nodeEls.get(n.id);
  if (!el || !n) return;
  el.style.width = `${n.w}px`;

  const title = el.querySelector('.n-title');
  if (title) title.textContent = nodeTitle(n);

  for (const input of el.querySelectorAll('[data-f]')) {
    if (document.activeElement === input) continue;
    const v = n.data[input.dataset.f];
    if (input.tagName === 'SELECT') {
      // 下拉框：只有值真的匹配某个选项才设置，否则会变成「什么都没选中」（显示空白）
      const wanted = v ?? '';
      const has = [...input.options].some((o) => o.value === String(wanted));
      if (has && input.value !== String(wanted)) input.value = String(wanted);
      if (!has && !input.value) input.selectedIndex = 0;
      continue;
    }
    const shown = input.dataset.f === 'duration' ? (v ? v : '') : v ?? '';
    if (String(input.value) !== String(shown)) input.value = shown;
  }

  if (n.type === 'image') {
    const badge = el.querySelector('.n-badge');
    if (badge) badge.textContent = badgeOf(n);
    const h = imageHandles().get(n.id) || '—';
    const hEl = el.querySelector('[data-role="handle"]');
    if (hEl) hEl.textContent = `引用编号 @${h}`;
  }

  renderPreview(n, el);
  renderStatus(n, el);
  renderMeta(n, el);
  renderRefChips(n, el);
  fillRefPicker(n, el);
  renderNote(n, el);
  renderFrame(n, el);

  const vidBtn = el.querySelector('[data-act="gen-vid"]');
  if (vidBtn) vidBtn.disabled = isRunning(n.data.jobId);
}

function jobOf(id) {
  return id ? state.jobs.get(id) : null;
}

/**
 * 对账：服务端有已完成的任务、节点却没视频 → 补回来。
 * 任务在页面没开着时完成（或事件漏了），节点会一直显示「还没有视频」。
 */
export async function reconcileNodeVideos() {
  if (!state.project) return 0;
  let r;
  try {
    r = await api.jobs();
  } catch {
    return 0;
  }
  const done = (r.jobs || []).filter((j) => j.status === 'succeeded' && j.result?.url);
  let fixed = 0;

  // 顺带同步任务状态：任务早就失败了，节点还挂着「生成中」会骗人
  for (const j of r.jobs || []) {
    if (!j.nodeId) continue;
    state.jobs.set(j.id, j);
    if (j.status === 'failed' || j.status === 'cancelled') {
      const n = getNode(j.nodeId);
      if (n && n.data.jobId === j.id) {
        n.data.jobId = '';
        n.data.lastError = j.error || (j.status === 'cancelled' ? '已取消' : '生成失败');
        syncNode(n);
        fixed++;
      }
    }
  }
  for (const j of done) {
    if (!j.nodeId) continue;
    const n = getNode(j.nodeId);
    if (!n || n.type !== 'text') continue;
    if (n.data.videoUrl === j.result.url) continue;
    // 已经有别的片子就不覆盖
    if (n.data.videoUrl && n.data.jobId !== j.id) continue;
    rememberVideo(n, j.result.url, `${j.accountLabel || '池'} · ${Math.round((j.result.elapsedMs || 0) / 1000)}s`);
    n.data.videoUrl = j.result.url;
    n.data.meta = `${j.accountLabel || '池'} · ${Math.round((j.result.elapsedMs || 0) / 1000)}s`;
    n.data.time = Date.now();
    n.data.jobId = '';
    n.data.lastError = '';
    if (!n.data.duration && j.seconds) n.data.duration = j.seconds;
    syncNode(n);
    fixed++;
  }
  if (fixed) {
    markDirty();
    // 主动提示一下，用户才知道「豆包那边出片 → 画布自己搬过来了」
    toast(`已自动同步 ${fixed} 段视频到画布`, 'ok', 3200);
  }
  return fixed;
}
function isRunning(id) {
  const j = jobOf(id);
  return !!j && (j.status === 'queued' || j.status === 'running');
}

function renderStatus(n, el) {
  const box = el.querySelector('[data-role="status"]');
  if (!box) return;
  const job = jobOf(n.data.jobId);
  if (job && (job.status === 'queued' || job.status === 'running')) {
    const pos = job.queuePosition > 0 ? `排队第 ${job.queuePosition} 位` : job.status === 'queued' ? '排队中' : '生成中';
    box.className = 'status run';
    box.innerHTML = `<span class="spin"></span><span>出视频 · ${pos}${job.accountLabel ? ` · ${esc(job.accountLabel)}` : ''}</span>`;
    return;
  }
  if (job && job.status === 'failed') {
    box.className = 'status err';
    box.textContent = `失败：${String(job.error || '').slice(0, 200)}`;
    box.title = String(job.error || '');
    return;
  }
  if (n.data.lastError) {
    box.className = 'status err';
    box.textContent = `失败：${String(n.data.lastError).slice(0, 200)}`;
    box.title = String(n.data.lastError);
    return;
  }
  if (n.data.videoUrl) {
    box.className = 'status ok';
    box.textContent = '视频已生成';
    return;
  }
  box.className = 'status';
  box.textContent = '';
}

function renderMeta(n, el) {
  const acc = el.querySelector('[data-role="meta-acc"]');
  if (acc) acc.textContent = n.data.meta || '未生成';
  const time = el.querySelector('[data-role="meta-time"]');
  if (time) time.textContent = n.data.time ? formatTime(n.data.time) : '';
  const ref = el.querySelector('[data-role="meta-ref"]');
  if (ref) {
    try {
      ref.textContent = `${collectRefs(n).length} 引用`;
    } catch {
      ref.textContent = '';
    }
  }
  const size = el.querySelector('[data-role="meta-size"]');
  if (size) size.textContent = n.data.url ? '' : '还没上传';
}

function renderRefChips(n, el) {
  const box = el.querySelector('[data-role="refs"]');
  if (!box) return;
  let refs = [];
  try {
    refs = collectRefs(n);
  } catch {
    refs = [];
  }
  if (!refs.length) {
    box.innerHTML = `<span class="set-hint">还没有引用图片 —— 插 @编号，或把图片节点连线过来</span>`;
    return;
  }
  // 只是「参考图」，不再标首帧
  box.innerHTML = refs
    .map(
      (r) =>
        `<span class="chip${r.url ? '' : ' chip-missing'}" title="${esc(r.name || r.handle)}${
          r.url ? '' : ' · 还没上传，不会发给模型'
        }">${esc(r.handle)}${r.name ? ' ' + esc(r.name) : ''}${r.url ? '' : '（未上传）'}</span>`
    )
    .join('');
}

function fillRefPicker(n, el) {
  const sel = el.querySelector('[data-role="ref-picker"]');
  if (!sel || n.type !== 'text') return;
  const handles = imageHandles();
  const opts = ['<option value="">＋ 插入图片引用…</option>'];
  for (const node of state.project.nodes) {
    if (node.type !== 'image') continue;
    const h = handles.get(node.id);
    if (!h) continue;
    const label = `${h}${node.data.name ? ' · ' + node.data.name : ''}${node.data.url ? '' : '（未上传）'}`;
    opts.push(`<option value="${esc(h)}">${esc(label)}</option>`);
  }
  sel.innerHTML = opts.join('');
}

function renderNote(n, el) {
  const tab = el.querySelector('.n-note-tab');
  const box = el.querySelector('.n-note');
  if (!tab || !box) return;
  const has = String(n.data.note || '').trim().length > 0;
  tab.classList.toggle('has', has);
  tab.classList.toggle('open', !!n.data.noteOpen);
  box.hidden = !n.data.noteOpen;
  const ta = box.querySelector('textarea');
  if (ta && document.activeElement !== ta) ta.value = n.data.note || '';
}

function renderFrame(n, el) {
  for (const [kind, cfg] of Object.entries(FRAME_KINDS)) {
    const tab = el.querySelector(`.n-frame-tab-${kind}`);
    const box = el.querySelector(`[data-frame-panel="${kind}"]`);
    if (!tab || !box) continue;

    const url = n.data[cfg.key] || '';
    tab.classList.toggle('has', !!url);
    tab.classList.toggle('open', !!n.data[cfg.openKey]);
    box.hidden = !n.data[cfg.openKey];

    const pv = box.querySelector('[data-role="frame-preview"]');
    if (pv) {
      pv.innerHTML = url
        ? `<img src="${esc(url)}" alt="" draggable="false" /><button class="nf-del" data-act="frame-clear" data-frame-kind="${kind}" title="清除">×</button>`
        : `<div class="nf-empty">未设置<br /><span>不设置就不带${cfg.label}</span></div>`;
    }

    const pick = box.querySelector('[data-role="frame-pick"]');
    if (pick) {
      const handles = imageHandles();
      const opts = ['<option value="">从图片节点里选…</option>'];
      for (const node of state.project?.nodes || []) {
        if (node.type !== 'image' || !node.data?.url) continue;
        const h = handles.get(node.id) || '';
        opts.push(
          `<option value="${esc(node.data.url)}"${node.data.url === url ? ' selected' : ''}>${esc(h)}${
            node.data.name ? ' · ' + esc(node.data.name) : ''
          }</option>`
        );
      }
      pick.innerHTML = opts.join('');
    }
  }
}

function ratioOf() {
  return state.project?.settings?.ratio || 'auto';
}

/** 把当前视频记进历史（最多 6 个），然后把新的设为当前 */
function rememberVideo(n, url, meta) {
  if (!url) return;
  if (!Array.isArray(n.data.videos)) {
    n.data.videos = [];
    // 老项目：只有 videoUrl，先把它记成第一版
    if (n.data.videoUrl && n.data.videoUrl !== url) {
      n.data.videos.push({ url: n.data.videoUrl, at: n.data.time || 0, meta: n.data.meta || '' });
    }
  }
  if (!n.data.videos.some((v) => v.url === url)) {
    n.data.videos.push({ url, at: Date.now(), meta: meta || '' });
  }
  if (n.data.videos.length > 6) n.data.videos = n.data.videos.slice(-6);
}

function renderVersions(n, el) {
  const bar = el.querySelector('[data-role="versions"]');
  if (!bar) return;
  const list = Array.isArray(n.data.videos) ? n.data.videos : [];
  if (list.length < 2) {
    bar.hidden = true;
    bar.innerHTML = '';
    return;
  }
  bar.hidden = false;
  bar.innerHTML =
    '<span class="ver-label">版本</span>' +
    list
      .map((v, i) => {
        const active = v.url === n.data.videoUrl;
        return `<button class="ver-chip${active ? ' on' : ''}" data-ver="${i}" title="${esc(v.meta || '')}">v${i + 1}</button>`;
      })
      .join('');

  bar.querySelectorAll('[data-ver]').forEach((b) => {
    b.onclick = (ev) => {
      ev.stopPropagation();
      const v = list[Number(b.dataset.ver)];
      if (!v) return;
      n.data.videoUrl = v.url;
      n.data.meta = v.meta || '';
      n.data.time = v.at || Date.now();
      markDirty();
      syncNode(n);
    };
  });
}

/** 刷新时长的滑杆 / 数值 / 按钮选中态 */
function renderDuration(n, el, { force = false } = {}) {
  const box = el.querySelector('[data-role="dur-chips"]');
  const range = el.querySelector('[data-role="dur-range"]');
  const label = el.querySelector('[data-role="dur-val"]');
  const cur = Number(n.data?.duration) || 0;
  const defDur = clamp(Number(state.project?.settings?.duration) || 5, 4, 15);
  const eff = cur || defDur;

  if (range && (force || document.activeElement !== range)) range.value = String(eff);
  if (label) {
    label.textContent = cur ? `${cur} 秒` : `默认（${defDur} 秒）`;
    label.title = `这个时长每个号每天约 ${Math.max(1, Math.floor(30 / eff))} 条`;
  }

  if (box) {
    for (const b of box.querySelectorAll('[data-dur]')) {
      const v = Number(b.dataset.dur) || 0;
      b.classList.toggle('on', v === cur);
      b.title =
        v === 0
          ? '跟随设置里的默认时长'
          : `${v} 秒 · 每个号每天约 ${Math.max(1, Math.floor(30 / v))} 条`;
    }
  }
}

function renderPreview(n, el) {
  const box = el.querySelector('[data-role="preview"]');
  if (!box) return;
  const media = n.type === 'text' ? n.data.videoUrl || '' : n.data.url || '';
  renderVersions(n, el);
  renderDuration(n, el);
  if (box.dataset.media === media) return;
  box.dataset.media = media;

  if (!media) {
    const hints = {
      image: '还没有图片<br /><b>点「上传图片」</b>',
      text: '还没有视频<br /><b>写好提示词后点「出视频」</b>',
    };
    box.innerHTML = `<div class="preview-empty"><span>${hints[n.type] || '暂无'}</span></div>`;
    return;
  }
  const isVideo = /\.(mp4|webm|mov)(\?|$)/i.test(media);
  box.innerHTML = isVideo
    ? `<video src="${esc(media)}" controls playsinline preload="metadata"></video>`
    : `<img src="${esc(media)}" alt="" draggable="false" loading="lazy" />`;
}

export function renderEdges() {
  const svg = document.getElementById('edges');
  if (!svg || !state.project) return;
  svg.innerHTML = '';
  for (const e of state.project.edges) {
    const a = nodeEls.get(e.from);
    const b = nodeEls.get(e.to);
    if (!a || !b) continue;
    const ax = parseFloat(a.style.left) + a.offsetWidth;
    const ay = parseFloat(a.style.top) + a.offsetHeight / 2;
    const bx = parseFloat(b.style.left);
    const by = parseFloat(b.style.top) + b.offsetHeight / 2;
    const d = curvePath(ax, ay, bx, by);
    const g = document.createElementNS(SVG_NS, 'g');
    g.setAttribute('class', `edge${state.selectedEdges.has(e.id) ? ' sel' : ''}`);
    g.dataset.id = e.id;
    const hit = document.createElementNS(SVG_NS, 'path');
    hit.setAttribute('d', d);
    hit.setAttribute('class', 'e-hit');
    const line = document.createElementNS(SVG_NS, 'path');
    line.setAttribute('d', d);
    line.setAttribute('class', 'e-line');
    g.append(hit, line);

    // 悬停时在线中点冒出一个 × —— 点它直接删掉这条连线
    const { mx, my } = curveMid(ax, ay, bx, by);
    const del = document.createElementNS(SVG_NS, 'g');
    del.setAttribute('class', 'e-del');
    del.dataset.edge = e.id;
    del.innerHTML =
      `<circle cx="${mx}" cy="${my}" r="10" />` +
      `<path d="M ${mx - 4} ${my - 4} L ${mx + 4} ${my + 4} M ${mx + 4} ${my - 4} L ${mx - 4} ${my + 4}" />`;
    g.append(del);

    // 视频 → 视频的连线：中间挂一个「尾帧接首帧」开关
    const fromNode = getNode(e.from);
    const toNode = getNode(e.to);
    if (fromNode?.type === 'text' && toNode?.type === 'text') {
      const on = !!e.frameLink;
      const pill = document.createElementNS(SVG_NS, 'g');
      pill.setAttribute('class', `e-frame${on ? ' on' : ''}`);
      pill.dataset.frameEdge = e.id;
      pill.innerHTML =
        `<rect x="${mx - 44}" y="${my - 48}" width="88" height="20" rx="10" />` +
        `<text x="${mx}" y="${my - 34}" text-anchor="middle">${on ? '尾帧→首帧' : '不接帧'}</text>`;
      g.append(pill);
    }

    svg.appendChild(g);
  }
}

function curveMid(x1, y1, x2, y2) {
  const dx = clamp(Math.abs(x2 - x1) * 0.5, 40, 170);
  // 三次贝塞尔 t=0.5：(P0 + 3P1 + 3P2 + P3) / 8
  return {
    mx: Math.round((x1 + 3 * (x1 + dx) + 3 * (x2 - dx) + x2) / 8),
    my: Math.round((y1 + 3 * y1 + 3 * y2 + y2) / 8),
  };
}

/** 切换「尾帧接首帧」开关 */
export function toggleFrameLink(id) {
  const e = state.project?.edges.find((x) => x.id === id);
  if (!e) return null;
  pushHistory();
  e.frameLink = !e.frameLink;
  renderEdges();
  markDirty();
  emit('project:changed');

  if (!e.frameLink) {
    toast('已断开帧连接', '', 2000);
    return false;
  }

  // 接上：立刻截上一段的最后一帧，直接填进下一段的「首帧参考图」框
  if (getNode(e.from)?.data?.videoUrl) {
    toast('已接上，正在截取上一段的最后一帧…', '', 2500);
  }
  fillLinkedFirstFrame(e).catch((err) => toast(`截取失败：${err.message}`, 'err', 4000));
  return true;
}

/** 把上游视频的最后一帧抽出来，写进下游节点的 firstFrame 字段（界面上能看到） */
async function fillLinkedFirstFrame(edge) {
  const from = getNode(edge.from);
  const to = getNode(edge.to);
  if (!from || !to) return false;
  if (!from.data?.videoUrl) {
    toast(`已接上「${nodeTitle(from)}」→ 这一段；等上一段出片后会自动截最后一帧填进来`, 'warn', 5200);
    return false;
  }
  const url = await lastFrameUpload(from.data.videoUrl);
  to.data.firstFrame = url;
  const el = nodeEls.get(to.id);
  if (el) renderFrame(to, el);
  markDirty();
  toast(`已把「${nodeTitle(from)}」的最后一帧填进「${nodeTitle(to)}」的首帧参考图`, 'ok', 4200);
  return true;
}

/** 找「接进这个节点、且开了帧连接」的上游节点 */
function incomingFrameLink(node) {
  const edges = state.project?.edges || [];
  for (const e of edges) {
    if (e.to !== node.id || !e.frameLink) continue;
    const from = getNode(e.from);
    if (from?.type === 'text') return from;
  }
  return null;
}

/** 从一段视频里抽最后一帧，传到 assets，返回 URL */
async function lastFrameUpload(videoUrl) {
  const v = document.createElement('video');
  v.muted = true;
  v.playsInline = true;
  v.preload = 'auto';
  v.src = videoUrl;
  await new Promise((res, rej) => {
    v.addEventListener('loadeddata', res, { once: true });
    v.addEventListener('error', () => rej(new Error('读不到上一段视频')), { once: true });
    v.load();
  });
  const t = Math.max(0, (v.duration || 0) - 0.08);
  await new Promise((res) => {
    v.addEventListener('seeked', res, { once: true });
    v.currentTime = t;
    setTimeout(res, 1500);
  });
  const c = document.createElement('canvas');
  c.width = v.videoWidth || 1280;
  c.height = v.videoHeight || 720;
  c.getContext('2d').drawImage(v, 0, 0);
  const blob = await new Promise((r) => c.toBlob(r, 'image/png'));
  if (!blob) throw new Error('截帧失败');
  return api.upload(new File([blob], `lastframe-${Date.now()}.png`, { type: 'image/png' }));
}

/** 删掉一条连线（可撤销） */
export function deleteEdge(id) {  if (!state.project) return;
  const before = state.project.edges.length;
  if (!before) return;
  pushHistory();
  state.project.edges = state.project.edges.filter((e) => e.id !== id);
  state.selectedEdges.delete(id);
  renderEdges();
  syncSelection();
  markDirty();
  emit('project:changed');
  if (state.project.edges.length < before) toast('已删除连线', '', 1400);
}

function curvePath(x1, y1, x2, y2) {
  const dx = clamp(Math.abs(x2 - x1) * 0.5, 40, 170);
  return `M ${x1} ${y1} C ${x1 + dx} ${y1}, ${x2 - dx} ${y2}, ${x2} ${y2}`;
}

export function updateEmptyHint() {
  const hint = document.getElementById('empty-hint');
  if (!hint) return;
  hint.hidden = !!(state.project && state.project.nodes.length);
}

export function syncAll() {
  if (!state.project) return;
  for (const n of state.project.nodes) syncNode(n);
  renderEdges();
}

/* ───────────────────────── 选择 ───────────────────────── */
export function syncSelection() {
  for (const [id, el] of nodeEls) el.classList.toggle('sel', state.selection.has(id));
  for (const g of $$('#edges g.edge')) g.classList.toggle('sel', state.selectedEdges.has(g.dataset.id));
}

export function selectedIds() {
  return [...state.selection];
}

export function selectOnly(ids, { additive = false } = {}) {
  if (!additive) {
    state.selection.clear();
    state.selectedEdges.clear();
  }
  for (const id of ids) if (id) state.selection.add(id);
  syncSelection();
  emit('selection:changed');
}

export function clearSelection() {
  state.selection.clear();
  state.selectedEdges.clear();
  syncSelection();
  emit('selection:changed');
}

/* ───────────────────────── 增删 ───────────────────────── */
export function addNode(type, { at = null, data = {} } = {}) {
  const def = NODE_TYPES[type];
  if (!def || !state.project) return null;
  pushHistory();
  const center = at ? screenToWorld(at.x, at.y) : viewportCenterWorld();
  // 连续新建时阶梯错开，别叠成一坨
  const spread = at ? 0 : (state.project.nodes.length % 6) * 28;
  const n = {
    id: uid('n'),
    type,
    x: Math.round(center.x - def.w / 2 + spread),
    y: Math.round(center.y - 90 + spread),
    w: def.w,
    data: { ...def.defaults(), ...data },
  };
  state.project.nodes.push(n);
  createNodeEl(n);
  selectOnly([n.id]);
  renderEdges();
  syncAll();
  updateEmptyHint();
  markDirty();
  emit('project:changed');
  return n;
}

export function deleteSelection() {
  if (!state.project) return;
  const ids = new Set(state.selection);
  if (!ids.size && !state.selectedEdges.size) return;
  pushHistory();

  const before = state.project.nodes.length;
  state.project.nodes = state.project.nodes.filter((n) => !ids.has(n.id));
  const removed = before - state.project.nodes.length;
  state.project.edges = state.project.edges.filter(
    (e) => !ids.has(e.from) && !ids.has(e.to) && !state.selectedEdges.has(e.id)
  );

  for (const id of ids) {
    nodeEls.get(id)?.remove();
    nodeEls.delete(id);
  }
  clearSelection();
  renderEdges();
  syncAll();
  updateEmptyHint();
  markDirty();
  emit('project:changed');
  if (removed) toast(`已删除 ${removed} 个节点`, '', 1600);
}

export function duplicateSelection() {
  if (!state.selection.size) return;
  pushHistory();
  const map = new Map();
  const created = [];
  for (const id of state.selection) {
    const src = getNode(id);
    if (!src) continue;
    const copy = {
      id: uid('n'),
      type: src.type,
      x: src.x + 36,
      y: src.y + 36,
      w: src.w,
      data: JSON.parse(JSON.stringify(src.data)),
    };
    delete copy.data.jobId;
    state.project.nodes.push(copy);
    map.set(id, copy.id);
    created.push(copy);
    createNodeEl(copy);
  }
  for (const e of [...state.project.edges]) {
    if (map.has(e.from) && map.has(e.to)) {
      state.project.edges.push({ id: uid('e'), from: map.get(e.from), to: map.get(e.to) });
    }
  }
  selectOnly(created.map((c) => c.id));
  renderEdges();
  syncAll();
  markDirty();
}

export function addEdge(from, to) {
  if (!from || !to || from === to) return;
  const p = state.project;
  if (p.edges.some((e) => e.from === from && e.to === to)) {
    toast('这两个节点已经连过了', 'warn', 1600);
    return;
  }
  pushHistory();
  p.edges.push({ id: uid('e'), from, to });
  renderEdges();
  markDirty();
  emit('project:changed');
  const n = getNode(to);
  if (n) syncNode(n);
}

export function getBounds() {
  if (!state.project?.nodes.length) return null;
  let minX = Infinity,
    minY = Infinity,
    maxX = -Infinity,
    maxY = -Infinity;
  for (const n of state.project.nodes) {
    const el = nodeEls.get(n.id);
    const h = el ? el.offsetHeight : 200;
    minX = Math.min(minX, n.x);
    minY = Math.min(minY, n.y);
    maxX = Math.max(maxX, n.x + n.w);
    maxY = Math.max(maxY, n.y + h);
  }
  return { minX, minY, maxX, maxY };
}

export function panToNode(id) {
  const n = getNode(id);
  const el = nodeEls.get(id);
  if (!n) return;
  const vp = document.getElementById('viewport');
  const r = vp.getBoundingClientRect();
  const h = el ? el.offsetHeight : 200;
  state.view.k = clamp(state.view.k, 0.4, 1.4);
  state.view.x = r.width / 2 - (n.x + n.w / 2) * state.view.k;
  state.view.y = r.height / 2 - (n.y + h / 2) * state.view.k;
  applyView();
  selectOnly([id]);
}

/* ───────────────────────── 生成 ───────────────────────── */
/**
 * 一键出片：把所有「有提示词、还没出片、当前也没在跑」的文本节点一次性排上队。
 * 调度那边有并发上限（默认 4），排多了会自动等前面跑完，不会把额度用超。
 */
export async function generateAll(onlyIds = null) {
  if (!state.project) return;

  const isRunning = (n) => {
    const j = n.data?.jobId ? state.jobs.get(n.data.jobId) : null;
    return j && (j.status === 'queued' || j.status === 'running');
  };

  const scope = onlyIds ? state.project.nodes.filter((n) => onlyIds.includes(n.id)) : state.project.nodes;
  const todo = scope.filter(
    (n) =>
      n.type === 'text' &&
      String(n.data?.text || '').trim() &&
      !n.data?.videoUrl &&
      !isRunning(n),
  );

  if (!todo.length) {
    toast(
      onlyIds ? '选中的节点里没有要出片的（没写提示词 / 已出过 / 正在生成）' : '没有要出片的节点（都出过了，或者正在生成中）',
      'warn',
      3600,
    );
    return;
  }

  // 额度预测：不够就先说一声（还是允许排，可能有的号刚刷新额度）
  {
    const need = todo.reduce((s, n) => s + (clamp(Number(n.data?.duration) || 5, 4, 15)), 0);
    const usable = state.quota?.usable;
    if (typeof usable === 'number' && need > usable) {
      toast(`额度不够：这 ${todo.length} 条要 ${need} 秒，今天可用的号只剩 ${usable} 秒 —— 会有一部分排不上`, 'warn', 5200);
    }
  }

  toast(`正在排 ${todo.length} 条…`, '', 2200);
  let sent = 0;
  for (const n of todo) {
    try {
      await generateVideo(n);
      sent++;
    } catch {
      /* 单条失败不挡后面的 */
    }
    await new Promise((r) => setTimeout(r, 350));
  }
  toast(`已排 ${sent} 条，调度会自动排队（同时最多 4 条）`, 'ok', 4200);
}

async function generateVideo(n) {
  if (!state.project) return;

  // 同一个节点只能有一条在跑：连点两次会生成两条、扣两次额度
  {
    const running = n.data?.jobId ? state.jobs.get(n.data.jobId) : null;
    if (running && (running.status === 'queued' || running.status === 'running')) {
      toast('这个节点正在生成中，等它出来再点', 'warn', 3000);
      return;
    }
  }

  const all = collectRefs(n);
  const refs = all.filter((r) => r.url);
  const missing = all.filter((r) => !r.url);
  if (missing.length) {
    toast(`有 ${missing.length} 张引用图还没上传（${missing.map((m) => m.handle).join('、')}），这次不带图`, 'warn', 3600);
  }

  // 首帧参考图：只认这个节点上单独设置的那张，不再拿「第一张引用」凑
  let firstFrame = n.data.firstFrame || '';
  const linkSrc = incomingFrameLink(n);
  if (linkSrc) {
    if (!linkSrc.data?.videoUrl) {
      return toast(`接进线的那一段「${nodeTitle(linkSrc)}」还没出片，先把它出了`, 'warn', 4000);
    }
    try {
      toast('正在取上一段的最后一帧…', '', 2000);
      firstFrame = await lastFrameUpload(linkSrc.data.videoUrl);
      // 同步写回节点，这样「首帧参考图」框里看到的就是真正发出去的那张
      n.data.firstFrame = firstFrame;
      const el = nodeEls.get(n.id);
      if (el) renderFrame(n, el);
    } catch (err) {
      return toast(`取最后一帧失败：${err.message}`, 'err', 4000);
    }
  }

  // 提示词要等首帧确定后再拼，这样「首帧参考」那行写得准
  const prompt = composeVideoPrompt(n, {
    linkedFrom: linkSrc ? nodeTitle(linkSrc) : '',
  });
  if (!prompt.trim()) return toast('先写提示词', 'warn');

  const s = state.project.settings;
  const duration = clamp(Number(n.data.duration) || Number(s.duration) || 5, 4, 15);
  const ratio = n.data.ratio || s.ratio || 'auto';

  try {
    const jobId = await runGeneration({
      kind: 'video',
      node: n,
      title: nodeTitle(n),
      payload: {
        prompt,
        firstFrame,
        lastFrame: n.data.lastFrame || '',
        refs: refs.slice(1).map((r) => r.url),
        duration,
        ratio,
        resolution: '720p',
        generateAudio: true,
        watermark: !!s.watermark,
      },
    });
    n.data.jobId = jobId;
    n.data.lastError = '';
    syncNode(n);
    markDirty();
  } catch (e) {
    toast(e.message, 'err');
  }
}

function pickFile() {
  return new Promise((resolve) => {
    const input = document.getElementById('file-input');
    input.value = '';
    input.accept = 'image/*';
    input.onchange = () => resolve(input.files?.[0] || null);
    input.click();
  });
}

async function uploadTo(n) {
  const file = await pickFile();
  if (!file) return;
  try {
    toast('上传中…', '', 1200);
    const url = await api.upload(file);
    n.data.url = url;
    n.data.time = Date.now();
    syncNode(n);
    syncAll();
    markDirty();
  } catch (e) {
    toast(`上传失败：${e.message}`, 'err');
  }
}

/** 上传一张图作为首帧/尾帧参考 */
async function uploadFrameImage(n, kind) {
  const cfg = FRAME_KINDS[kind] || FRAME_KINDS.first;
  const file = await pickFile();
  if (!file) return;
  try {
    toast('上传中…', '', 1200);
    const url = await api.upload(file);
    pushHistory();
    n.data[cfg.key] = url;
    syncNode(n);
    markDirty();
    toast(`已设为${cfg.label}参考图`, 'ok', 1800);
  } catch (e) {
    toast(`上传失败：${e.message}`, 'err');
  }
}

function showPrompt(n) {
  const linkSrc = incomingFrameLink(n);
  const prompt = composeVideoPrompt(n, {
    linkedFrom: linkSrc ? nodeTitle(linkSrc) : '',
  });
  const refs = collectRefs(n);
  showModal({
    title: `${nodeTitle(n)} · 最终提示词`,
    html: `
      <div class="set-hint">下面就是发给视频模型的文本（@引用 会被剥掉，首尾帧作为附件单独上传）。</div>
      <div class="n-label">提示词</div>
      <pre class="modal-pre">${esc(prompt)}</pre>
      <div class="n-label">引用图片（${refs.length}）</div>
      <div class="chips">${
        refs.length
          ? refs
              .map(
                (r) =>
                  `<span class="chip${r.url ? '' : ' chip-missing'}">${esc(r.handle)}${r.name ? ' ' + esc(r.name) : ''}${
                    r.url ? '' : '（未上传，不发送）'
                  }</span>`
              )
              .join('')
          : '<span class="set-hint">没有引用任何图片</span>'
      }</div>`,
    actions: [
      {
        label: '复制提示词',
        onClick: () => {
          navigator.clipboard?.writeText(prompt).then(
            () => toast('已复制', 'ok'),
            () => toast('复制失败', 'err')
          );
          return true;
        },
      },
      { label: '关闭', primary: true },
    ],
  });
}

/* ───────────────────────── 交互 ───────────────────────── */
export function initCanvas() {
  const vp = document.getElementById('viewport');
  const world = document.getElementById('world');

  vp.addEventListener('pointerdown', onPointerDown);
  window.addEventListener('pointermove', onPointerMove);
  window.addEventListener('pointerup', onPointerUp);
  window.addEventListener('pointercancel', onPointerUp);
  vp.addEventListener('wheel', onWheel, { passive: false });
  vp.addEventListener('contextmenu', (e) => e.preventDefault());
  vp.addEventListener('dblclick', (e) => {
    if (e.target.closest('.node') || e.target.closest('g.edge')) return;
    addNode('text', { at: { x: e.clientX, y: e.clientY } });
  });

  // 右键菜单
  const ctx = document.getElementById('ctx-add');
  if (ctx) {
    for (const b of ctx.querySelectorAll('[data-ctx-add]')) {
      b.onclick = () => {
        const kind = b.dataset.kind || '';
        const x = Number(ctx.dataset.x);
        const y = Number(ctx.dataset.y);
        closeAddMenu();
        addNode(b.dataset.ctxAdd, { at: { x, y }, data: kind ? { kind } : {} });
      };
    }
    document.addEventListener(
      'pointerdown',
      (e) => {
        if (!ctx.hidden && !ctx.contains(e.target)) closeAddMenu();
      },
      true
    );
    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') closeAddMenu();
    });
  }

  // 拖时长滑杆（每一秒都能选）
  world.addEventListener(
    'input',
    (e) => {
      const range = e.target.closest?.('[data-role="dur-range"]');
      if (!range) return;
      const nodeEl = range.closest('.node');
      if (!nodeEl) return;
      const n = getNode(nodeEl.dataset.id);
      if (!n) return;
      beginEdit();
      n.data.duration = clamp(Number(range.value) || 5, 4, 15);
      markDirty();
      renderDuration(n, nodeEl);
    },
    true,
  );
  world.addEventListener(
    'change',
    (e) => {
      if (e.target?.dataset?.role === 'dur-range') commitEdit();
    },
    true,
  );

  // 点时长按钮
  world.addEventListener('click', (e) => {
    const chip = e.target.closest?.('[data-dur]');
    if (!chip) return;
    const nodeEl = chip.closest('.node');
    if (!nodeEl) return;
    const n = getNode(nodeEl.dataset.id);
    if (!n) return;
    beginEdit();
    n.data.duration = Number(chip.dataset.dur) || 0;
    markDirty();
    // 先按新值把滑杆/文字摆好，再提交这一批编辑
    renderDuration(n, nodeEl, { force: true });
    commitEdit();
  });

  world.addEventListener('input', (e) => {
    const el = e.target;
    const nodeEl = el.closest('.node');
    if (!nodeEl) return;
    const n = getNode(nodeEl.dataset.id);
    if (!n) return;
    const f = el.dataset.f;
    if (!f) return;
    // 必须在改数据之前拍快照，否则撤销会「撤到改完之后」
    beginEdit();
    if (f === 'duration') n.data.duration = el.value === '' ? 0 : clamp(Number(el.value) || 0, 4, 15);
    else n.data[f] = el.type === 'number' ? Number(el.value) || 0 : el.value;

    if (f === 'text') {
      const t = nodeEl.querySelector('.n-title');
      if (t) t.textContent = nodeTitle(n);
      renderRefChips(n, nodeEl);
      const ref = nodeEl.querySelector('[data-role="meta-ref"]');
      if (ref) ref.textContent = `${collectRefs(n).length} 引用`;
    }
    if (f === 'name') {
      const t = nodeEl.querySelector('.n-title');
      if (t) t.textContent = nodeTitle(n);
    }
    if (f === 'note') renderNote(n, nodeEl);
    markDirty();
  });

  // 输入框失焦就立刻把这一批编辑入栈（不用等 700ms）
  world.addEventListener(
    'blur',
    (e) => {
      if (e.target?.dataset?.f) commitEdit();
    },
    true
  );

  world.addEventListener('change', (e) => {
    const el = e.target;
    if (el.dataset?.set === 'ref') return;

    // 首帧参考图：从图片节点里选一张
    if (el.dataset?.role === 'frame-pick') {
      const nodeEl = el.closest('.node');
      const n = getNode(nodeEl.dataset.id);
      const kind = el.dataset.frameKind || 'first';
      const cfg = FRAME_KINDS[kind];
      if (n && cfg && el.value) {
        pushHistory();
        n.data[cfg.key] = el.value;
        syncNode(n);
        markDirty();
        toast(`已设为${cfg.label}参考图`, 'ok', 1800);
      }
      return;
    }
    // 引用插入
    if (el.dataset?.role === 'ref-picker') {
      const nodeEl = el.closest('.node');
      const n = getNode(nodeEl.dataset.id);
      const h = el.value;
      if (!h || !n) return;
      const ta = nodeEl.querySelector('textarea[data-f="text"]');
      const token = `@${h}`;
      const pos = ta.selectionStart ?? ta.value.length;
      ta.value = ta.value.slice(0, pos) + token + ta.value.slice(pos);
      n.data.text = ta.value;
      ta.focus();
      ta.selectionStart = ta.selectionEnd = pos + token.length;
      el.value = '';
      renderRefChips(n, nodeEl);
      const ref = nodeEl.querySelector('[data-role="meta-ref"]');
      if (ref) ref.textContent = `${collectRefs(n).length} 引用`;
      markDirty();
      return;
    }
    if (el.dataset?.f) markDirty();
  });

  world.addEventListener('click', (e) => {
    const edgeDel = e.target.closest('.e-del');
    if (edgeDel) {
      deleteEdge(edgeDel.dataset.edge);
      return;
    }

    const framePill = e.target.closest('.e-frame');
    if (framePill) {
      toggleFrameLink(framePill.dataset.frameEdge);
      return;
    }

    const noteTab = e.target.closest('.n-note-tab');
    if (noteTab) {
      const nodeEl = noteTab.closest('.node');
      const n = getNode(nodeEl.dataset.id);
      if (n) {
        n.data.noteOpen = !n.data.noteOpen;
        renderNote(n, nodeEl);
        if (n.data.noteOpen) {
          setTimeout(() => nodeEl.querySelector('.n-note textarea')?.focus(), 30);
        }
        markDirty();
      }
      return;
    }

    const frameTab = e.target.closest('[data-frame-tab]');
    if (frameTab) {
      const nodeEl = frameTab.closest('.node');
      const n = getNode(nodeEl.dataset.id);
      const kind = frameTab.dataset.frameTab;
      const cfg = FRAME_KINDS[kind];
      if (n && cfg) {
        n.data[cfg.openKey] = !n.data[cfg.openKey];
        renderFrame(n, nodeEl);
        markDirty();
      }
      return;
    }

    const btn = e.target.closest('[data-act]');
    if (!btn) {
      const del = e.target.closest('.n-del');
      if (del) {
        const nodeEl = del.closest('.node');
        selectOnly([nodeEl.dataset.id]);
        deleteSelection();
      }
      return;
    }
    const nodeEl = btn.closest('.node');
    const n = getNode(nodeEl.dataset.id);
    if (!n) return;
    const act = btn.dataset.act;
    if (act === 'gen-vid') generateVideo(n);
    else if (act === 'upload') uploadTo(n);
    else if (act === 'frame-upload') uploadFrameImage(n, btn.dataset.frameKind || 'first');
    else if (act === 'frame-clear') {
      const kind = btn.dataset.frameKind || 'first';
      const cfg = FRAME_KINDS[kind];
      if (cfg && n.data[cfg.key]) {
        pushHistory();
        n.data[cfg.key] = '';
        syncNode(n);
        markDirty();
        toast(`已清除${cfg.label}参考图`, '', 1600);
      }
    } else if (act === 'show-prompt') showPrompt(n);
    else if (act === 'copy-ref') {
      const h = imageHandles().get(n.id) || '';
      navigator.clipboard?.writeText(`@${h}`).then(
        () => toast(`已复制 @${h}`, 'ok'),
        () => toast('复制失败', 'err')
      );
    }
  });

  window.addEventListener('keydown', (e) => {
    if (e.code === 'Space' && !isTyping(e.target)) {
      spaceDown = true;
      vp.classList.add('space');
      e.preventDefault();
    }
  });
  window.addEventListener('keyup', (e) => {
    if (e.code === 'Space') {
      spaceDown = false;
      vp.classList.remove('space');
    }
  });
}

function isTyping(el) {
  const tag = el?.tagName;
  return tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || el?.isContentEditable;
}

function onWheel(e) {
  e.preventDefault();
  if (e.shiftKey) panBy(-e.deltaY, 0);
  else zoomAt(e.clientX, e.clientY, Math.exp(-e.deltaY * 0.0015));
}

function onPointerDown(e) {
  if (!state.project) return;
  const t = e.target;

  const outPort = t.closest('.port-out');
  if (outPort) {
    const nodeEl = outPort.closest('.node');
    startConnect(e, nodeEl.dataset.id);
    e.preventDefault();
    return;
  }
  if (t.closest('.port-in')) return;

  const edgeG = t.closest('g.edge');
  if (edgeG) {
    state.selectedEdges.clear();
    state.selection.clear();
    state.selectedEdges.add(edgeG.dataset.id);
    syncSelection();
    emit('selection:changed');
    return;
  }

  const handle = t.closest('.n-resize');
  if (handle) {
    const nodeEl = handle.closest('.node');
    const n = getNode(nodeEl.dataset.id);
    drag = { mode: 'resize', n, startW: n.w, sx: e.clientX, before: snapshotNow(), moved: false };
    e.preventDefault();
    return;
  }

  const nodeEl = t.closest('.node');
  if (nodeEl) {
    if (t.closest('input,textarea,select,button,video')) return;
    startNodeDrag(e, nodeEl);
    return;
  }

  if (e.button === 1 || e.button === 2 || spaceDown || e.altKey) {
    startPan(e);
    e.preventDefault();
    return;
  }
  if (e.shiftKey) {
    startMarquee(e);
    return;
  }
  startPan(e);
}

function startPan(e) {
  drag = {
    mode: 'pan',
    sx: e.clientX,
    sy: e.clientY,
    vx: state.view.x,
    vy: state.view.y,
    button: e.button,
    moved: false,
  };
  document.getElementById('viewport').classList.add('panning');
}

/** 右键（没拖动）在光标处弹出「添加」菜单 */
function openAddMenu(x, y) {
  const el = document.getElementById('ctx-add');
  if (!el) return;
  const w = 176;
  const h = 214;
  el.style.left = `${clamp(x, 8, window.innerWidth - w - 8)}px`;
  el.style.top = `${clamp(y, 8, window.innerHeight - h - 8)}px`;
  el.dataset.x = x;
  el.dataset.y = y;
  el.hidden = false;
}

function closeAddMenu() {
  const el = document.getElementById('ctx-add');
  if (el) el.hidden = true;
}

function startNodeDrag(e, nodeEl) {
  const id = nodeEl.dataset.id;
  if (e.shiftKey) {
    if (state.selection.has(id)) {
      state.selection.delete(id);
      syncSelection();
      emit('selection:changed');
      return;
    }
    state.selection.add(id);
    syncSelection();
    emit('selection:changed');
  } else if (!state.selection.has(id)) {
    selectOnly([id]);
  }

  const items = [...state.selection]
    .map((nid) => getNode(nid))
    .filter(Boolean)
    .map((n) => ({ n, x: n.x, y: n.y }));
  drag = { mode: 'nodes', sx: e.clientX, sy: e.clientY, items, before: snapshotNow(), moved: false };
  for (const it of items) nodeEls.get(it.n.id)?.classList.add('dragging');
  const el = nodeEls.get(id);
  if (el) el.style.zIndex = String(zTop++);
  e.preventDefault();
}

function startMarquee(e) {
  const vp = document.getElementById('viewport');
  const r = vp.getBoundingClientRect();
  const box = document.getElementById('marquee');
  drag = { mode: 'marquee', sx: e.clientX, sy: e.clientY, rect: r, box };
  box.hidden = false;
  box.style.left = `${e.clientX - r.left}px`;
  box.style.top = `${e.clientY - r.top}px`;
  box.style.width = '0px';
  box.style.height = '0px';
}

function startConnect(e, fromId) {
  const el = nodeEls.get(fromId);
  if (!el) return;
  const svg = document.getElementById('edges');
  const path = document.createElementNS(SVG_NS, 'path');
  path.setAttribute('class', 'e-temp');
  svg.appendChild(path);
  drag = {
    mode: 'connect',
    from: fromId,
    path,
    ax: parseFloat(el.style.left) + el.offsetWidth,
    ay: parseFloat(el.style.top) + el.offsetHeight / 2,
  };
  for (const p of $$('.port-in')) p.classList.add('hot');
}

function onPointerMove(e) {
  if (!drag) return;

  if (drag.mode === 'pan') {
    state.view.x = drag.vx + (e.clientX - drag.sx);
    state.view.y = drag.vy + (e.clientY - drag.sy);
    if (Math.abs(e.clientX - drag.sx) > 3 || Math.abs(e.clientY - drag.sy) > 3) drag.moved = true;
    applyView();
    return;
  }

  if (drag.mode === 'nodes') {
    const dx = (e.clientX - drag.sx) / state.view.k;
    const dy = (e.clientY - drag.sy) / state.view.k;
    if (Math.abs(dx) > 2 || Math.abs(dy) > 2) drag.moved = true;
    for (const it of drag.items) {
      it.n.x = Math.round(it.x + dx);
      it.n.y = Math.round(it.y + dy);
      const el = nodeEls.get(it.n.id);
      if (el) {
        el.style.left = `${it.n.x}px`;
        el.style.top = `${it.n.y}px`;
      }
    }
    renderEdges();
    return;
  }

  if (drag.mode === 'resize') {
    const w = Math.round(clamp(drag.startW + (e.clientX - drag.sx) / state.view.k, 220, 760));
    if (Math.abs(w - drag.startW) > 2) drag.moved = true;
    drag.n.w = w;
    const el = nodeEls.get(drag.n.id);
    if (el) el.style.width = `${drag.n.w}px`;
    renderEdges();
    return;
  }

  if (drag.mode === 'marquee') {
    const r = drag.rect;
    const x = Math.min(e.clientX, drag.sx) - r.left;
    const y = Math.min(e.clientY, drag.sy) - r.top;
    const w = Math.abs(e.clientX - drag.sx);
    const h = Math.abs(e.clientY - drag.sy);
    Object.assign(drag.box.style, { left: `${x}px`, top: `${y}px`, width: `${w}px`, height: `${h}px` });
    return;
  }

  if (drag.mode === 'connect') {
    const p = screenToWorld(e.clientX, e.clientY);
    drag.path.setAttribute('d', curvePath(drag.ax, drag.ay, p.x, p.y));
    return;
  }
}

function onPointerUp(e) {
  if (!drag) return;
  const mode = drag.mode;

  if (mode === 'pan') {
    document.getElementById('viewport').classList.remove('panning');
    if (drag.button === 2 && !drag.moved) {
      openAddMenu(e.clientX, e.clientY);
    } else {
      markDirty();
    }
  }
  if (mode === 'nodes') {
    for (const it of drag.items) nodeEls.get(it.n.id)?.classList.remove('dragging');
    if (drag.moved && drag.before) pushHistorySnapshot(drag.before);
    markDirty();
  }
  if (mode === 'resize') {
    if (drag.moved && drag.before) pushHistorySnapshot(drag.before);
    markDirty();
  }

  if (mode === 'marquee') {
    drag.box.hidden = true;
    const r = drag.rect;
    const x1 = Math.min(e.clientX, drag.sx);
    const y1 = Math.min(e.clientY, drag.sy);
    const x2 = Math.max(e.clientX, drag.sx);
    const y2 = Math.max(e.clientY, drag.sy);
    if (x2 - x1 > 4 || y2 - y1 > 4) {
      const hit = [];
      for (const [id, el] of nodeEls) {
        const b = el.getBoundingClientRect();
        if (b.left < x2 && b.right > x1 && b.top < y2 && b.bottom > y1) hit.push(id);
      }
      selectOnly(hit, { additive: true });
    } else {
      clearSelection();
    }
  }

  if (mode === 'connect') {
    for (const p of $$('.port-in')) p.classList.remove('hot');
    drag.path.remove();
    const target = document.elementFromPoint(e.clientX, e.clientY)?.closest('.node');
    if (target && target.dataset.id !== drag.from) addEdge(drag.from, target.dataset.id);
  }

  drag = null;
}

/* ───────────────────────── 任务回流 ───────────────────────── */
on('job:done', (ev) => {
  const job = ev.detail;
  const n = getNode(job.nodeId);
  if (!n) return;
  if (n.data.jobId === job.id) n.data.jobId = '';
  if (job.status === 'succeeded' && job.result) {
    const meta = `${job.accountLabel || '池'} · ${(job.result.elapsedMs / 1000).toFixed(0)}s`;
    rememberVideo(n, job.result.url, meta);
    n.data.videoUrl = job.result.url;
    n.data.meta = meta;
    n.data.time = Date.now();
    n.data.lastError = '';
  } else if (job.status === 'failed') {
    n.data.lastError = job.error;
  }
  syncNode(n);
  markDirty();

  // 这段出片了：把下游「尾帧→首帧」的连接补上（之前可能因为没片而没填）
  if (job.status === 'succeeded' && n.data.videoUrl) {
    const outLinks = (state.project?.edges || []).filter((e) => e.from === n.id && e.frameLink);
    for (const e of outLinks) {
      const target = getNode(e.to);
      if (target && !target.data.firstFrame) {
        fillLinkedFirstFrame(e).catch(() => {});
      }
    }
  }
});

on('job:changed', () => {
  for (const n of state.project?.nodes || []) {
    if (n.data.jobId) syncNode(n);
  }
});

on('project:changed', () => updateEmptyHint());

// 撤销/重做后重画整个画布
on('history:restored', () => {
  renderAll();
  emit('project:changed');
});
