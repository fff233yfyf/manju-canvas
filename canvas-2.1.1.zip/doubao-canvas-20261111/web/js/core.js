/* 核心：状态 / API / 视图变换 / 持久化 / 提示词组装 */

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
export const uid = (p = 'n') => `${p}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
export const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
export const esc = (s) =>
  String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

export const bus = new EventTarget();
export const emit = (type, detail) => bus.dispatchEvent(new CustomEvent(type, { detail }));
export const on = (type, fn) => bus.addEventListener(type, fn);

export const state = {
  project: null,
  view: { x: 60, y: 60, k: 1 },
  selection: new Set(),
  selectedEdges: new Set(),
  server: null,
  bridge: null,
  jobs: new Map(),
  dirty: false,
  ready: false,
};

const STORAGE_KEY = 'manju:current';
const STORAGE_BACKUP = 'manju:backup';

/* ───────────────────────── API ───────────────────────── */
async function request(url, opts = {}) {
  const res = await fetch(url, opts);
  const text = await res.text();
  let data;
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    throw new Error(`服务返回了非 JSON 内容：${text.slice(0, 120)}`);
  }
  if (!res.ok || data.ok === false) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}

const jsonInit = (method, body) => ({
  method,
  headers: { 'content-type': 'application/json' },
  body: JSON.stringify(body),
});

export const api = {
  state: () => request('/api/state'),
  pool: () => request('/api/pool'),
  license: () => request('/api/license'),
  activateLicense: (key) => request('/api/license/activate', jsonInit('POST', { key })),
  bridgeChallengeDone: (id) => request(`/api/bridges/${encodeURIComponent(id)}/challenge-done`, jsonInit('POST', {})),
  reloadConfig: () => request('/api/config/reload', { method: 'POST' }),
  quota: (fresh = false) => request(`/api/quota${fresh ? '?fresh=1' : ''}`),
  bridges: () => request('/api/bridges'),
  bridgeLogin: (id) => request(`/api/bridges/${encodeURIComponent(id)}/login`, { method: 'POST' }),
  bridgeLoginStatus: (id) => request(`/api/bridges/${encodeURIComponent(id)}/login-status`),
  bridgeClose: (id) => request(`/api/bridges/${encodeURIComponent(id)}/close`, { method: 'POST' }),
  bridgeWindow: (id, state) =>
    request(`/api/bridges/${encodeURIComponent(id)}/window`, jsonInit('POST', { state })),
  generate: (body) => request('/api/generate', jsonInit('POST', body)),
  jobs: (activeOnly = false) => request(`/api/jobs${activeOnly ? '?active=1' : ''}`),
  cancel: (id) => request(`/api/jobs/${id}/cancel`, { method: 'POST' }),
  async upload(file) {
    const res = await fetch('/api/upload', {
      method: 'POST',
      headers: {
        'x-file-name': encodeURIComponent(file.name || 'upload.png'),
        'content-type': file.type || 'application/octet-stream',
      },
      body: file,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.ok) throw new Error(data.error || `上传失败 HTTP ${res.status}`);
    return data.url;
  },
  listProjects: () => request('/api/projects'),
  getProject: (id) => request(`/api/projects/${id}`),
  saveProject: (p) => request(`/api/projects/${p.id}`, jsonInit('PUT', p)),
  deleteProject: (id) => request(`/api/projects/${id}`, { method: 'DELETE' }),
};

/* ───────────────────────── 项目模型 ───────────────────────── */
export function blankProject(title = '未命名画布') {
  return {
    id: `p_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`,
    title,
    version: 2,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    view: { x: 60, y: 60, k: 1 },
    settings: {
      // 默认留空：让用户自己写（或从「我的画风」里选）
      style: '',
      ratio: 'auto',
      duration: 5,
      generateAudio: true,
      watermark: false,
    },
    nodes: [],
    edges: [],
  };
}

export function normalizeProject(raw) {
  const p = { ...blankProject(), ...(raw || {}) };
  p.settings = { ...blankProject().settings, ...(p.settings || {}) };
  p.view = { x: 60, y: 60, k: 1, ...(p.view || {}) };
  const KNOWN = new Set(['text', 'image']);
  p.nodes = Array.isArray(p.nodes) ? p.nodes.filter((n) => n && n.id) : [];
  p.edges = Array.isArray(p.edges) ? p.edges.filter((e) => e && e.from && e.to) : [];
  for (const n of p.nodes) {
    n.x = Number(n.x) || 0;
    n.y = Number(n.y) || 0;
    n.w = Number(n.w) || 320;
    n.data = n.data || {};
  }
  // 旧版节点迁移：角色卡 → 人物图；镜头卡 → 文本（提示词 + 已有的片子）
  for (const n of p.nodes) {
    if (n.type === 'character') {
      n.type = 'image';
      n.data.kind = n.data.kind || 'character';
    } else if (n.type === 'shot') {
      n.type = 'text';
      const parts = [n.data.prompt || n.data.text || '', n.data.dialogue || ''].filter(Boolean);
      n.data = {
        text: parts.join('\n'),
        duration: Number(n.data.duration) || 0,
        ratio: '',
        jobId: '',
        videoUrl: n.data.videoUrl || '',
        meta: n.data.meta || n.data.vmeta || '',
        time: 0,
        lastError: '',
      };
    } else if (n.type === 'image') {
      n.data.kind = ['character', 'scene', 'prop'].includes(n.data.kind) ? n.data.kind : 'character';
    }
  }
  p.nodes = p.nodes.filter((n) => KNOWN.has(n.type));
  const ids = new Set(p.nodes.map((n) => n.id));
  p.edges = p.edges.filter((e) => ids.has(e.from) && ids.has(e.to));
  return p;
}

export function getNode(id) {
  return state.project?.nodes.find((n) => n.id === id) || null;
}

export function edgesInto(id) {
  return (state.project?.edges || []).filter((e) => e.to === id);
}

/** 向上游 BFS：拿到所有连到我的节点（去重、限深、防环） */
export function upstreamNodes(nodeId, maxDepth = 6) {
  const p = state.project;
  if (!p) return [];
  const byTarget = new Map();
  for (const e of p.edges) {
    if (!byTarget.has(e.to)) byTarget.set(e.to, []);
    byTarget.get(e.to).push(e.from);
  }
  const seen = new Set([nodeId]);
  const out = [];
  let frontier = [nodeId];
  for (let depth = 0; depth < maxDepth && frontier.length; depth++) {
    const next = [];
    for (const id of frontier) {
      for (const from of byTarget.get(id) || []) {
        if (seen.has(from)) continue;
        seen.add(from);
        const n = getNode(from);
        if (n) {
          out.push(n);
          next.push(from);
        }
      }
    }
    frontier = next;
  }
  return out;
}

/* ───────────────────────── 图片编号与引用 ───────────────────────── */
export const IMAGE_KINDS = {
  character: { label: '人物图', short: '人物' },
  scene: { label: '场景图', short: '场景' },
  prop: { label: '道具图', short: '道具' },
};

/** 给每张图片分配可引用的编号：人物1 / 场景2 / 道具1 …（按节点顺序） */
export function imageHandles() {
  const counts = { character: 0, scene: 0, prop: 0 };
  const map = new Map();
  for (const n of state.project?.nodes || []) {
    if (n.type !== 'image') continue;
    const k = IMAGE_KINDS[n.data.kind] ? n.data.kind : 'character';
    counts[k] += 1;
    map.set(n.id, `${IMAGE_KINDS[k].short}${counts[k]}`);
  }
  return map;
}

export function handleOf(nodeId) {
  return imageHandles().get(nodeId) || '';
}

/**
 * 一条提示词用到了哪些图：先看正文里的 @人物1 / @场景2 引用，再看连线接进来的图片节点。
 * 顺序即引用顺序，第一张会作为视频首帧。
 */
export function collectRefs(node) {
  if (!state.project) return [];
  const handles = imageHandles();
  const byHandle = new Map();
  for (const [id, h] of handles) byHandle.set(h, id);

  const ids = [];
  const text = String(node.data?.text || '');
  for (const m of text.matchAll(/@(人物|场景|道具)\s*(\d+)/g)) {
    const id = byHandle.get(`${m[1]}${m[2]}`);
    if (id && !ids.includes(id)) ids.push(id);
  }
  for (const up of upstreamNodes(node.id)) {
    if (up.type === 'image' && !ids.includes(up.id)) ids.push(up.id);
  }

  const out = [];
  for (const id of ids) {
    const n = getNode(id);
    if (!n) continue;
    out.push({
      id,
      handle: handles.get(id) || '',
      name: n.data?.name || '',
      kind: n.data?.kind || 'character',
      url: n.data?.url || '',
    });
  }
  return out;
}

/**
 * 首帧 / 尾帧参考图的来源说明，用来拼进提示词。
 * 只说明「哪张图是首帧/尾帧」+ 怎么用，不描述图里有什么 —— 否则模型会把它当画面内容去画。
 */
export function frameRefLine(node, { linkedFrom = '' } = {}) {
  const images = (state.project?.nodes || []).filter((n) => n.type === 'image' && n.data?.url);
  const byUrl = new Map(images.map((n) => [n.data.url, n]));
  const handles = imageHandles();
  const parts = [];

  // 首帧：接了上一段时优先用「承接」的写法，忽略节点上单独设的首帧
  if (linkedFrom) {
    parts.push(`首帧参考：上一段「${linkedFrom}」的最后一帧`);
  } else if (node.data?.firstFrame) {
    const src = byUrl.get(node.data.firstFrame);
    const name = src ? `${handles.get(src.id) || ''}${src.data.name ? ' ' + src.data.name : ''}`.trim() : '';
    parts.push(`首帧参考：${name || '已上传的图'}`);
  }

  if (node.data?.lastFrame) {
    const src = byUrl.get(node.data.lastFrame);
    const name = src ? `${handles.get(src.id) || ''}${src.data.name ? ' ' + src.data.name : ''}`.trim() : '';
    parts.push(`尾帧参考：${name || '已上传的图'}`);
  }

  if (!parts.length) return '';
  const how = linkedFrom
    ? '（这一段要接在上一段的结尾上：开头的人物、光线、构图与上一段最后一帧保持一致，动作从这里继续往下走）'
    : '（第一张图是开头画面，最后一张图是结尾画面）';
  return `${parts.join('；')}。${how}`;
}

/**
 * 文本节点 → 生视频的提示词。
 * @引用 会被剥掉——图片是作为附件传过去的，不该留在文字里。
 */
export function composeVideoPrompt(node, opts = {}) {
  const s = state.project?.settings || {};
  const raw = String(node.data?.text || '');
  const body = raw
    .replace(/@(人物|场景|道具)\s*\d+/g, ' ')
    .replace(/[（(]\s*[）)]/g, '') // 引用剥掉后留下的空括号
    .replace(/[ \t]{2,}/g, ' ')
    .replace(/\s+([，。、；：！？])/g, '$1')
    .trim();
  return [body, s.style ? `整体画风：${s.style}` : '', frameRefLine(node, opts)].filter(Boolean).join('\n');
}

/* ───────────────────────── 视图 ───────────────────────── */
const MIN_K = 0.1;
const MAX_K = 3;

export function applyView() {
  const { x, y, k } = state.view;
  const world = document.getElementById('world');
  if (world) world.style.transform = `translate3d(${x}px, ${y}px, 0) scale(${k})`;
  const vp = document.getElementById('viewport');
  if (vp) {
    const g1 = 24 * k;
    const g2 = 120 * k;
    vp.style.backgroundSize = `${g1}px ${g1}px, ${g2}px ${g2}px`;
    vp.style.backgroundPosition = `${x}px ${y}px, ${x}px ${y}px`;
  }
  const zl = document.getElementById('zoom-label');
  if (zl) zl.textContent = `${Math.round(k * 100)}%`;
}

export function screenToWorld(clientX, clientY) {
  const vp = document.getElementById('viewport');
  const r = vp.getBoundingClientRect();
  return {
    x: (clientX - r.left - state.view.x) / state.view.k,
    y: (clientY - r.top - state.view.y) / state.view.k,
  };
}

export function viewportCenterWorld() {
  const vp = document.getElementById('viewport');
  const r = vp.getBoundingClientRect();
  return screenToWorld(r.left + r.width / 2, r.top + r.height / 2);
}

export function zoomAt(clientX, clientY, factor) {
  const vp = document.getElementById('viewport');
  const r = vp.getBoundingClientRect();
  const px = clientX - r.left;
  const py = clientY - r.top;
  const oldK = state.view.k;
  const k = clamp(oldK * factor, MIN_K, MAX_K);
  if (k === oldK) return;
  const ratio = k / oldK;
  state.view.x = px - (px - state.view.x) * ratio;
  state.view.y = py - (py - state.view.y) * ratio;
  state.view.k = k;
  applyView();
  schedulePersist();
}

export function panBy(dx, dy) {
  state.view.x += dx;
  state.view.y += dy;
  applyView();
  schedulePersist();
}

export function setZoom(k, anchor) {
  const vp = document.getElementById('viewport');
  const r = vp.getBoundingClientRect();
  const cx = anchor?.x ?? r.left + r.width / 2;
  const cy = anchor?.y ?? r.top + r.height / 2;
  zoomAt(cx, cy, clamp(k, MIN_K, MAX_K) / state.view.k);
}

export function fitBounds(bounds, { padding = 100, maxScale = 1 } = {}) {
  const vp = document.getElementById('viewport');
  if (!vp || !bounds) return;
  const r = vp.getBoundingClientRect();
  const w = Math.max(bounds.maxX - bounds.minX, 260);
  const h = Math.max(bounds.maxY - bounds.minY, 200);
  const k = clamp(Math.min((r.width - padding * 2) / w, (r.height - padding * 2) / h, maxScale), MIN_K, MAX_K);
  state.view.k = k;
  state.view.x = r.width / 2 - ((bounds.minX + bounds.maxX) / 2) * k;
  state.view.y = r.height / 2 - ((bounds.minY + bounds.maxY) / 2) * k;
  applyView();
  schedulePersist();
}

/* ───────────────────────── 持久化 ───────────────────────── */
let autosaveTimer = null;
let remoteFailing = false;

export function setSaveState(kind, text) {
  const el = document.getElementById('save-state');
  if (!el) return;
  el.className = `save-state ${kind || ''}`;
  el.textContent = text;
}

/* ───────────────────────── 撤销 / 重做 ───────────────────────── */
const HISTORY_LIMIT = 80;
const undoStack = [];
const redoStack = [];
let pendingSnap = null;
let pendingTimer = null;

/** 当前画布的快照（字符串，便于比较与去重） */
export function snapshotNow() {
  const p = state.project;
  if (!p) return null;
  return JSON.stringify({ ...p, view: { ...state.view } });
}

function emitHistory() {
  emit('history:changed', { canUndo: undoStack.length > 0, canRedo: redoStack.length > 0 });
}

function pushSnapshot(json) {
  if (!json) return;
  if (undoStack[undoStack.length - 1] === json) return; // 和上一次一样，不重复记
  undoStack.push(json);
  if (undoStack.length > HISTORY_LIMIT) undoStack.shift();
  redoStack.length = 0;
  emitHistory();
}

/** 一次性改动（增删节点、连线、拖动…）之前调它，记下改动前的样子 */
export function pushHistory() {
  commitEdit();
  pushSnapshot(snapshotNow());
}

/** 把之前 capture 到的快照入栈（拖动这类"结束才知道算不算改动"的场景用） */
export function pushHistorySnapshot(json) {
  pushSnapshot(json);
}

/**
 * 连续编辑（打字）用：第一次调用记下初始状态，停手 700ms 后入栈。
 * 这样打一行字是一步撤销，而不是一个字一步。
 */
export function beginEdit() {
  if (pendingSnap === null) {
    pendingSnap = snapshotNow();
    clearTimeout(pendingTimer);
    pendingTimer = setTimeout(commitEdit, 700);
  }
}

export function commitEdit() {
  clearTimeout(pendingTimer);
  if (pendingSnap === null) return;
  const s = pendingSnap;
  pendingSnap = null;
  pushSnapshot(s);
}

function restoreSnapshot(json) {
  const p = normalizeProject(JSON.parse(json));
  state.project = p;
  state.view = { ...(p.view || state.view) };
  state.selection.clear();
  state.selectedEdges.clear();
  applyView();
  emit('project:loaded', p);
  emit('selection:changed');
  emit('history:restored', p);
  markDirty();
}

export function historyState() {
  return { canUndo: undoStack.length > 0, canRedo: redoStack.length > 0 };
}

export function undo() {
  commitEdit();
  if (!undoStack.length) return false;
  const cur = snapshotNow();
  const snap = undoStack.pop();
  if (cur) redoStack.push(cur);
  restoreSnapshot(snap);
  emitHistory();
  return true;
}

export function redo() {
  commitEdit();
  if (!redoStack.length) return false;
  const cur = snapshotNow();
  const snap = redoStack.pop();
  if (cur) undoStack.push(cur);
  restoreSnapshot(snap);
  emitHistory();
  return true;
}

/** 换文档（新建 / 打开文件 / 载入示例）时清空历史 */
export function clearHistory() {
  undoStack.length = 0;
  redoStack.length = 0;
  pendingSnap = null;
  clearTimeout(pendingTimer);
  emitHistory();
}

export function markDirty() {
  state.dirty = true;
  setSaveState('dirty', '未保存');
  // 不做自动保存：什么时候存、存不存，完全由用户点「保存」决定。
  // 这里只负责把「有改动」这个状态显示出来，并在关页/换画布时提醒。
  clearTimeout(autosaveTimer);
  autosaveTimer = null;
}

/**
 * 自动把这幅画布存进「画布列表」（本地 projects/ 目录）。
 * 空画布不存 —— 免得列表里堆一堆空白。
 */
export async function saveCanvasNow() {
  const p = state.project;
  if (!p) return false;
  if (!Array.isArray(p.nodes) || p.nodes.length === 0) {
    setSaveState('', '空画布');
    return false;
  }
  p.view = { ...state.view };
  p.updatedAt = Date.now();
  try {
    await api.saveProject(p);
    state.dirty = false;
    setSaveState('saved', '已存到画布列表');
    return true;
  } catch (e) {
    setSaveState('dirty', '没同步上');
    console.warn('画布自动保存失败', e);
    return false;
  }
}

/** 兼容旧调用：现在不再自动落盘，保存完全由用户触发 */
export function schedulePersist() {}

/** 兼容旧调用：只在内存里留一份备份，打开画布时不会再读它 */
export function saveLocal() {
  const p = state.project;
  if (!p) return;
  p.view = { ...state.view };
  try {
    localStorage.setItem(STORAGE_BACKUP, JSON.stringify(p));
  } catch {
    /* 存不下就算了 */
  }
}

export function loadLocal() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    return normalizeProject(JSON.parse(raw));
  } catch {
    try {
      const raw = localStorage.getItem(STORAGE_BACKUP);
      return raw ? normalizeProject(JSON.parse(raw)) : null;
    } catch {
      return null;
    }
  }
}

export async function saveRemote({ silent = true } = {}) {
  const p = state.project;
  if (!p) return false;
  p.view = { ...state.view };
  try {
    await api.saveProject({ ...p, updatedAt: Date.now() });
    remoteFailing = false;
    state.dirty = false;
    setSaveState('saved', '已保存');
    if (!silent) toast('项目已保存到本地目录', 'ok');
    return true;
  } catch (e) {
    if (!remoteFailing) {
      remoteFailing = true;
      setSaveState('', '仅浏览器草稿');
      if (!silent) toast(`保存到服务端失败：${e.message}`, 'err');
    }
    return false;
  }
}

export function applyProject(project, { resetView = true } = {}) {
  // 切换画布时掐掉还没跑的自动保存，否则它会拿着新画布的内容写回旧 id
  clearTimeout(autosaveTimer);
  state.project = normalizeProject(project);
  state.selection.clear();
  state.selectedEdges.clear();
  state.jobs.clear();
  localStorage.setItem(STORAGE_BACKUP, JSON.stringify(state.project));
  if (resetView) {
    state.view = { ...state.project.view };
  }
  const t = document.getElementById('project-title');
  if (t) t.value = state.project.title || '未命名画布';
  applyView();
  emit('project:loaded', state.project);
  emit('selection:changed');
}

export async function createProject(title = '未命名画布') {
  const p = blankProject(title);
  applyProject(p);
  saveLocal();
  await saveRemote({ silent: true });
  return p;
}

export async function openProject(id) {
  const r = await api.getProject(id);
  applyProject(r.project);
  saveLocal();
  return r.project;
}

/* ───────────────────────── 任务 ───────────────────────── */
let pollTimer = null;
let pollBusy = false;

export function startPolling() {
  if (pollTimer || pollBusy) return;
  pollTimer = setTimeout(pollOnce, 800);
}

async function pollOnce() {
  pollTimer = null;
  if (pollBusy) return;
  pollBusy = true;
  try {
    const r = await api.jobs();
    let changed = false;
    for (const j of r.jobs) {
      const prev = state.jobs.get(j.id);
      const justDone =
        prev && prev.status !== j.status && (j.status === 'succeeded' || j.status === 'failed' || j.status === 'cancelled');
      state.jobs.set(j.id, j);
      if (justDone) emit('job:done', j);
      if (!prev || prev.status !== j.status || prev.progress !== j.progress) changed = true;
    }
    emit('jobs:updated');
    refreshPoolSoon();
    if (changed) emit('job:changed');
    const active = r.jobs.some((j) => j.status === 'queued' || j.status === 'running');
    if (active) startPolling();
    else emit('jobs:idle');
  } catch {
    // 服务端不可用：静默重试一次更慢
    pollTimer = setTimeout(pollOnce, 5000);
  } finally {
    pollBusy = false;
  }
}

export async function runGeneration({ kind, node, payload, title = '' }) {
  const r = await api.generate({ kind, nodeId: node.id, title, payload });
  state.jobs.set(r.id, {
    id: r.id,
    kind,
    nodeId: node.id,
    status: 'queued',
    progress: 0,
    createdAt: Date.now(),
  });
  if (r.mock) toast('模拟模式：未配置 API Key，返回的是占位图', 'warn');
  emit('jobs:updated');
  startPolling();
  return r.id;
}

export async function refreshServerState() {
  try {
    state.server = await api.state();
    emit('server:updated', state.server);
    return state.server;
  } catch {
    return null;
  }
}

let poolTimer = null;
function refreshPoolSoon() {
  if (poolTimer) return;
  poolTimer = setTimeout(async () => {
    poolTimer = null;
    try {
      state.server = { ...(state.server || {}), ...(await api.state()) };
      emit('server:updated', state.server);
    } catch {
      /* ignore */
    }
  }, 700);
}

/* ───────────────────────── UI 小工具 ───────────────────────── */
export function toast(message, type = '', ms = 3200) {
  const root = document.getElementById('toasts');
  if (!root) return;
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = message;
  root.appendChild(el);
  setTimeout(() => {
    el.classList.add('out');
    setTimeout(() => el.remove(), 220);
  }, ms);
}

export function download(filename, content, mime = 'application/json') {
  const blob = new Blob([content], { type: mime });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}

export function formatTime(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  const p = (n) => String(n).padStart(2, '0');
  return `${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

/* ───────────────────────── 画幅 ───────────────────────── */
/** 与后端 RATIO_SIZES 保持一致；Seedream 用明确像素尺寸最稳 */
export const NODE_RATIO_SIZES = {
  '16:9': '2048x1152',
  '9:16': '1152x2048',
  '1:1': '2048x2048',
  '4:3': '2048x1536',
  '3:4': '1536x2048',
  '21:9': '2048x878',
};

/* ───────────────────────── 弹层 ───────────────────────── */
export function showModal({ title = '', html = '', actions = [], onMount } = {}) {
  const root = document.getElementById('modal-root');
  if (!root) return null;
  root.hidden = false;
  root.innerHTML = `
    <div class="modal" role="dialog" aria-modal="true">
      <div class="modal-head">${esc(title)}<button class="x" data-close title="关闭">×</button></div>
      <div class="modal-body">${html}</div>
      ${actions.length ? `<div class="modal-foot">${actions.map((a, i) => `<button class="btn ${a.primary ? 'primary' : ''}" data-act="${i}">${esc(a.label)}</button>`).join('')}</div>` : ''}
    </div>`;
  root.querySelector('[data-close]').onclick = closeModal;
  root.onclick = (e) => {
    if (e.target === root) closeModal();
  };
  actions.forEach((a, i) => {
    const btn = root.querySelector(`[data-act="${i}"]`);
    if (btn) btn.onclick = () => {
      const keep = a.onClick?.();
      if (!keep) closeModal();
    };
  });
  onMount?.(root);
  return root;
}

export function closeModal() {
  const root = document.getElementById('modal-root');
  if (!root) return;
  root.hidden = true;
  root.innerHTML = '';
}
