@echo off
chcp 65001 >nul
cd /d "%~dp0"
title 解除文件锁定

echo.
echo  正在解除「来自网络」的锁定标记...
echo  （如果弹出 Windows 安全中心提示，点「确定」就行）
echo.

powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%~dp0' -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue"

echo  完成。
echo.
echo  以后双击 .bat 就不会再弹「打开这些文件可能会对你的计算机有害」了。
echo.
pause
