@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Doubao 2.0 Fast Canvas - Environment Check

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  [X] Node.js not found.
  echo      Install Node.js 22+ from https://nodejs.org then run this again.
  echo.
  pause
  exit /b 1
)

node "tools\doctor.mjs"
echo.
pause
