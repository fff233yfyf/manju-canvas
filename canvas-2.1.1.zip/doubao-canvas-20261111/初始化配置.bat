@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Doubao 2.0 Fast Canvas - Setup

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  [!] Node.js not found.
  echo.
  echo      Install Node.js 22 or newer from https://nodejs.org
  echo      ^(choose the LTS installer, then run this again^)
  echo.
  pause
  exit /b 1
)

for /f "tokens=*" %%v in ('node -p "process.versions.node.split('.')[0]"') do set NODEMAJOR=%%v
if %NODEMAJOR% LSS 22 (
  echo.
  echo  [!] Your Node.js is too old ^(version %NODEMAJOR%, need 22 or newer^).
  echo      Download the LTS installer from https://nodejs.org and reinstall.
  echo.
  pause
  exit /b 1
)

node "tools\setup.mjs"
pause
