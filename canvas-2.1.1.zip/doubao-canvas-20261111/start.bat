@echo off
chcp 65001 >nul
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo 未找到 Node.js。请先安装 Node 22 或更高版本：https://nodejs.org
  echo.
  pause
  exit /b 1
)

if not exist "config\accounts.json" (
  copy "config\accounts.example.json" "config\accounts.json" >nul
  echo 已创建 config\accounts.json，请填入你的 API Key 后重新运行。
)

start "" cmd /c "timeout /t 2 /nobreak >nul && start http://127.0.0.1:8787"
node server.mjs
pause
