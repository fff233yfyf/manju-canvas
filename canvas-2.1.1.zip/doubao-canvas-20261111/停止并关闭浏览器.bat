@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo.
echo   正在关闭所有豆包浏览器窗口...
echo   （只关程序自己起的那些，不影响你平时用的 Edge）
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo   [X] 没找到 Node.js，先双击「安装Node教程.txt」照着装
  pause
  exit /b 1
)
node tools\stop-all.mjs
echo.
pause