/**
 * 批量登录：把 config 里的桥一个个叫起来等你扫码。
 *
 *   node bridge/login-all.mjs                 从第一条开始，逐条等扫码
 *   node bridge/login-all.mjs --only=web-01,web-02
 *   node bridge/login-all.mjs --from=web-05   从第五条开始（前面扫过的跳过）
 *   node bridge/login-all.mjs --retry         连已登录的也重新扫
 *
 * 一条扫完才弹下一条，所以不会 15 个窗口糊一屏。
 * 扫码在浏览器窗口里完成，脚本只负责「打开 → 等 → 记结果 → 下一条」。
 */
import fs from 'node:fs/promises';
import { CONFIG_FILE } from '../lib/paths.mjs';

const args = process.argv.slice(2);
const opt = (name) => {
  const a = args.find((x) => x.startsWith(`${name}=`));
  return a ? a.slice(name.length + 1) : '';
};
const only = opt('--only') ? opt('--only').split(',').map((s) => s.trim()).filter(Boolean) : null;
const fromId = opt('--from');
const retry = args.includes('--retry');
const perTimeout = (Number(opt('--timeout')) || 180) * 1000;

const useColor = Boolean(process.stdout.isTTY) && !process.env.NO_COLOR;
const c = (code) => (s) => (useColor ? `\x1b[${code}m${s}\x1b[0m` : String(s));
const gray = c(90);
const green = c(32);
const red = c(31);
const yellow = c(33);
const bold = c(1);

const cfg = JSON.parse((await fs.readFile(CONFIG_FILE, 'utf8')).replace(/^\uFEFF/, ''));
let list = (cfg.provider?.bridges || []).filter((b) => b.enabled !== false && b.url);
if (only) list = list.filter((b) => only.includes(b.id));
if (fromId) {
  const i = list.findIndex((b) => b.id === fromId);
  if (i >= 0) list = list.slice(i);
}

if (!list.length) {
  console.log('没有要处理的桥。检查 config/config.json 的 provider.bridges。');
  process.exit(1);
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const base = (b) => String(b.url).replace(/\/+$/, '');

async function getJson(url, timeoutMs = 8000) {
  const res = await fetch(url, { signal: AbortSignal.timeout(timeoutMs) });
  return res.json();
}

console.log(bold(`批量登录 · ${list.length} 个账号`));
console.log(gray('浏览器窗口会一个一个弹出来。扫完一个自动轮到下一个（窗口不会自动关，扫完后统一处理）。\n'));

const result = { ok: [], skipped: [], failed: [], offline: [] };

for (let i = 0; i < list.length; i++) {
  const b = list[i];
  const tag = `[${String(i + 1).padStart(2, ' ')}/${list.length}] ${b.label.padEnd(10)}`;

  let health;
  try {
    health = await getJson(`${base(b)}/health`, 2500);
  } catch {
    console.log(`${tag} ${red('桥没启动')}  ${gray(base(b))}`);
    result.offline.push(b.id);
    continue;
  }

  if (health.browserUp === false && health.error && /占用|退出|启动失败|找不到浏览器/.test(health.error)) {
    console.log(`${tag} ${red('浏览器有问题')}  ${gray(health.error.slice(0, 60))}`);
    result.failed.push(b.id);
    continue;
  }

  if (health.loggedIn && !retry) {
    console.log(`${tag} ${green('已登录')} ${gray('跳过')}`);
    result.skipped.push(b.id);
    continue;
  }

  // 注意：按需模式下 browserUp=false 是正常的，/login 会负责把浏览器拉起来。

  // 触发登录
  try {
    await fetch(`${base(b)}/login`, { method: 'POST', signal: AbortSignal.timeout(15000) });
  } catch (e) {
    console.log(`${tag} ${red('无法触发登录')} ${gray(e.message)}`);
    result.failed.push(b.id);
    continue;
  }

  process.stdout.write(`${tag} ${yellow('等待扫码')} … 请在刚弹出的窗口登录`);

  const t0 = Date.now();
  let done = false;
  let bad = 0;
  while (Date.now() - t0 < perTimeout) {
    await sleep(2000);
    let st;
    try {
      st = await getJson(`${base(b)}/login/status`, 8000);
    } catch {
      bad += 1;
      if (bad > 5) {
        process.stdout.write(`\r${tag} ${red('✗ 查询登录状态失败')}\n`);
        result.failed.push(b.id);
        done = true;
        break;
      }
      continue;
    }
    if (st.ok === false) {
      bad += 1;
      if (bad > 3) {
        process.stdout.write(`\r${tag} ${red('✗ 桥不认这个接口')} ${gray(st.error || '')}\n`);
        result.failed.push(b.id);
        done = true;
        break;
      }
      continue;
    }
    if (st.status === 'logged_in') {
      process.stdout.write(`\r${tag} ${green('✓ 已登录')} ${gray(st.account || '')}\n`);
      result.ok.push(b.id);
      done = true;
      break;
    }
    if (st.status === 'failed') {
      process.stdout.write(`\r${tag} ${red('✗ 失败')} ${gray(st.error || '')}\n`);
      result.failed.push(b.id);
      done = true;
      break;
    }
    if (Date.now() - t0 > 8000 && Date.now() % 6000 < 2100) process.stdout.write('.');
  }

  if (!done) {
    process.stdout.write(`\r${tag} ${yellow('超时')} ${gray(`（${perTimeout / 1000}s 内没扫）`)}\n`);
    result.failed.push(b.id);
  }

  await sleep(600);
}

console.log(`\n${bold('结果')}`);
console.log(`  ${green('新登录')} ${result.ok.length} 个${result.ok.length ? '：' + result.ok.join(', ') : ''}`);
if (result.skipped.length) console.log(`  ${gray('本来就登录着')} ${result.skipped.length} 个`);
if (result.failed.length) console.log(`  ${red('失败/超时')} ${result.failed.length} 个：${result.failed.join(', ')}`);
if (result.offline.length) console.log(`  ${red('桥没启动')} ${result.offline.length} 个：${result.offline.join(', ')}`);

const remaining = [...result.failed, ...result.offline];
if (remaining.length) {
  console.log(`\n重试这些：node bridge/login-all.mjs --only=${remaining.join(',')}`);
} else if (result.ok.length || result.skipped.length) {
  console.log('\n全部就绪。可以去画布「额度」里看一眼，然后开始出片。');
}
console.log('');
