/**
 * 登录判定：只看真正的「会话 cookie」。
 *
 * 踩过的坑：最早把 passport_csrf_token 也算作登录证据，但字节的 passport
 * 对**匿名访客**也会种这个 cookie —— 结果是页面一打开就误判成「已登录」，
 * 用户还没扫码画布就显示绿点，后面点出视频必然失败。
 *
 * 所以现在只认下面几个会话 cookie，并且要求值足够长（匿名占位值通常很短）。
 * 单独抽成模块是为了能脱离浏览器做单元测试（tests/login-detect.test.mjs）。
 */

import crypto from 'node:crypto';

/** 只有登录成功后才出现的会话 cookie */
export const SESSION_COOKIES = ['sessionid', 'sessionid_ss', 'sid_guard', 'sid_tt', 'sid_ucp_v1'];

/** 匿名访客也会有的 cookie，绝不能当登录证据 */
export const ANONYMOUS_COOKIES = ['ttwid', 'passport_csrf_token', 'passport_csrf_token_default', 'msToken', 's_v_web_id'];

/** 会话 cookie 的最小长度（真实 sessionid 都是几十个字符，占位值不会这么长） */
const MIN_VALUE_LENGTH = 16;

/**
 * 登录态的「指纹」：对会话 cookie 做哈希后取前 10 位。
 * 用途不是安全，而是**核对 15 条桥是不是真的登了 15 个不同的账号**
 * —— 如果端口冲突导致多条桥连到同一个浏览器，指纹会完全一样。
 */
function fingerprintOf(hits) {
  const base = hits.map((c) => `${c.name}=${c.value}`).sort().join('|');
  return crypto.createHash('sha256').update(base).digest('hex').slice(0, 10);
}

/**
 * @param {{name:string, value:string}[]} cookies
 * @returns {{loggedIn:boolean, evidence:string, reason:string, fingerprint:string}}
 */
export function detectLogin(cookies) {
  const list = Array.isArray(cookies) ? cookies : [];
  if (!list.length) return { loggedIn: false, evidence: '', reason: '没有任何 cookie（页面可能还没打开）', fingerprint: '' };

  const hits = list.filter(
    (c) => c && SESSION_COOKIES.includes(c.name) && String(c.value || '').length >= MIN_VALUE_LENGTH
  );

  if (hits.length) {
    return {
      loggedIn: true,
      evidence: hits.map((c) => `${c.name}(${String(c.value).length})`).join(', '),
      reason: '存在会话 cookie',
      fingerprint: fingerprintOf(hits),
    };
  }

  // 只看到匿名 cookie：明确判定为未登录
  const anon = list.filter((c) => c && ANONYMOUS_COOKIES.includes(c.name)).map((c) => c.name);
  const nearMiss = list.filter((c) => c && SESSION_COOKIES.includes(c.name) && String(c.value || '').length < MIN_VALUE_LENGTH);

  return {
    loggedIn: false,
    evidence: '',
    reason: nearMiss.length
      ? `有会话 cookie 但值太短（${nearMiss.map((c) => c.name).join(',')}），不像真会话`
      : anon.length
        ? `只有匿名 cookie（${anon.join(',')}），还没登录`
        : '没有会话 cookie',
    fingerprint: '',
  };
}
