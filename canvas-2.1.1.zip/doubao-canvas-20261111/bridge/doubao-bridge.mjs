/**
 * 豆包网页桥 —— 用你已登录的浏览器，把网页端的额度接进画布。
 *
 * 零依赖：用 Node 内置 WebSocket 直连 Edge/Chrome 的调试端口（CDP），不装 Playwright。
 *
 *   node bridge/doubao-bridge.mjs             启动桥（会自动开一个浏览器窗口）
 *   node bridge/doubao-bridge.mjs --probe     打开页面并导出结构，用来填选择器
 *   node bridge/doubao-bridge.mjs --no-browser  只起 HTTP 服务，不碰浏览器
 *
 * 环境变量：
 *   BRIDGE_PORT    桥的端口，默认 8788
 *   BRIDGE_SITE    要驱动的站点，默认 https://www.doubao.com/chat/
 *   DEBUG_PORT    浏览器调试端口，默认 9222
 *   EDGE_PATH     浏览器 exe 路径（默认自动找 Edge / Chrome）
 */
import http from 'node:http';
import fs from 'node:fs/promises';
import { UI, sleep, realClick, pressKey, ensureVisible } from './ui.mjs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { detectLogin } from './login-detect.mjs';
import { classifyChallenge, describeChallenge, hintFor, SNAPSHOT_EXPR } from './challenge.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.BRIDGE_PORT || 8788);
const SITE = process.env.BRIDGE_SITE || 'https://www.doubao.com/chat/';
const DEBUG_PORT = Number(process.env.DEBUG_PORT || 9222);
const PROFILE = process.env.BRIDGE_PROFILE || path.join(HERE, '.profile');
// 无头模式：窗口不出现，但 CDP 照样能驱动页面
const HEADLESS = process.env.BRIDGE_HEADLESS === '1';
// 最小化模式：窗口存在但缩到任务栏，实测 DOM 依然可读写，适合「不想看见窗口」
const MINIMIZED = process.env.BRIDGE_MINIMIZED === '1';
const OUT_DIR = path.join(HERE, 'out');
const DUMP_DIR = path.join(HERE, 'dump');
const SEL_FILE = path.join(HERE, 'selectors.json');


const state = {
  browserUp: false,
  loggedIn: false,
  // 是否真的查过一次登录态。没开浏览器时 checked=false，
  // 这时「未登录」其实只是「不知道」，UI 要显示成「待确认」而不是骗人说没登录。
  checked: false,
  account: '',
  error: '',
  page: null,
  loginReason: '',
  loginEvidence: '',
  fingerprint: '',
  // 豆包明确说「额度用完/次数已用完」的时间戳 —— 比本地估算准，当天的号直接跳过
  quotaExhausted: 0,
  // 这个号怎么都不出片（连续失败）→ 停用到某个时间点，期间不派活
  disabledUntil: 0,
  disabledReason: '',
  failStreak: 0,
  challenge: null,
};

/** 一次「这个号根本生不了片」就自动停用（永久，等用户手动恢复） */
function noteAccountHealth(err) {
  const msg = String(err?.message || err || '');
  // 只有「底层透传 / RAW_PAYLOAD」这类才停用账号；其他回复只展示给用户
  const accountLevel = /RAW_PAYLOAD|底层数据透传|底层透传|透传代理|✅/.test(msg);
  if (!accountLevel) {
    state.failStreak = 0;
    return;
  }
  state.failStreak++;
  console.log(`  账号级失败 ${state.failStreak} 次：${msg.slice(0, 60)}`);
  if (!state.disabledUntil) {
    state.disabledUntil = Date.now() + 365 * 24 * 3600 * 1000;
    state.disabledReason = msg.slice(0, 120);
    console.log('  这个账号自动停用（等手动恢复）');
  }
}

/** 用户点了「我已完成」就置 true，桥立刻重新检查 */
let challengeDoneFlag = false;
const CHALLENGE_WAIT_MS = 5 * 60 * 1000;

/** 上一个「浏览器还活着」的确认时间，避免每个 /health 都去 ping */
let lastBrowserPing = 0;
let browserChild = null;

/* ───────────────── 人机验证（滑块 / 短信） ───────────────── */

/** 看一眼页面是不是在要人机验证 */
async function detectChallenge(cdp) {
  try {
    const snap = await cdp.evaluate(SNAPSHOT_EXPR);
    return snap ? classifyChallenge(snap) : null;
  } catch {
    return null;
  }
}

/**
 * 发现验证页：把窗口交给用户，等他自己过，过了就继续。
 * 绝不尝试自动破解验证码。
 */
async function waitForHuman(cdp, challenge, task) {
  state.challenge = {
    ...challenge,
    label: describeChallenge(challenge),
    hint: hintFor(challenge),
    since: Date.now(),
    taskId: task?.id || '',
  };
  challengeDoneFlag = false;
  state.error = '';

  // 窗口必须露出来，不然用户根本看不到验证码
  await setWindowState('normal').catch(() => {});
  await cdp.send('Page.bringToFront').catch(() => {});
  console.log(`[${task?.id || '-'}] 需要人工验证：${state.challenge.label}（${challenge.evidence}）`);

  const deadline = Date.now() + CHALLENGE_WAIT_MS;
  while (Date.now() < deadline) {
    await sleep(2000);
    const again = await detectChallenge(cdp);
    if (!again) {
      state.challenge = null;
      challengeDoneFlag = false;
      console.log(`[${task?.id || '-'}] 验证已通过，继续`);
      return true;
    }
    if (challengeDoneFlag) {
      challengeDoneFlag = false;
      await sleep(1200);
    }
  }

  state.challenge = null;
  throw new Error(
    `豆包要求${describeChallenge(challenge)}，等了 5 分钟还没通过。浏览器窗口已经弹出来了，去里面完成验证后重试`
  );
}

/** 浏览器会莫名其妙退出（崩溃 / 被安全软件干掉），所以不能只信启动时那次成功 */
async function confirmBrowser() {
  if (!state.browserUp) return;
  if (Date.now() - lastBrowserPing < 8000) return;
  lastBrowserPing = Date.now();
  try {
    const r = await fetch(`http://127.0.0.1:${DEBUG_PORT}/json/version`, { signal: AbortSignal.timeout(800) });
    if (!r.ok) throw new Error('bad');
  } catch {
    state.browserUp = false;
    state.page = null;
    state.error = '浏览器已经退出（调试端口不通），重启桥或点「登录豆包」重开';
  }
}

/* ─────────────────────────── 浏览器 ─────────────────────────── */

function findBrowser() {
  if (process.env.EDGE_PATH) return process.env.EDGE_PATH;
  const candidates = [
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  ];
  return candidates.find(Boolean);
}

async function launchBrowser() {
  const exe = findBrowser();
  try {
    await fs.access(exe);
  } catch {
    throw new Error(`找不到浏览器：${exe}（可以用 EDGE_PATH 指定路径）`);
  }

  // 端口必须是这个桥独占的。多开时如果共用一个端口，会全部连到同一个浏览器，
  // 表现为「登一个号，15 条桥全绿」—— 这是最坑的假象，必须在启动前拦住。
  //
  // 但占用多半只是「上次退出时没关干净的浏览器」还在收尾，所以先等几秒，
  // 别一上来就报错把人吓一跳。
  const portBusy = async () => {
    try {
      const r = await fetch(`http://127.0.0.1:${DEBUG_PORT}/json/version`, { signal: AbortSignal.timeout(600) });
      return r.ok;
    } catch {
      return false;
    }
  };

  // 端口上已经有浏览器 → 直接复用。
  // 这条既解决「上次没关干净、新桥起不来」，也让我们能在不重启桥的情况下换代码调试。
  // 每个桥的端口是独占的，所以占用者只可能是「这个账号自己的浏览器」。
  if (await portBusy()) {
    state.browserUp = true;
    state.error = '';
    lastBrowserPing = Date.now();
    console.log(`复用已打开的浏览器（调试端口 ${DEBUG_PORT}）`);
    return;
  }

  await fs.mkdir(PROFILE, { recursive: true });

  const baseArgs = [
    `--remote-debugging-port=${DEBUG_PORT}`,
    `--user-data-dir=${PROFILE}`,
    '--no-first-run',
    '--no-default-browser-check',
    // 窗口被别的窗口完全盖住时，Chromium 默认会把它当成「不可见」并停止渲染，
    // 豆包就不挂播放器/按钮了。这几个开关让它照常渲染 —— 于是窗口可以安心待在后面。
    '--disable-backgrounding-occluded-windows',
    '--disable-renderer-backgrounding',
    '--disable-background-timer-throttling',
    '--disable-features=msEdgeFirstRunExperience,msEdgeSidebarV2,CalculateNativeWinOcclusion',
    ...(HEADLESS
      ? ['--headless=new', '--window-size=1440,900', '--disable-blink-features=AutomationControlled']
      : ['--window-size=1400,900', '--window-position=-3000,-3000']),
    SITE,
  ];

  const child = spawn(exe, baseArgs, { detached: true, stdio: 'ignore' });
  child.unref();
  browserChild = child;
  child.on('exit', () => {
    if (state.browserUp) {
      state.browserUp = false;
      state.page = null;
      state.error = '浏览器已退出';
      lastBrowserPing = 0;
    }
  });

  // 等调试端口起来
  for (let i = 0; i < 40; i++) {
    await sleep(400);
    try {
      const res = await fetch(`http://127.0.0.1:${DEBUG_PORT}/json/version`, { signal: AbortSignal.timeout(1200) });
      if (res.ok) {
        state.browserUp = true;
        state.error = '';
        lastBrowserPing = Date.now();
        return;
      }
    } catch {
      /* 继续等 */
    }
  }
  throw new Error(`浏览器 16s 内没打开调试端口 ${DEBUG_PORT}，可能被别的进程占用了`);
}

class CDP {
  constructor(ws) {
    this.ws = ws;
    this.seq = 0;
    this.pending = new Map();
    this.waiters = new Map(); // method -> [{ resolve, timer }]
    this.listeners = new Map(); // method -> Set(fn)  （持续监听，不是一次性等待）
    ws.addEventListener('message', (ev) => {
      const msg = JSON.parse(ev.data);
      if (msg.id && this.pending.has(msg.id)) {
        const { resolve, reject } = this.pending.get(msg.id);
        this.pending.delete(msg.id);
        if (msg.error) reject(new Error(msg.error.message));
        else resolve(msg.result);
        return;
      }
      if (msg.method) {
        const subs = this.listeners.get(msg.method);
        if (subs) {
          for (const fn of subs) {
            try {
              fn(msg.params);
            } catch {
              /* 监听器里出错不能影响主流程 */
            }
          }
        }
        const list = this.waiters.get(msg.method);
        if (list && list.length) {
          const w = list.shift();
          clearTimeout(w.timer);
          w.resolve(msg.params);
        }
      }
    });
  }

  /** 持续监听某个 CDP 事件 */
  on(method, fn) {
    if (!this.listeners.has(method)) this.listeners.set(method, new Set());
    this.listeners.get(method).add(fn);
  }

  /** 等一个 CDP 事件（比如 Page.fileChooserOpened） */
  waitEvent(method, timeoutMs = 10000) {
    return new Promise((resolve, reject) => {
      const entry = {
        resolve,
        timer: setTimeout(() => {
          const list = this.waiters.get(method) || [];
          const i = list.indexOf(entry);
          if (i >= 0) list.splice(i, 1);
          reject(new Error(`等事件 ${method} 超时`));
        }, timeoutMs),
      };
      if (!this.waiters.has(method)) this.waiters.set(method, []);
      this.waiters.get(method).push(entry);
    });
  }

  send(method, params = {}, timeoutMs = 30000) {
    const id = ++this.seq;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`CDP ${method} 超时`));
      }, timeoutMs);
      this.pending.set(id, {
        resolve: (v) => {
          clearTimeout(timer);
          resolve(v);
        },
        reject: (e) => {
          clearTimeout(timer);
          reject(e);
        },
      });
      this.ws.send(JSON.stringify({ id, method, params }));
    });
  }

  async evaluate(expression, { awaitPromise = true } = {}) {
    const r = await this.send('Runtime.evaluate', {
      expression,
      awaitPromise,
      returnByValue: true,
      userGesture: true,
    });
    if (r.exceptionDetails) {
      throw new Error(r.exceptionDetails.exception?.description || r.exceptionDetails.text || '页面里报错');
    }
    return r.result?.value;
  }
}

async function attachPage() {
  if (state.page) return state.page;

  // 找一个 page target，没有就新建一个
  let target = null;
  for (let i = 0; i < 20; i++) {
    const list = await fetch(`http://127.0.0.1:${DEBUG_PORT}/json/list`).then((r) => r.json());
    target = list.find((t) => t.type === 'page');
    if (target) break;
    await sleep(400);
  }
  if (!target) {
    await fetch(`http://127.0.0.1:${DEBUG_PORT}/json/new?about:blank`, { method: 'PUT' });
    await sleep(800);
    const list = await fetch(`http://127.0.0.1:${DEBUG_PORT}/json/list`).then((r) => r.json());
    target = list.find((t) => t.type === 'page');
  }
  if (!target) throw new Error('没有可用的浏览器标签页');

  const ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((resolve, reject) => {
    ws.addEventListener('open', resolve, { once: true });
    ws.addEventListener('error', () => reject(new Error('连不上页面调试通道')), { once: true });
  });
  const cdp = new CDP(ws);
  await cdp.send('Page.enable');
  await cdp.send('Runtime.enable');
  await cdp.send('DOM.enable').catch(() => {});
  await cdp.send('Network.enable').catch(() => {});
  state.page = cdp;
  return cdp;
}

async function goto(url, { waitMs = 3500 } = {}) {
  const cdp = await attachPage();
  await cdp.send('Page.navigate', { url });
  await sleep(waitMs);
  for (let i = 0; i < 25; i++) {
    const ready = await cdp.evaluate('document.readyState').catch(() => '');
    if (ready === 'complete') break;
    await sleep(400);
  }
  return cdp;
}

/* ─────────────────────────── 选择器 ─────────────────────────── */

async function loadSelectors() {
  try {
    return JSON.parse(await fs.readFile(SEL_FILE, 'utf8'));
  } catch {
    try {
      return JSON.parse(await fs.readFile(path.join(HERE, 'selectors.example.json'), 'utf8'));
    } catch {
      return {};
    }
  }
}

/* ─────────────────────────── 业务 ─────────────────────────── */

/**
 * 判断是否已登录：只认真正的会话 cookie（见 login-detect.mjs）。
 * 早先版本把匿名访客也有的 passport_csrf_token 当成证据，导致没扫码就显示已登录。
 */
async function checkLogin() {
  if (!state.browserUp) return false;
  try {
    const cdp = await attachPage();

    const { cookies } = await cdp.send('Network.getCookies', {
      urls: ['https://www.doubao.com/', 'https://jimeng.jianying.com/'],
    });

    const r = detectLogin(cookies || []);
    state.checked = true;
    state.loggedIn = r.loggedIn;
    state.loginReason = r.reason;
    state.loginEvidence = r.evidence;
    state.fingerprint = r.fingerprint || '';

    if (r.loggedIn) {
      if (!state.account) state.account = '豆包账号';
      state.error = '';
    } else {
      state.account = '';
    }
    return r.loggedIn;
  } catch (e) {
    state.error = e.message;
    return false;
  }
}

/** 控制浏览器窗口：'minimized' 缩到任务栏 / 'normal' 恢复 */
/** 屏幕外的位置：窗口「可见」但你看不见，Chromium 照常渲染 */
const PARK_POS = { left: -3000, top: -3000, width: 1400, height: 900 };

/** 把窗口停到屏幕外（不最小化，最小化会让页面停渲染） */
async function parkWindow(cdp) {
  try {
    const w = await cdp.send('Browser.getWindowForTarget', {});
    const windowId = w?.windowId ?? w?.result?.windowId;
    if (!windowId) return false;
    await cdp.send('Browser.setWindowBounds', { windowId, bounds: { ...PARK_POS, windowState: 'normal' } });
    return true;
  } catch {
    return false;
  }
}

/** 把窗口挪回屏幕中央（登录扫码时才需要） */
async function showWindow(cdp) {
  try {
    const w = await cdp.send('Browser.getWindowForTarget', {});
    const windowId = w?.windowId ?? w?.result?.windowId;
    if (!windowId) return false;
    await cdp.send('Browser.setWindowBounds', {
      windowId,
      bounds: { left: 40, top: 40, width: 1400, height: 900, windowState: 'normal' },
    });
    return true;
  } catch {
    return false;
  }
}

async function setWindowState(kind) {
  try {
    const cdp = await attachPage();
    const w = await cdp.send('Browser.getWindowForTarget', {});
    const windowId = w?.windowId ?? w?.result?.windowId;
    if (!windowId) return false;
    // 恢复「正常」时必须连位置一起挪回屏幕内：
    // 只改 windowState 的话，窗口可能还停在屏幕外（-3000,-3000），
    // 页面仍然是 hidden，豆包的输入区会渲染不全 —— 这是排查过的坑。
    const bounds =
      kind === 'minimized'
        ? { windowState: 'minimized' }
        : { windowState: 'normal', left: 40, top: 40, width: 1400, height: 900 };
    await cdp.send('Browser.setWindowBounds', { windowId, bounds });
    return true;
  } catch {
    return false;
  }
}

/** 在页面里取回资源的 base64（带上网页自己的登录态，避免直链 403） */
async function grabAsDataUrl(cdp, url) {
  return cdp.evaluate(`(async () => {
    const r = await fetch(${JSON.stringify(url)}, { credentials: 'include' });
    if (!r.ok) throw new Error('下载失败 HTTP ' + r.status);
    const b = await r.blob();
    return await new Promise((res, rej) => {
      const fr = new FileReader();
      fr.onload = () => res(fr.result);
      fr.onerror = () => rej(new Error('读文件失败'));
      fr.readAsDataURL(b);
    });
  })()`);
}

/* ── 页面操作：以下选择器全部来自真机实测（2026-11，Edge 157 / 豆包网页版） ── */
/** 首页点「视频生成」技能胶囊，让输入框进入视频模式 */
/**
 * 强制开一个新对话。
 * 豆包会记住上一个会话的"角色"（比如被要求扮演底层透传代理），
 * 直接沿用旧会话的话，它就会一直回 RAW_PAYLOAD / 提示词文本，永远不出片。
 */
async function startFreshChat(cdp) {
  const onChat = async () => !!(await cdp.evaluate('/\\/chat\\/[0-9]/.test(location.pathname)'));
  if (!(await onChat())) return true;

  const box = await cdp.evaluate(`(() => {
    const cands = [...document.querySelectorAll('button,a,div,span')].filter((e) => {
      const t = (e.textContent || '').trim();
      const r = e.getBoundingClientRect();
      return /^新对话/.test(t) && t.length <= 8 && r.width > 30 && r.height > 18;
    });
    if (!cands.length) return null;
    cands.sort((a, b) => {
      const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect();
      return ra.width * ra.height - rb.width * rb.height;
    });
    const r = cands[0].getBoundingClientRect();
    return { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) };
  })()`);

  if (!box) return false;
  await realClick(cdp, box.x, box.y);
  for (let i = 0; i < 12; i++) {
    await sleep(400);
    if (!(await onChat())) {
      console.log('  已开新对话');
      return true;
    }
  }
  return false;
}

async function ensureVideoSkill(cdp) {
  if (await cdp.evaluate(`!!document.querySelector('${UI.skillBadge}')`)) return true;

  // 只认真正的 <button>（div/span 打不打得到不保证）
  const FINDER = `(() => {
    const els = [...document.querySelectorAll('button')].filter((el) => {
      const t = (el.textContent || '').trim();
      const r = el.getBoundingClientRect();
      return t === '视频生成' && r.width > 20 && r.width < 190 && r.height > 16 && r.height < 64;
    });
    if (!els.length) return null;
    els.sort((a, b) => b.getBoundingClientRect().top - a.getBoundingClientRect().top);
    const r = els[0].getBoundingClientRect();
    return { x: Math.round(r.x + r.width / 2), y: Math.round(r.y + r.height / 2), n: els.length };
  })()`;

  const hasBadge = async () => !!(await cdp.evaluate(`!!document.querySelector('${UI.skillBadge}')`));

  // 首页的技能胶囊是异步渲染的，刚打开页面时还没有，等它
  let box = null;
  for (let i = 0; i < 40; i++) {
    box = await cdp.evaluate(FINDER);
    if (box) break;
    await sleep(400);
  }
  if (!box) throw new Error('首页等不到「视频生成」技能胶囊（约 18 秒）');

  await realClick(cdp, box.x, box.y);
  for (let i = 0; i < 8; i++) {
    await sleep(500);
    if (await hasBadge()) return true;
  }

  // 真实点击没生效 → 用 JS 补一枪（React 对合成 click 也认）
  await cdp.evaluate(`(() => {
    const els = [...document.querySelectorAll('button')].filter((el) => (el.textContent || '').trim() === '视频生成');
    if (!els.length) return false;
    els.sort((a, b) => b.getBoundingClientRect().top - a.getBoundingClientRect().top);
    els[0].click();
    return true;
  })()`);
  for (let i = 0; i < 12; i++) {
    await sleep(500);
    if (await hasBadge()) return true;
  }
  throw new Error('点了「视频生成」但技能没激活');
}

const chipText = (cdp) =>
  cdp.evaluate(`(() => {
    const b = [...document.querySelectorAll('button')].find((x) => /·\\s*\\d+s/.test(x.textContent || ''));
    return b ? b.textContent.replace(/\\s+/g, ' ').trim() : null;
  })()`);

/** 设比例和时长（时长滑块是 0~11 的索引，值 = 4 + index） */
async function applyParams(cdp, ratio, seconds) {
  const want = `${ratio} · ${seconds}s`;

  // 技能刚激活时胶囊还没渲染出来，等它
  let current = null;
  for (let i = 0; i < 12; i++) {
    current = await chipText(cdp);
    if (current) break;
    await sleep(600);
  }
  if (!current) throw new Error('找不到「比例 · 时长」设置胶囊（技能可能没真正激活）');
  if (current === want) return want;

  const box = await cdp.evaluate(`(() => {
    const b = [...document.querySelectorAll('button')].find((x) => /·\\s*\\d+s/.test(x.textContent || ''));
    if (!b) return null;
    const r = b.getBoundingClientRect();
    return { x: Math.round(r.x + r.width / 2), y: Math.round(r.y + r.height / 2) };
  })()`);
  if (!box) throw new Error('找不到「比例 · 时长」设置胶囊');
  await realClick(cdp, box.x, box.y);
  await sleep(1000);

  const rb = await (async () => {
    for (let i = 0; i < 8; i++) {
      const r = await cdp.evaluate(`(() => {
        const p = [...document.querySelectorAll('${UI.panel}')].find((e) => (e.textContent || '').includes('比例'));
        if (!p) return null;
        const b = [...p.querySelectorAll('button')].find((x) => (x.textContent || '').trim() === ${JSON.stringify(ratio)});
        if (!b) return { err: '面板里没有这个比例：' + ${JSON.stringify(ratio)} };
        const r = b.getBoundingClientRect();
        return { x: Math.round(r.x + r.width / 2), y: Math.round(r.y + r.height / 2) };
      })()`);
      if (r) return r;
      await sleep(500);
    }
    return { err: '比例面板没打开' };
  })();
  if (rb?.err) throw new Error(rb.err);
  await realClick(cdp, rb.x, rb.y);
  await sleep(350);

  const focused = await cdp.evaluate(`(() => {
    const p = [...document.querySelectorAll('${UI.panel}')].find((e) => (e.textContent || '').includes('比例'));
    const s = p && p.querySelector('${UI.slider}');
    if (!s) return false;
    s.focus();
    return document.activeElement === s;
  })()`);
  if (!focused) throw new Error('找不到时长滑块');

  await pressKey(cdp, 'Home', 'Home', 36);
  const steps = Math.max(0, Math.min(11, seconds - 4));
  for (let i = 0; i < steps; i++) await pressKey(cdp, 'ArrowRight', 'ArrowRight', 39);
  await sleep(250);

  await pressKey(cdp, 'Escape', 'Escape', 27);
  await sleep(400);

  const now = await chipText(cdp);
  if (now !== want) throw new Error(`参数没设上：现在「${now}」，期望「${want}」`);
  return now;
}

/** 往 ProseMirror 里打字（必须先真实点击聚焦，再 Input.insertText） */
async function typePrompt(cdp, text) {
  await pressKey(cdp, 'Escape', 'Escape', 27);
  await sleep(200);

  const box = await cdp.evaluate(`(() => {
    const el = document.querySelector('${UI.input}');
    if (!el) return null;
    el.focus();
    const r = el.getBoundingClientRect();
    return { x: Math.round(r.x + Math.min(r.width / 2, 220)), y: Math.round(r.y + r.height / 2) };
  })()`);
  if (!box) throw new Error('找不到提示词输入框');
  await realClick(cdp, box.x, box.y);
  await sleep(200);

  await cdp.send('Input.insertText', { text });
  await sleep(400);

  let got = await cdp.evaluate(`(document.querySelector('${UI.input}')?.textContent || '').trim()`);
  if (!got) {
    await cdp.evaluate(`(() => {
      const el = document.querySelector('${UI.input}');
      el.focus();
      document.execCommand('insertText', false, ${JSON.stringify(text)});
      return true;
    })()`);
    await sleep(400);
    got = await cdp.evaluate(`(document.querySelector('${UI.input}')?.textContent || '').trim()`);
  }
  if (!got) throw new Error('提示词没输入进去');
  return got;
}

/**
 * 通过「下载」按钮拿真正的文件。
 *
 * 关键：播放器拿的是带水印的转码流（URL 里 lr=video_gen_watermark_dyn），
 * 而「下载」给的是干净的原片。实测：下载文件 1280x720、无任何水印。
 * 所以绝不能用 video.src 去抓，必须走下载。
 */
/**
 * 关掉视频预览弹层。
 * 下载完之后弹层还开着，豆包的播放器会一直循环播放（有声音），
 * 用户把窗口收起来也能听见 —— 所以收工前必须先关掉 + 暂停。
 */
async function closeVideoPreview(cdp) {
  // 1) 先暂停所有播放器：哪怕关不掉弹层，也不会再出声
  await cdp
    .evaluate(`(() => {
      document.querySelectorAll('video').forEach((v) => { try { v.pause(); v.muted = true; } catch {} });
      return true;
    })()`)
    .catch(() => {});

  // 2) Esc 能关掉大部分弹层
  await pressKey(cdp, 'Escape', 'Escape', 27).catch(() => {});
  await sleep(500);

  // 3) 点右上角那个 × —— 实测这个元素的 testid 就是 canvas_close_btn
  const closer = await cdp.evaluate(`(() => {
    const el = document.querySelector('[data-testid="canvas_close_btn"]');
    if (!el) return null;
    const r = el.getBoundingClientRect();
    if (!r.width || !r.height) return null;
    return { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2), by: 'canvas_close_btn' };
  })()`).catch(() => null);
  if (closer) {
    await realClick(cdp, closer.x, closer.y).catch(() => {});
    await sleep(500);
  }

  // 4) 兜底：按 aria-label / 窗口右上角找
  const box = closer
    ? null
    : await cdp.evaluate(`(() => {
    const W = window.innerWidth;
    const named = [...document.querySelectorAll('[aria-label],[title]')].filter((e) => {
      const lab = (e.getAttribute('aria-label') || '') + ' ' + (e.getAttribute('title') || '');
      const r = e.getBoundingClientRect();
      return /关闭|close/i.test(lab) && r.width > 0 && r.height > 0 && r.width < 90 && r.height < 90;
    });
    if (named.length) {
      named.sort((a, b) => b.getBoundingClientRect().left - a.getBoundingClientRect().left);
      const r = named[0].getBoundingClientRect();
      return { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2), by: 'label' };
    }
    // 兜底：窗口右上角区域里最小的可点元素
    const corner = [...document.querySelectorAll('button,[role="button"],svg,i')].filter((e) => {
      const r = e.getBoundingClientRect();
      const topbar = r.top < 150 && r.left > W * 0.75 && r.width > 10 && r.width < 70 && r.height > 10 && r.height < 70;
      return topbar;
    });
    if (!corner.length) return null;
    corner.sort((a, b) => b.getBoundingClientRect().left - a.getBoundingClientRect().left);
    const r = corner[0].getBoundingClientRect();
    return { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2), by: 'corner' };
  })()`).catch(() => null);

  if (box) {
    await realClick(cdp, box.x, box.y).catch(() => {});
    await sleep(400);
  }

  const left = await cdp.evaluate(`document.querySelectorAll('video').length`).catch(() => 0);
  return left;
}

async function downloadViaButton(cdp, taskId) {
  await ensureVisible(cdp);  const DL = path.join(OUT_DIR, 'dl');
  await fs.rm(DL, { recursive: true, force: true });
  await fs.mkdir(DL, { recursive: true });
  await cdp
    .send('Browser.setDownloadBehavior', { behavior: 'allow', downloadPath: DL, eventsEnabled: true })
    .catch(() => {});

  // 悬停视频，让右下角的操作按钮出现
  const box = await cdp.evaluate(`(() => {
    const v = document.querySelector('video');
    if (!v) return null;
    v.scrollIntoView({ block: 'center' });
    const r = v.getBoundingClientRect();
    return { x: Math.round(r.x + r.width / 2), y: Math.round(r.y + r.height / 2) };
  })()`);
  if (!box) throw new Error('找不到结果视频');
  await cdp.send('Input.dispatchMouseEvent', { type: 'mouseMoved', x: box.x, y: box.y, buttons: 0 });
  await sleep(800);

  const btn = await cdp.evaluate(`(() => {
    // 页面上同名按钮可能有好几个（侧边栏/历史记录里也有），
    // 必须挑「离这个视频最近」的那个，否则会点到别的地方去。
    const vids = [...document.querySelectorAll('video')];
    const v = vids[vids.length - 1];
    if (!v) return null;
    const vr = v.getBoundingClientRect();
    const cx = vr.left + vr.width / 2;
    const cy = vr.top + vr.height / 2;
    const cands = [...document.querySelectorAll('[data-testid="edit_image_hover_tag_download_btn"]')]
      .map((el) => ({ r: el.getBoundingClientRect() }))
      .filter((x) => x.r.width > 0 && x.r.height > 0);
    if (!cands.length) return null;
    cands.sort((a, b) => {
      const da = Math.hypot(a.r.left + a.r.width / 2 - cx, a.r.top + a.r.height / 2 - cy);
      const db = Math.hypot(b.r.left + b.r.width / 2 - cx, b.r.top + b.r.height / 2 - cy);
      return da - db;
    });
    const r = cands[0].r;
    return { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2), count: cands.length };
  })()`);
  if (!btn) throw new Error('视频出来了但找不到「下载」按钮');
  await realClick(cdp, btn.x, btn.y);

  let last = -1;
  let stable = 0;
  for (let i = 0; i < 150; i++) {
    await sleep(1000);
    const files = (await fs.readdir(DL).catch(() => [])).filter(
      (f) => !f.endsWith('.crdownload') && !f.endsWith('.tmp')
    );
    if (!files.length) continue;
    const src = path.join(DL, files[0]);
    const st = await fs.stat(src);
    if (st.size === last) stable++;
    else {
      stable = 0;
      last = st.size;
    }
    if (stable >= 2 && st.size > 10240) {
      const out = path.join(OUT_DIR, `${taskId}.mp4`);
      await fs.rename(src, out);
      return out;
    }
  }

  // 下载按钮点了但没拿到文件 —— 直接从页面里把视频字节抓回来（带登录态，绕开目录/下载行为那些坑）
  console.log('  下载按钮没落盘，改用页面内抓取');
  const src = await cdp.evaluate(`(() => {
    const vids = [...document.querySelectorAll('video')];
    const v = vids[vids.length - 1];
    return v ? (v.currentSrc || v.src || '') : '';
  })()`);
  if (src) {
    const dataUrl = await grabAsDataUrl(cdp, src).catch(() => '');
    const b64 = String(dataUrl).split(',')[1] || '';
    if (b64.length > 20000) {
      const out = path.join(OUT_DIR, `${taskId}.mp4`);
      await fs.mkdir(OUT_DIR, { recursive: true });
      await fs.writeFile(out, Buffer.from(b64, 'base64'));
      console.log('  页面内抓取成功：' + Math.round(b64.length / 1024) + 'KB（可能是带水印的播放流）');
      return out;
    }
  }
  throw new Error('点下载后等文件超时（150 秒）');
}

/**
 * 直接从视频地址把片子取回来（不依赖「下载」按钮，也不依赖播放器挂载）。
 * 用途：客户那边「生成好了但下载按钮没反应 / <video> 一直不挂」时兜底。
 * 注意：这是播放流，可能带水印；正常路径仍然优先走下载按钮拿无水印原片。
 */
async function saveMediaFromUrl(cdp, url, taskId) {
  if (!url) return '';
  const dataUrl = await grabAsDataUrl(cdp, url);
  const b64 = String(dataUrl || '').split(',')[1] || '';
  if (b64.length < 30000) {
    throw new Error('拿到的数据太小（' + Math.round(b64.length / 1024) + 'KB，不像视频）');
  }
  const out = path.join(OUT_DIR, `${taskId}-url.mp4`);
  await fs.mkdir(OUT_DIR, { recursive: true });
  await fs.writeFile(out, Buffer.from(b64, 'base64'));
  return out;
}

/**
 * 一次完整的生成：新对话 → 选技能 → 设参数 → 打字 → 发送 → 等 video → 点下载取原片。
 * 实测：4 秒 720p 大约 150 秒出片。
 */
/**
 * 把一张图传给豆包：点输入框左边的「+」→ 拦下文件选择器 → 塞文件 → 等缩略图出现。
 * 实测这条路能成功（直接给隐藏 input 塞文件，页面不认）。
 */
async function uploadImage(cdp, file, { expectCount = 1 } = {}) {
  await cdp.send('Page.enable').catch(() => {});
  await cdp.send('Page.setInterceptFileChooserDialog', { enabled: true }).catch(() => {});

  const plus = await cdp.evaluate(`(() => {
    const ed = document.querySelector('.tiptap.ProseMirror');
    let box = ed;
    for (let i = 0; i < 8 && box && box.parentElement; i++) box = box.parentElement;
    if (!box) return null;
    const btns = [...box.querySelectorAll('button')]
      .map((b) => ({ b, r: b.getBoundingClientRect() }))
      .filter((x) => x.r.width > 20 && x.r.width < 44 && x.r.height > 20 && x.r.height < 44);
    if (!btns.length) return null;
    btns.sort((a, b) => a.r.left - b.r.left);
    const r = btns[0].r;
    return { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) };
  })()`);
  if (!plus) throw new Error('找不到上传按钮（输入框左边的 +）');

  const chooser = cdp.waitEvent('Page.fileChooserOpened', 8000);
  await realClick(cdp, plus.x, plus.y);
  const ev = await chooser;
  if (!ev?.backendNodeId) throw new Error('没拿到文件选择器的目标');

  await cdp.send('DOM.setFileInputFiles', { backendNodeId: ev.backendNodeId, files: [file] }, 15000);

  // 等缩略图挂上去（数一下有多少张「明显大于图标」的图）
  for (let i = 0; i < 24; i++) {
    await sleep(500);
    const count = await cdp.evaluate(`(() => {
      const ed = document.querySelector('.tiptap.ProseMirror');
      let box = ed;
      for (let i = 0; i < 10 && box && box.parentElement; i++) box = box.parentElement;
      if (!box) return 0;
      return [...box.querySelectorAll('img')].filter((im) => im.naturalWidth > 60 || im.naturalHeight > 60).length;
    })()`);
    if (count >= expectCount) {
      await sleep(600); // 让它把上传真正提交完
      return true;
    }
  }
  throw new Error('参考图上传后等不到缩略图');
}

/* ───────────────── 模型选择（必须是 Seedance 2.0 Fast） ───────────────── */

const WANT_MODEL = 'Seedance 2.0 Fast';

/** 读模型胶囊上的文字 */
async function readModel(cdp) {
  return cdp.evaluate(`(() => {
    const b = [...document.querySelectorAll('button')].find((x) => /Seedance/i.test(x.textContent || ''));
    return b ? (b.textContent || '').replace(/\\s+/g, ' ').trim() : '';
  })()`);
}

/** 等模型胶囊出现（技能刚激活时它还没渲染） */
async function waitModelChip(cdp, timeoutMs = 25000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const chip = await cdp.evaluate(`(() => {
      const b = [...document.querySelectorAll('button')].find((x) => /Seedance/i.test(x.textContent || ''));
      if (!b) return null;
      const r = b.getBoundingClientRect();
      return r.width ? { text: (b.textContent || '').replace(/\\s+/g, ' ').trim(), x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) } : null;
    })()`);
    if (chip) return chip;
    await sleep(500);
  }
  return null;
}

/** 不是 Seedance 2.0 Fast 就点开面板切过去 */
async function ensureModel(cdp, want = WANT_MODEL) {
  for (let attempt = 0; attempt < 3; attempt++) {
    const now = await readModel(cdp);
    if (now.includes('2.0 Fast')) return now;

    const chip = await waitModelChip(cdp, attempt === 0 ? 10000 : 4000);
    if (!chip) throw new Error('找不到模型选择胶囊');
    await realClick(cdp, chip.x, chip.y);

    // 等面板里的目标项出现
    let target = null;
    for (let i = 0; i < 12 && !target; i++) {
      await sleep(400);
      target = await cdp.evaluate(`(() => {
        const want = ${JSON.stringify(want)};
        const cands = [...document.querySelectorAll('div,li,button')]
          .filter((el) => {
            const t = (el.textContent || '').replace(/\\s+/g, ' ').trim();
            return t.startsWith(want) && !t.startsWith('模型');
          })
          .map((el) => ({ el, r: el.getBoundingClientRect() }))
          .filter((x) => x.r.width > 60 && x.r.height >= 30 && x.r.height < 90);
        if (!cands.length) return null;
        cands.sort((a, b) => b.r.height - a.r.height);
        const r = cands[0].r;
        return { text: (cands[0].el.textContent || '').replace(/\\s+/g, ' ').trim(), x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) };
      })()`);
    }
    if (!target) {
      await pressKey(cdp, 'Escape', 'Escape', 27);
      await sleep(300);
      continue;
    }
    console.log(`  切换模型 →「${target.text}」`);
    await realClick(cdp, target.x, target.y);
    await sleep(900);
  }

  const final = await readModel(cdp);
  if (!final.includes('2.0 Fast')) throw new Error(`模型没切到 ${want}（现在是「${final || '未知'}」）`);
  return final;
}

/** 往输入框写一句话并发送（用来回「确认」） */
async function sendChatText(cdp, text) {
  await pressKey(cdp, 'Escape', 'Escape', 27);
  await sleep(200);
  const box = await cdp.evaluate(`(() => {
    const el = document.querySelector('${UI.input}');
    if (!el) return null;
    el.focus();
    const r = el.getBoundingClientRect();
    return r.width ? { x: Math.round(r.x + Math.min(r.width / 2, 220)), y: Math.round(r.y + r.height / 2) } : null;
  })()`);
  if (!box) throw new Error('找不到输入框');
  await realClick(cdp, box.x, box.y);
  await sleep(200);
  await cdp.send('Input.insertText', { text });
  await sleep(350);

  const btn = await cdp.evaluate(`(() => {
    const b = document.querySelector('${UI.send}');
    if (!b) return null;
    const r = b.getBoundingClientRect();
    return r.width ? { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) } : null;
  })()`);
  if (!btn) throw new Error('找不到发送按钮');
  await realClick(cdp, btn.x, btn.y);
  await sleep(600);
}

/** 把画布页面切到前台（豆包标签留后台继续接片子，实测后台标签照样能读） */
async function ensureCanvasTab() {
  try {
    const base = `http://127.0.0.1:${process.env.PORT || 8787}`;
    const list = await fetch(`http://127.0.0.1:${DEBUG_PORT}/json/list`).then((r) => r.json());
    const existing = list.find((t) => t.type === 'page' && (t.url || '').startsWith(base));
    if (existing) {
      await fetch(`http://127.0.0.1:${DEBUG_PORT}/json/activate/${existing.id}`).catch(() => {});
      return true;
    }
    await fetch(`http://127.0.0.1:${DEBUG_PORT}/json/new?${encodeURIComponent(base)}`, { method: 'PUT' });
    return true;
  } catch {
    return false;
  }
}

async function runTask(task) {
  if (!state.browserUp) await launchBrowser();

  // 准备阶段必须让窗口可见：隐藏状态下加载页面，编辑器控件根本不会渲染。
  // （实测：可见状态下加载完再最小化，DOM 和点击都还正常 → 所以点完发送就能收起来）
  // 注意：这里不能从「最小化」恢复 —— Windows 会在恢复时把窗口激活到前台，
  // 客户正在用画布时就会看到豆包窗口跳出来。改由 ensureVisible 只挪位置。
  let cdpRef = null;
  try {
    const r = await runTaskInner(task, (c) => (cdpRef = c));
    return r;
  } catch (err) {
    // 失败时留一张截图，客户把路径发给作者就能定位（多半是豆包改版了）
    const shot = await captureFailureShot(cdpRef, task.id).catch(() => '');
    const e = decorateError(err, shot, cdpRef);
    // 提示词已经发出去了 —— 豆包那边可能正在生成，绝不能换号重试（会出两条片子）
    if (task.__sent) e.code = 'maybe-generating';
    // 「这个号怎么都不出片」的失败：连续两次就把号停用，别再浪费额度
    noteAccountHealth(e);
    throw e;
  } finally {
    // 收工：先把视频预览关掉（不然它会一直在后台播），再把窗口挪回屏幕外。
    // 不最小化：最小化后再恢复会抢焦点，客户会看到窗口弹出来。
    if (cdpRef) {
      await closeVideoPreview(cdpRef).catch(() => {});
      await parkWindow(cdpRef).catch(() => {});
    }
  }
}

/** 把「找不到 XXX」这类错误翻译成人话，并附上截图路径 */

/**
 * 关掉挡路的推广弹窗。
 * 豆包时不时弹「下载电脑版 · 新用户领 30 天订阅权益」这类全屏卡片，
 * 它会盖住输入框和视频卡片，任务就卡住了。
 * 识别方式：卡片文字里带「30 天」或「下载电脑版」，就点它右上角的 ×。
 */
async function dismissPromoPopup(cdp) {
  const hit = await cdp
    .evaluate(`(() => {
      const vis = (e) => {
        const r = e.getBoundingClientRect();
        return r.width > 40 && r.height > 40 && r.bottom > 0 && r.top < innerHeight;
      };
      // 先快速判断有没有弹窗，没有就直接返回（省钱省时间）
      const overlays = [...document.querySelectorAll('[role="dialog"],[class*="modal" i],[class*="dialog" i],[class*="overlay" i]')].filter(vis);
      if (!overlays.length) return null;

      // 在这些弹窗里找「带 30 天 / 下载电脑版」的那张卡片
      let card = null;
      for (const o of overlays) {
        const t = (o.textContent || '').replace(/\\s+/g, '');
        if (/30天|下载电脑版|领.*订阅/.test(t) && t.length < 800) { card = o; break; }
      }
      if (!card) return null;

      const cr = card.getBoundingClientRect();
      const pickClose = () => {
        const sels = [
          '[aria-label*="关闭"]', '[aria-label*="close" i]', '[title*="关闭"]',
          'button[class*="close" i]', '[class*="close" i]', '[class*="Close"]',
        ];
        for (const sel of sels) {
          for (const el of card.querySelectorAll(sel)) {
            if (!vis(el)) continue;
            const r = el.getBoundingClientRect();
            if (r.width > 120 && r.height > 120) continue; // 太大的是卡片本身
            return el;
          }
        }
        // 兜底：找最靠右上角的小按钮
        const cands = [...card.querySelectorAll('button,[role="button"],div,span')].filter((el) => {
          if (!vis(el)) return false;
          const r = el.getBoundingClientRect();
          if (r.width > 56 || r.height > 56) return false;
          const txt = (el.textContent || '').trim();
          const aria = (el.getAttribute('aria-label') || '').trim();
          return /^(×|✕|✖|x|X|关闭)$/.test(txt) || /关闭|close/i.test(aria);
        });
        cands.sort((a, b) => {
          const ra = a.getBoundingClientRect();
          const rb = b.getBoundingClientRect();
          return rb.right - ra.right || ra.top - rb.top;
        });
        return cands[0] || null;
      };

      const el = pickClose();
      if (!el) return { found: true, clicked: false };
      const r = el.getBoundingClientRect();
      return {
        found: true,
        clicked: true,
        x: Math.round(r.left + r.width / 2),
        y: Math.round(r.top + r.height / 2),
        text: (card.textContent || '').replace(/\\s+/g, ' ').trim().slice(0, 30),
      };
    })()`)
    .catch(() => null);

  if (!hit || !hit.found) return false;
  if (!hit.clicked) {
    // 找不到叉：按 Esc 试试（大多数弹窗都吃 Esc）
    await pressKey(cdp, 'Escape').catch(() => {});
    console.log('  发现挡路弹窗但没找到叉，按了 Esc');
    await sleep(500);
    return true;
  }
  await realClick(cdp, hit.x, hit.y);
  console.log(`  关掉了挡路弹窗：${hit.text}`);
  await sleep(700);
  return true;
}

function decorateError(err, shotPath, cdp) {
  if (err?.cancelled) return err; // 用户主动取消，不加工
  const raw = String(err?.message || err || '');
  const uiChanged = /找不到|等不到|没激活|没设上|没输入进去/.test(raw);
  const hidden = /窗口不可见|屏幕锁定/.test(raw);
  // 写文件失败（权限/磁盘）—— 客户把程序放在 Program Files 里时最常见
  const fsDenied = /EACCES|EPERM|EROFS|ENOSPC|EISDIR|权限|拒绝访问|磁盘/.test(raw);

  let msg = raw;
  if (uiChanged) {
    msg += '｜豆包网页的界面可能改版了，这句话需要作者更新选择器';
  }
  if (fsDenied) {
    msg +=
      '｜程序目录写不进去（权限或磁盘满）。把整个文件夹挪到 D 盘这种普通目录再试，' +
      '别放在 C:\\Program Files 下面（Windows 不让普通程序往那里写文件）';
  }
  if (shotPath) {
    msg += `｜失败截图：${shotPath}`;
  }
  const e = new Error(msg);
  e.cause = err;
  e.uiChanged = uiChanged;
  e.hiddenWindow = hidden;
  e.fsDenied = fsDenied;
  return e;
}

/** 失败现场截图，存到 bridge/dump/ */
async function captureFailureShot(cdp, taskId) {
  if (!cdp) return '';
  await fs.mkdir(DUMP_DIR, { recursive: true });
  const file = path.join(DUMP_DIR, `fail-${taskId}-${Date.now()}.png`);
  const r = await cdp.send('Page.captureScreenshot', { format: 'png' }).catch(() => null);
  if (!r?.data) return '';
  await fs.writeFile(file, Buffer.from(r.data, 'base64'));
  return file;
}

function runTaskInner(task, exposeCdp) {
  return runTaskBody(task, exposeCdp);
}

async function runTaskBody(task, exposeCdp) {
  let cdp = await goto(SITE, { waitMs: 1500 });
  exposeCdp?.(cdp);

  // 一进来就确保窗口在屏幕内：隐藏状态下豆包会少渲染一堆控件（模型胶囊、比例胶囊都拿不到）
  await ensureVisible(cdp);

  // 必须是全新对话：旧会话的"角色设定"会让它一直回 RAW_PAYLOAD，根本不出片
  await startFreshChat(cdp).catch(() => {});

  // 一进来就先看看有没有弹人机验证（新设备、异地登录最常触发）
  const firstChallenge = await detectChallenge(cdp);
  if (firstChallenge) {
    await waitForHuman(cdp, firstChallenge, task);
    // 验证过了页面可能停在验证页或刷新过，重新进对话页从头走
    cdp = await goto(SITE, { waitMs: 2000 });
    exposeCdp?.(cdp);
  }
  // 非最小化模式下再提一次前台，确保可见
  await sleep(MINIMIZED ? 900 : 1200);

  await checkLogin();
  if (!state.loggedIn) throw new Error('网页没登录，先在画布上点「登录豆包」');

  // 准备阶段（开技能 → 选模型 → 设比例时长）最容易碰壁：
  // 豆包是单页应用，刚打开时会自己重渲染一次，把已经挂上的技能冲掉。
  // 所以整段重试 3 次，每次失败就重新进一次页面。
  const ratio = task.ratio && task.ratio !== 'auto' ? String(task.ratio) : '自动';
  const seconds = Math.min(15, Math.max(4, Math.round(Number(task.duration) || 4)));

  let prepared = false;
  let lastPrepErr = null;
  for (let attempt = 1; attempt <= 3 && !prepared; attempt++) {
    try {
      await ensureVideoSkill(cdp);
      await sleep(1200); // 给它一点时间重渲染
      const still = await cdp.evaluate(`!!document.querySelector('${UI.skillBadge}')`);
      if (!still) throw new Error('技能刚激活就被页面重置了');
      await ensureModel(cdp); // 必须是 Seedance 2.0 Fast，发现是 Mini 就切
      await applyParams(cdp, ratio, seconds);
      prepared = true;
    } catch (e) {
      lastPrepErr = e;
      if (attempt >= 3) break;
      console.log(`  准备步骤第 ${attempt} 次失败（${e.message}），重新进页面再试`);
      cdp = await goto(SITE, { waitMs: 1500 });
      exposeCdp?.(cdp);
      await sleep(1800);
    }
  }
  if (!prepared) throw lastPrepErr || new Error('准备阶段失败');

  if (task.firstFrame) {
    // 参考图/首帧：走「+ 按钮 → 文件选择器」这条真实路径。
    // 直接对隐藏 input 调 setFileInputFiles 试过，页面不认。
    const tmp = path.join(OUT_DIR, `frame-${Date.now()}.png`);
    await fs.mkdir(OUT_DIR, { recursive: true });
    const b64 = String(task.firstFrame).replace(/^data:image\/\w+;base64,/, '');
    await fs.writeFile(tmp, Buffer.from(b64, 'base64'));
    await uploadImage(cdp, tmp, { expectCount: 1 });
  }

  if (task.lastFrame) {
    // 尾帧：再传一张，页面会按顺序收下（首帧在前、尾帧在后）
    const tmp = path.join(OUT_DIR, `last-${Date.now()}.png`);
    await fs.mkdir(OUT_DIR, { recursive: true });
    const b64 = String(task.lastFrame).replace(/^data:image\/\w+;base64,/, '');
    await fs.writeFile(tmp, Buffer.from(b64, 'base64'));
    await uploadImage(cdp, tmp, { expectCount: 2 });
  }

  await typePrompt(cdp, String(task.prompt || ''));
  await sleep(300);

  // 发送前再确认一次「视频生成」技能还挂着。
  // 豆包是单页应用，准备阶段点开的技能可能在中途被重渲染冲掉；
  // 一旦没挂上，它会把提示词当普通聊天处理，回一句「已生成代码 / 我不能直接生成视频」，
  // 片子就没有了（豆包08 就是这么废掉的）。
  if (!(await cdp.evaluate(`!!document.querySelector('${UI.skillBadge}')`))) {
    console.log('  发送前发现技能掉了，重新点一次');
    await ensureVideoSkill(cdp).catch(() => {});
    await sleep(800);
    await ensureModel(cdp).catch(() => {});
    // 技能掉了之后输入框会被清空，提示词要重新打
    await typePrompt(cdp, String(task.prompt || ''));
    await sleep(400);
  }

  // 记下发送前已有的 video 数量，避免把上一轮的结果当成本次产出
  const baseline = await cdp.evaluate(`document.querySelectorAll('video').length`);

  const btn = await (async () => {
    for (let i = 0; i < 10; i++) {
      const b = await cdp.evaluate(`(() => {
        const b = document.querySelector('${UI.send}');
        if (!b) return null;
        const r = b.getBoundingClientRect();
        return r.width > 0 ? { x: Math.round(r.x + r.width / 2), y: Math.round(r.y + r.height / 2) } : null;
      })()`);
      if (b) return b;
      await sleep(500);
    }
    return null;
  })();
  if (!btn) throw new Error('找不到发送按钮');
  await realClick(cdp, btn.x, btn.y);
  // 从这一刻起，豆包那边可能已经在生成了 —— 后面失败也绝不能让池子换号重试
  task.__sent = true;

  // 注意：这里不能把窗口最小化。实测最小化后渲染进程会被冻结，
  // 后续的 CDP 调用（读页面、点确认、等视频）全部挂住，任务直接卡死。
  // 所以出片全程窗口保持可见 —— 这是唯一能稳定跑完的模式。

  // 有些片子生成慢（十几分钟很正常），给足 1 小时再判失败
  const deadline = Date.now() + 60 * 60 * 1000;
  let lastTick = Date.now();
  let hiddenStreak = 0;
  let restored = false;
  let ticks = 0;
  let lastReply = '';
  let everStarted = false;
  let confirmSent = false;
  let canvasTabShown = false;
  let hiddenByUs = false;

  // 边等边记：页面上所有视频请求地址。
  // 万一「下载按钮点不动 / <video> 死活不挂」，还能直接从这些地址把片子抓下来，
  // 不至于生成好了却什么都没落到画布上（客户反馈过这种情况）。
  const mediaUrls = [];
  try {
    cdp.on('Network.responseReceived', (p) => {
      const r = p?.response;
      if (!r) return;
      const url = String(r.url || '');
      const mime = String(r.mimeType || '');
      if (!url) return;
      const isVideo = /^video\//i.test(mime) || /\.(mp4|mov|webm)(\?|#|$)/i.test(url);
      if (isVideo && !mediaUrls.includes(url)) {
        mediaUrls.push(url);
        if (mediaUrls.length > 12) mediaUrls.shift();
        console.log(`  抓到视频地址（第 ${mediaUrls.length} 个）：${url.slice(0, 120)}`);
      }
    });
    await cdp.send('Network.enable', {}, 5000);
  } catch {
    /* 开不了网络监听也不影响主流程 */
  }

  while (Date.now() < deadline) {
    try {
      await sleep(2000);
      ticks++;

      // 挡路的推广弹窗（「下载电脑版 领 30 天」这类）会盖住输入框/视频卡片，
      // 每两轮看一眼，有就点右上角的叉关掉，别让它卡住任务。
      if (ticks % 2 === 0) await dismissPromoPopup(cdp).catch(() => {});

      // 用户点了「取消这一条」：立刻停手，不再点按钮、不再下载
      if (task.status === 'cancelled') {
        console.log('  任务被用户取消，停止等待');
        const e = new Error('任务已被用户取消');
        e.cancelled = true;
        throw e;
      }

    // 电脑睡眠/休眠会让时间一下跳过很久，任务实际上已经废了，早点说清楚
    const tick = Date.now();
    if (tick - lastTick > 60000) {
      throw new Error('电脑休眠了（时间跳过了 ' + Math.round((tick - lastTick) / 1000) + ' 秒），视频渲染中断。请把电源计划设成「不睡眠」再试');
    }
    lastTick = tick;

    // 图生视频有时会先弹一张「参数确认」卡片，出现了就点掉，否则永远等不到片子
    const confirmBtn = await cdp.evaluate(`(() => {
      const b = [...document.querySelectorAll('button')].find((x) =>
        /^(确认|确认生成|开始生成|确认并生成)$/.test((x.textContent || '').trim())
      );
      if (!b) return null;
      const r = b.getBoundingClientRect();
      return r.width > 10 ? { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) } : null;
    })()`);
    if (confirmBtn) {
      // 页面上有「确认」按钮就直接点它（比在聊天框里打字更稳）
      confirmSent = true;
      await realClick(cdp, confirmBtn.x, confirmBtn.y);
      await sleep(800);
    }

    const st = await cdp.evaluate(`(() => {
      const vids = [...document.querySelectorAll('video')];
      const v = vids[vids.length - 1];
      // 用 textContent：最小化时 innerText 会塌成空串
      const t = document.body.textContent || '';
      const err = (t.match(/(次数已用完|额度不足|生成失败|内容不合规|请稍后重试)/) || [])[1] || '';
      // 豆包最后一条回复：拿不到就算了，拿到的话失败时要显示给用户看
      let reply = '';
      try {
        const sels = [
          '[data-testid="message_text_content"]',
          '[class*="message-content"]',
          '[class*="msg-content"]',
          '[class*="receive-box"]',
        ];
        for (const sel of sels) {
          const els = [...document.querySelectorAll(sel)].filter((e) => (e.textContent || '').trim().length > 4);
          if (els.length) {
            reply = (els[els.length - 1].textContent || '').replace(/\\s+/g, ' ').trim();
            break;
          }
        }
      } catch {}
      return { count: vids.length, src: v ? (v.src || v.currentSrc || '') : '', err, vis: document.visibilityState, text: t.slice(0, 30000), reply: reply.slice(0, 600) };
    })()`);

    // 窗口不可见：我们自己收起的是正常的；不是我们收的就每 15 秒试着拉回来。
    // 关键：提示词已经发出去了就绝不判死 —— 豆包那边可能正在生成，
    // 这时候失败 = 白丢一条片子（还可能触发换号重试、双倍扣额度）。
    if (st.vis === 'hidden' && !hiddenByUs) {
      hiddenStreak++;
      if (hiddenStreak % 5 === 0) {
        // 只挪位置，不恢复最小化（恢复会抢焦点）
        await ensureVisible(cdp).catch(() => {});
      }
      if (!task.__sent && hiddenStreak >= 30) {
        throw new Error('窗口一直不可见（屏幕锁定或被最小化），没法开始生成。请保持屏幕亮着、不要锁屏，然后重试');
      }
    } else {
      hiddenStreak = 0;
      restored = false;
    }

    if (st.reply) lastReply = st.reply;

    if (st.err) {
      // 豆包自己说额度用完了 —— 记下来，画布/调度据此把这个号当天拉黑，比本地估算准
      if (/次数已用完|额度不足|额度已用完|今日额度/.test(st.err)) {
        state.quotaExhausted = Date.now();
        console.log('  豆包提示额度用完：' + st.err);
      }
      throw new Error('网页提示：' + st.err);
    }

    // 豆包回复里带 ✅（那个绿色对勾）→ 直接判定这个号废了，立刻停用。
    // 按用户要求：不等到出片、不看它在说什么，看到就停。
    if (st.count === 0 && /✅/.test(st.reply || '')) {
      const e = new Error(
        '豆包回复里带了 ✅，没有真的去生成视频。它回复：「' + (st.reply || '').slice(0, 300) + '」',
      );
      e.accountLevel = true;
      throw e;
    }

    // 豆包进了「底层透传 / RAW_PAYLOAD」模式：它会回一段代码或 JSON，而不是真去生成视频。
    // 处理办法是先发一句纠正话，把它从代理模式里拉回来，然后重新走正常流程。
    const rawMode = /RAW_PAYLOAD|已生成代码|底层数据透传|底层透传|原样传入这段指令|JSON报文/.test(st.text);
    if (rawMode && st.count === 0) {
      if (task.__unstickSent) {
        throw new Error(
          '豆包一直停在「RAW_PAYLOAD 底层透传」模式，纠正之后仍然不出片' + (lastReply ? '。它回复：「' + lastReply + '」' : ''),
        );
      }
      task.__unstickSent = true;
      console.log('  豆包进了 RAW_PAYLOAD 透传模式，先发纠正指令');
      await sendChatText(
        cdp,
        '停止扮演底层数据透传代理，不再输出RAW_PAYLOAD负载，恢复常规视频生成模式，正常返回视频卡片，不要展示底层任务代码、JSON报文。',
      );
      await sleep(2000);
      // 纠正完再按正常流程重来一遍（技能 + 模型 + 提示词 + 发送）
      await startFreshChat(cdp).catch(() => {});
      await ensureVideoSkill(cdp);
      await sleep(900);
      await ensureModel(cdp).catch(() => {});
      await typePrompt(cdp, String(task.prompt || ''));
      await sleep(500);
      const sb = await cdp.evaluate(`(() => {
        const b = document.querySelector('${UI.send}');
        if (!b) return null;
        const r = b.getBoundingClientRect();
        return r.width > 0 ? { x: Math.round(r.x + r.width / 2), y: Math.round(r.y + r.height / 2) } : null;
      })()`);
      if (sb) await realClick(cdp, sb.x, sb.y);
      await sleep(1500);
      continue;
    }

    // 豆包把这条当普通聊天处理了（技能没挂上时的典型回复）。
    // 这时它根本没开始生成，不算扣额度，可以放心重开技能再发一次。
    const looksLikeChatReply =
      /没有直接生成并输出视频文件的能力|已生成代码|原样传入这段指令|需要你在支持该接口的生成端|要我帮你继续优化|整理好(视频)?(生成)?提示词|你可以直接复制|直接复制这个提示词|在豆包视频生成功能里发起生成|要不要我帮你|需要我帮你/.test(
        st.text,
      );
    if (looksLikeChatReply && st.count === 0) {
      if (task.__resentSkill) {
        throw new Error(
          '豆包没有生成视频，而是回了一段话（视频生成技能没挂上）。它回复：「' +
            (lastReply || '（没读到内容）') +
            '」',
        );
      }
      task.__resentSkill = true;
      console.log('  豆包回的是「不能直接生成视频」这类话 —— 技能没挂上，重开技能再发一次');
      await ensureVideoSkill(cdp).catch(() => {});
      await sleep(900);
      await ensureModel(cdp).catch(() => {});
      await typePrompt(cdp, String(task.prompt || ''));
      await sleep(500);
      const b = await cdp.evaluate(`(() => {
        const b = document.querySelector('${UI.send}');
        if (!b) return null;
        const r = b.getBoundingClientRect();
        return r.width > 0 ? { x: Math.round(r.x + r.width / 2), y: Math.round(r.y + r.height / 2) } : null;
      })()`);
      if (b) await realClick(cdp, b.x, b.y);
      await sleep(1500);
      continue;
    }

    // 豆包已经是「视频生成好了」，但 <video> 还没挂出来 —— 它按需渲染，
    // 窗口不可见时干脆不挂。把窗口抬出来 + 滚到那条消息，逼它渲染。
    if (st.count === 0 && /视频生成好了|视频生成完成/.test(st.text) && ticks % 3 === 0) {
      await ensureVisible(cdp);
      await cdp.evaluate(`(() => {
        window.scrollTo(0, document.body.scrollHeight);
        const els = [...document.querySelectorAll('div,section,article')];
        const hit = els.reverse().find((e) => /视频生成好了|视频生成完成/.test(e.textContent || '') && (e.textContent || '').length < 600);
        if (hit) hit.scrollIntoView({ block: 'center' });
        return true;
      })()`).catch(() => {});

      // 关键：豆包的视频卡片是个封面，<video> 要「点一下播放」才挂出来。
      // 光滚动没用（实测滚完还是 0 个 video），必须真点一下播放按钮。
      const playBox = await cdp.evaluate(`(() => {
        const pick = (sel) => {
          const els = [...document.querySelectorAll(sel)].filter((e) => {
            const r = e.getBoundingClientRect();
            return r.width > 4 && r.height > 4;
          });
          return els[els.length - 1] || null;
        };
        const el = pick('[class*="play-icon"]') || pick('[class*="video-player-wrapper"]');
        if (!el) return null;
        const r = el.getBoundingClientRect();
        return { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) };
      })()`).catch(() => null);
      if (playBox) {
        await realClick(cdp, playBox.x, playBox.y);
        console.log('  点了播放按钮，等播放器挂出来');
      }
      await sleep(600);

      // 还是没挂出 <video>，但我们抓到了视频请求地址 —— 直接从地址取。
      // 这条是「生成好了却没下载」的保底路径：不依赖下载按钮，也不依赖播放器。
      if (mediaUrls.length && ticks % 6 === 0) {
        for (const u of [...mediaUrls].reverse()) {
          try {
            console.log('  下载按钮/播放器没反应，直接从视频地址抓：' + u.slice(0, 100));
            const file = await saveMediaFromUrl(cdp, u, task.id);
            if (file) {
              console.log('  抓到了，存到 ' + file);
              return { path: file, seconds, ratio };
            }
          } catch (e) {
            console.log('  从地址抓失败：' + (e.message || e));
          }
        }
      }
    }

    // 「本次使用 Seedance 2.0 Fast 生成」= 它真的开始出片了。
    // 注意：这里不要收窗口。收起来之后豆包会把播放器/按钮都不渲染，
    // 出片时又得抬回来 —— 一抬就抢焦点，用户正在用画布会很烦。
    // 窗口现在是小窗放在后面，靠抗遮挡启动参数保持渲染。
    if (/本次使用\s*Seedance[\s\S]{0,40}生成/.test(st.text)) everStarted = true;

    if (!canvasTabShown && /本次使用\s*Seedance[\s\S]{0,40}生成/.test(st.text)) {
      canvasTabShown = true;
      console.log('  已开始生成');
    }

    // 每个任务只会进新对话，所以全文里出现这句就是它要确认；发过一次就不再发（防重复触发新生成）。
    if (!confirmSent && /确认后.{0,15}(开始|生成)/.test(st.text)) {
      confirmSent = true;
      console.log('  页面要求确认参数，回复「确认」（只发这一次）');
      try {
        await sendChatText(cdp, '确认');
      } catch (e) {
        console.log('  回复「确认」失败：' + e.message);
      }
      await sleep(1200);
      continue;
    }

    // 生成过程中也可能突然弹验证（大约每 12 秒查一次，别每轮都查）
    if (ticks % 4 === 0) {
      const ch = await detectChallenge(cdp);
      if (ch) await waitForHuman(cdp, ch, task);
    }
    if (st.count > Number(baseline) && st.count > 0) {
      // 必须走「下载」拿原片：播放器那份是带水印的转码流
      // 下载偶尔会失败（按钮没出现/文件没落盘），重试几次，别因为这一次就把片子丢了
      let lastErr = null;
      for (let attempt = 1; attempt <= 3; attempt++) {
        try {
          const file = await downloadViaButton(cdp, task.id);
          await closeVideoPreview(cdp).catch(() => {});
          return { path: file, seconds, ratio };
        } catch (e) {
          lastErr = e;
          console.log(`  下载第 ${attempt} 次失败：${e.message}`);
          await sleep(2500);
        }
      }
      throw lastErr || new Error('下载失败');
    }
    } catch (err) {
      // 提示词已经发出去了：豆包那边可能正在生成。
      // 这里的任何错误都不能让任务结束，否则就白丢一条片子（画布上还看不见）。
      if (!task.__sent) throw err;
      console.log('  出片过程中出错，继续等：' + err.message);
      await sleep(5000);
    }
  }
  // 超时前最后再试一次：期间抓到的视频地址，能抓下来一条算一条
  if (mediaUrls.length) {
    for (const u of [...mediaUrls].reverse()) {
      try {
        console.log('  等待超时，最后试着从视频地址抓：' + u.slice(0, 100));
        const file = await saveMediaFromUrl(cdp, u, task.id);
        if (file) return { path: file, seconds, ratio };
      } catch (e) {
        console.log('  兜底抓取失败：' + (e.message || e));
      }
    }
  }

  throw new Error(
    '豆包一直没有出片（等了 60 分钟）' +
      (lastReply ? '。它最后回复：「' + lastReply + '」' : '') +
      (mediaUrls.length ? `（期间抓到 ${mediaUrls.length} 个视频地址，但都取不下来）` : '（一个视频地址都没抓到）'),
  );
}

/* ─────────────────────────── HTTP ─────────────────────────── */

const tasks = new Map();

// 任务表不能只增不减：完成的任务留 10 分钟够画布来取结果，然后清掉。
const TASK_TTL = 10 * 60 * 1000;
setInterval(() => {
  const now = Date.now();
  for (const [id, t] of tasks) {
    const done = t.status === 'succeeded' || t.status === 'failed' || t.status === 'cancelled';
    if (done && now - (t.createdAt || 0) > TASK_TTL) tasks.delete(id);
  }
}, 5 * 60 * 1000).unref?.();

const json = (res, code, obj) => {
  const body = JSON.stringify(obj);
  res.writeHead(code, { 'content-type': 'application/json; charset=utf-8', 'content-length': Buffer.byteLength(body) });
  res.end(body);
};

async function readJson(req) {
  const chunks = [];
  for await (const c of req) chunks.push(c);
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}');
  } catch {
    return {};
  }
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  const { pathname } = url;
  const method = req.method || 'GET';

  // 手动恢复：清掉自动停用
  if (pathname === '/enable') {
    state.disabledUntil = 0;
    state.disabledReason = '';
    state.failStreak = 0;
    console.log('  账号已手动恢复');
    return json(res, 200, { ok: true });
  }

  if (pathname === '/health') {
    await confirmBrowser();
    return json(res, 200, {
      ok: true,
      name: 'doubao-web-bridge',
      version: '1.0.0',
      loggedIn: state.loggedIn,
      // false = 还没开浏览器查过，状态未知（不等于没登录）
      checked: state.checked,
      account: state.account,
      browserUp: state.browserUp,
      error: state.error,
      // 为什么判定成这个状态 —— 排查「没扫码却显示已登录」时看这里
      loginReason: state.loginReason,
      loginEvidence: state.loginEvidence,
      // 登录态指纹：用来核对多条桥是不是真的登了不同账号
      fingerprint: state.fingerprint,
      // 非空 = 豆包在要人机验证，用户在画布上点「我已完成」后这里会清掉
      challenge: state.challenge,
      // 非 0 = 豆包明确提示过「今日额度用完」（时间戳），当天不该再派活
      quotaExhausted: state.quotaExhausted || 0,
      disabledUntil: state.disabledUntil || 0,
      disabledReason: state.disabledReason || '',
      failStreak: state.failStreak || 0,
      kinds: ['video'],
      queue: { pending: [...tasks.values()].filter((t) => t.status === 'queued').length, running: 0 },
    });
  }

  if (pathname === '/challenge/done' && method === 'POST') {
    // 用户说他处理完了。桥不会盲信：下一轮仍然以页面实际状态为准
    challengeDoneFlag = true;
    return json(res, 200, { ok: true });
  }

  if (pathname === '/challenge' && method === 'GET') {
    return json(res, 200, { ok: true, challenge: state.challenge });
  }

  if (pathname === '/close' && method === 'POST') {
    // 优雅关掉浏览器：Chromium 只有正常退出才会把 cookie 刷到磁盘，
    // 直接 kill 进程有可能丢掉最近的登录态。
    try {
      if (state.browserUp) {
        const cdp = await attachPage();
        await cdp.send('Browser.close', {}, 3000).catch(() => {});
      }
    } catch {
      /* 关不掉就算了 */
    }
    state.browserUp = false;
    state.page = null;
    state.loggedIn = false;
    state.checked = false;
    state.fingerprint = '';
    return json(res, 200, { ok: true, closed: true });
  }

  if (pathname === '/window' && method === 'POST') {
    const body = await readJson(req);
    const want = body.state === 'normal' ? 'normal' : 'minimized';
    const okState = state.browserUp ? await setWindowState(want) : false;
    return json(res, 200, { ok: okState, state: want });
  }

  if (pathname === '/login' && method === 'POST') {
    (async () => {
      try {
        if (!state.browserUp) await launchBrowser();
        // 扫码必须看得见：把窗口从屏幕外/任务栏挪回来
        const cdp = await goto(SITE, { waitMs: 2000 });
        await showWindow(cdp);
        state.error = '';
        // 轮询等用户扫码
        for (let i = 0; i < 150; i++) {
          await sleep(2000);
          if (await checkLogin()) return;
        }
      } catch (e) {
        state.error = e.message;
      }
    })();
    return json(res, 200, { ok: true, status: 'opened' });
  }

  if (pathname === '/login/status') {
    if (state.browserUp && !state.loggedIn) await checkLogin().catch(() => {});
    return json(res, 200, {
      ok: true,
      status: state.loggedIn ? 'logged_in' : state.error ? 'failed' : 'pending',
      account: state.account,
      error: state.error,
    });
  }

  if (pathname === '/generate' && method === 'POST') {
    const body = await readJson(req);
    if (!body.prompt || !String(body.prompt).trim()) return json(res, 200, { ok: false, error: 'prompt 为空' });
    // 一个桥只有一个浏览器页面，两个任务同时驱动会互相抢页面
    if (state.busyTask) {
      return json(res, 200, { ok: false, error: `桥正在跑任务 ${state.busyTask}，等它结束再来` });
    }
    const id = `t_${crypto.randomBytes(4).toString('hex')}`;
    const task = { id, status: 'queued', progress: 0, createdAt: Date.now(), kind: body.kind || 'video' };
    tasks.set(id, task);
    state.busyTask = id;

    runTask({ ...body, id })
      .then((r) => {
        Object.assign(task, { status: 'succeeded', progress: 100, path: r.path });
      })
      .catch((e) => {
        Object.assign(task, { status: 'failed', error: e.message, code: e.code || '' });
      })
      .finally(() => {
        state.busyTask = '';
      });

    return json(res, 200, { ok: true, taskId: id });
  }

  if (pathname.startsWith('/tasks/')) {
    const id = decodeURIComponent(pathname.slice('/tasks/'.length));
    const t = tasks.get(id);
    if (!t) return json(res, 200, { ok: false, error: '任务不存在' });
    if (method === 'DELETE') {
      t.status = 'cancelled';
      return json(res, 200, { ok: true, cancelled: true });
    }
    return json(res, 200, {
      ok: true,
      status: t.status,
      progress: t.progress,
      path: t.path || '',
      url: '',
      error: t.error || '',
      // maybe-generating = 提示词已经发出去，豆包可能正在生成（不能换号重试）
      code: t.code || '',
      kind: t.kind,
      model: 'doubao-web',
    });
  }

  if (pathname === '/dump') {
    return json(res, 200, { ok: true, state });
  }

  return json(res, 404, { ok: false, error: `未知路径 ${pathname}` });
});

const SEL_SITE_FOR_LOGIN = () => SITE;

/* ─────────────────────────── 探测模式 ─────────────────────────── */

async function probe() {
  console.log('正在打开浏览器…（会复用 bridge/.profile，登录一次以后就不用了）');
  await launchBrowser();
  const cdp = await goto(SITE, { waitMs: 3000 });
  console.log('\n请在弹出的窗口里手动登录，并打开「视频生成」页面。');
  console.log('40 秒后自动抓取页面结构…\n');
  await sleep(40000);

  await fs.mkdir(DUMP_DIR, { recursive: true });
  const html = await cdp.evaluate('document.documentElement.outerHTML');
  await fs.writeFile(path.join(DUMP_DIR, 'page.html'), html, 'utf8');

  const info = await cdp.evaluate(`(() => {
    const pick = (el) => ({
      tag: el.tagName.toLowerCase(),
      id: el.id || '',
      cls: (el.className || '').toString().slice(0, 120),
      text: (el.textContent || '').slice(0, 40),
      ph: el.getAttribute('placeholder') || '',
    });
    return {
      url: location.href,
      title: document.title,
      editable: [...document.querySelectorAll('[contenteditable="true"],textarea,input[type="text"]')].slice(0, 20).map(pick),
      buttons: [...document.querySelectorAll('button,[role="button"]')].slice(0, 40).map(pick),
      videos: [...document.querySelectorAll('video')].slice(0, 10).map(v => ({ src: v.src, poster: v.poster })),
      fileInputs: [...document.querySelectorAll('input[type="file"]')].length,
      bodyText: (document.body.textContent || '').slice(0, 800),
    };
  })()`);

  await fs.writeFile(path.join(DUMP_DIR, 'page.json'), JSON.stringify(info, null, 2), 'utf8');
  const shot = await cdp.send('Page.captureScreenshot', { format: 'png' });
  await fs.writeFile(path.join(DUMP_DIR, 'page.png'), Buffer.from(shot.data, 'base64'));

  console.log('已导出到 bridge/dump/ ：');
  console.log('  page.html  页面结构');
  console.log('  page.json  可编辑元素/按钮/视频 清单');
  console.log('  page.png   截图');
  console.log('\n把这三个文件（或它们的路径）交给开发者，就能把选择器写好。');
  console.log('页面 URL：' + info.url);
  console.log('可编辑元素：' + info.editable.length + ' 个，按钮：' + info.buttons.length + ' 个');
  process.exit(0);
}

/* ─────────────────────────── 启动 ─────────────────────────── */

const args = process.argv.slice(2);

if (args.includes('--probe')) {
  await probe();
} else {
  await fs.mkdir(OUT_DIR, { recursive: true });
  server.listen(PORT, '127.0.0.1', () => {
    console.log(`豆包网页桥已启动：http://127.0.0.1:${PORT}`);
    console.log(`  profile（登录态）：${PROFILE}`);
    console.log(`  站点：${SITE}`);
  });
  if (!args.includes('--no-browser') && process.env.BRIDGE_NO_BROWSER !== '1') {
    // 池子会传入错开的延迟，避免 15 个 Edge 同时启动
    const eagerDelay = Math.max(0, Number(process.env.BRIDGE_EAGER_DELAY) || 0);
    setTimeout(() => {
      launchBrowser()
        .then(async () => {
          console.log('浏览器已就绪，正在恢复登录态…');
          // 复用的浏览器可能停在 about:blank，先把窗口导航到豆包
          try {
            const cdp = await attachPage();
            const url = await cdp.evaluate('location.href').catch(() => '');
            if (!url || url.startsWith('about:')) await goto(SITE, { waitMs: 1200 });
          } catch {
            /* 导航失败不影响登录检测 */
          }
          return checkLogin().catch(() => {});
        })
        .catch((e) => {
          state.error = e.message;
          console.error('浏览器启动失败：' + e.message);
          console.error('桥的 HTTP 服务仍然可用，点「登录豆包」会重试打开浏览器。');
        });
    }, eagerDelay).unref?.();
  } else {
    console.log('浏览器按需启动（第一次登录时才开窗口）。');
  }
}
