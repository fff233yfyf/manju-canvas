/**
 * 识别「豆包要求人机验证」的页面特征。
 *
 * 不做任何自动破解 —— 只负责认出来，然后把窗口交给用户。
 * 单独放在这里是为了能跑单元测试：真实滑块很难复现，但页面特征可以造。
 */

/** 在页面里抓一份用于判断的快照 */
export const SNAPSHOT_EXPR = `(() => {
  const text = (document.body && document.body.innerText ? document.body.innerText : '').slice(-5000);
  const iframes = [...document.querySelectorAll('iframe')]
    .map((f) => f.src || '')
    .filter(Boolean)
    .slice(0, 20);
  const hints = [...document.querySelectorAll('[class*="captcha"],[id*="captcha"],[class*="slide-verify"],[class*="slider"]')]
    .slice(0, 30)
    .map((e) => ((e.className && String(e.className)) || '') + ' ' + (e.id || ''))
    .filter((s) => s.trim());
  return { text, iframes, hints, title: document.title || '' };
})()`;

const SLIDER_TEXT = /拖动.*滑块|滑块.*拖动|向右滑动|按住.*滑块|滑动.*完成验证|拖动下方滑块/;
const SMS_TEXT = /短信验证|手机号.*验证|获取验证码|验证码已发送|请输入.*验证码/;

// 扫码验证（豆包怀疑不是本人在用时，会让你用手机扫一下）
const SCAN_TEXT = /扫码验证|扫码确认|扫码完成|请使用.{0,10}(豆包|抖音)?\s*(App|app|客户端|手机).{0,8}扫|手机.{0,6}扫一扫|扫一扫.{0,10}(验证|确认|完成)|二维码.{0,10}(验证|确认|完成)/;
// 普通的登录二维码不算验证，交给登录流程处理
const LOGIN_QR = /扫码登录|登录豆包|手机号登录|其他方式登录|请先登录|登录后/;

const GENERIC_TEXT = /安全验证|人机验证|身份验证|请完成.{0,6}验证|完成验证后继续|异常访问|为确认.{0,8}(是你本人|本人操作)/;
const CAPTCHA_FRAME = /captcha|verify|secsdk|rmc\.bytedance/i;
const SLIDER_HINT = /captcha_verify_slide|slide-verify|slidercaptcha|slider-container|captcha-slider/i;
const CAPTCHA_HINT = /captcha/i;
const QR_HINT = /qrcode|qr-code|qr_code|scan-?code/i;

/**
 * @param {{text?: string, iframes?: string[], hints?: string[], title?: string}} snap
 * @returns {{type: 'scan'|'slider'|'sms'|'unknown', evidence: string}|null}
 */
export function classifyChallenge(snap = {}) {
  const text = String(snap.text || '');
  const iframes = snap.iframes || [];
  const hints = snap.hints || [];

  // 扫码验证优先判断：它和「扫码登录」长得很像，必须先分清楚
  const scanHit = SCAN_TEXT.exec(text);
  const qrHint = hints.find((h) => QR_HINT.test(h));
  const looksLikeLogin = LOGIN_QR.test(text);
  if (scanHit && !(looksLikeLogin && !/验证|确认|本人/.test(text))) {
    return { type: 'scan', evidence: `文字：${scanHit[0]}` };
  }

  const sliderHit = SLIDER_TEXT.exec(text);
  const sliderHint = hints.find((h) => SLIDER_HINT.test(h));
  if (sliderHit || sliderHint) {
    return { type: 'slider', evidence: sliderHit ? `文字：${sliderHit[0]}` : `元素：${sliderHint}` };
  }

  const smsHit = SMS_TEXT.exec(text);
  if (smsHit) return { type: 'sms', evidence: `文字：${smsHit[0]}` };

  const frame = iframes.find((s) => CAPTCHA_FRAME.test(s));
  const hint = hints.find((h) => CAPTCHA_HINT.test(h));
  const generic = GENERIC_TEXT.exec(text);
  if (frame || hint || generic) {
    const ev = frame ? `内嵌验证框：${frame.slice(0, 80)}` : hint ? `元素：${hint}` : `文字：${generic[0]}`;
    // 通用验证里如果还带着二维码元素，按扫码处理（最常见）
    if (qrHint) return { type: 'scan', evidence: `元素：${qrHint}` };
    return { type: 'unknown', evidence: ev };
  }

  return null;
}

/** 给用户看的说法 */
export function describeChallenge(c) {
  if (!c) return '';
  if (c.type === 'scan') return '扫码验证';
  if (c.type === 'slider') return '拖动滑块验证';
  if (c.type === 'sms') return '短信验证码';
  return '人机验证';
}

/** 具体要用户做什么 */
export function hintFor(c) {
  if (!c) return '';
  if (c.type === 'scan') return '拿手机豆包 App 扫一下那个窗口里的二维码';
  if (c.type === 'slider') return '去那个窗口里拖动滑块';
  if (c.type === 'sms') return '去那个窗口里输入短信验证码';
  return '去那个窗口里完成验证';
}
