/**
 * 桥池管理器：一条命令把 config/config.json 里配的桥全部拉起来。
 *
 *   node bridge/run-pool.mjs               起全部启用的桥，自动唤醒并最小化窗口
 *   node bridge/run-pool.mjs --only=web-01,web-02    只起这几条（省内存）
 *   node bridge/run-pool.mjs --no-spawn    只监控，不启动（桥已经开着了）
 *   node bridge/run-pool.mjs --windows     窗口正常显示（默认最小化）
 *   node bridge/run-pool.mjs --lazy        不自动开浏览器（每次要手动点登录）
 *
 * Ctrl+C 会把自己启动的桥一起关掉。
 *
 * 每条桥 = 一个独立浏览器 profile，所以同一个号不会被挤掉。
 * 15 个号 = 15 个 Edge 进程，内存大概 3~6 GB —— 建议按需用 --only。
 */
import fs from 'node:fs/promises';
import fsSync from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { CONFIG_FILE } from '../lib/paths.mjs';
import { closeBrowserByPort } from '../lib/cdp-close.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const BRIDGE = path.join(HERE, 'doubao-bridge.mjs');

/**
 * 浏览器配置目录放哪。
 *
 * 以前放在程序目录里（bridge/.profile-web-01 …），15 个号能吃掉 9~10 GB，
 * 客户看到"这个文件夹 9.5 GB"会以为程序有问题，拷走/备份/卸载也都很难受。
 * 现在默认放到系统应用数据目录，程序目录保持几十兆干净。
 *
 *   Windows: %LOCALAPPDATA%\manju-canvas\profiles\<账号 id>
 *   可用 MANJU_PROFILE_DIR 覆盖（想放别的盘就设它）
 */
function profilesRoot() {
  if (process.env.MANJU_PROFILE_DIR) return process.env.MANJU_PROFILE_DIR;
  const base =
    process.env.LOCALAPPDATA || process.env.XDG_DATA_HOME || path.join(process.env.HOME || process.env.USERPROFILE || HERE, 'AppData', 'Local');
  return path.join(base, 'manju-canvas', 'profiles');
}

/**
 * 程序目录旁边的「配置目录」（同级、同盘）。
 * 跨盘改名会失败，这时候用它：同一块盘上改名是瞬间的，程序目录立刻瘦下来。
 */
const PROJECT_ROOT = path.join(HERE, '..');
const SIBLING_DIR = path.join(path.dirname(PROJECT_ROOT), `${path.basename(PROJECT_ROOT)}-profiles`);
const ROOT_MARKER = path.join(PROJECT_ROOT, 'data', 'profile-root.txt');

/** 记住上一次选定的目录，别每次启动又变 */
async function chosenRoot() {
  if (process.env.MANJU_PROFILE_DIR) return process.env.MANJU_PROFILE_DIR;
  const saved = (await fs.readFile(ROOT_MARKER, 'utf8').catch(() => '')).trim();
  return saved || profilesRoot();
}

/**
 * 老版本把配置放在程序目录里 —— 启动时尝试搬出去。
 * 优先搬系统目录（同盘时瞬间完成）；跨盘则搬到「程序目录旁边」的同级目录。
 */
async function migrateOldProfile(id) {
  const oldDir = path.join(HERE, `.profile-${id}`);
  const exists = async (p) => !!(await fs.stat(p).catch(() => null));
  if (!(await exists(oldDir))) {
    // 没有老目录：新装，直接用当前选定的根目录
    return path.join(await chosenRoot(), id);
  }

  const targets = [profilesRoot(), SIBLING_DIR];
  for (const root of targets) {
    const newDir = path.join(root, id);
    if (await exists(newDir)) return newDir; // 已经搬过了
    try {
      await fs.mkdir(path.dirname(newDir), { recursive: true });
      await fs.rename(oldDir, newDir);
      console.log(`  [配置迁移] ${id} → ${newDir}`);
      if (root !== profilesRoot()) {
        await fs.mkdir(path.dirname(ROOT_MARKER), { recursive: true });
        await fs.writeFile(ROOT_MARKER, root + '\n', 'utf8');
      }
      return newDir;
    } catch {
      /* 跨盘/权限问题，换下一个位置 */
    }
  }

  console.log(`  [配置迁移] ${id} 搬不动，继续用老位置`);
  return oldDir;
}

const args = process.argv.slice(2);
const onlyArg = args.find((a) => a.startsWith('--only='));
const only = onlyArg ? onlyArg.slice('--only='.length).split(',').map((s) => s.trim()).filter(Boolean) : null;
const noSpawn = args.includes('--no-spawn');
const eager = !args.includes('--lazy');
// 没任务时窗口收进任务栏（用户看不到）；有任务时恢复成正常窗口渲染，但不抢焦点。
// 想让它常驻窗口就用 --windows。
const minimized = !args.includes('--windows');
// 默认退出时关掉浏览器；想下次启动更快就加 --keep-browsers
const keepBrowsers = args.includes('--keep-browsers');

const useColor = Boolean(process.stdout.isTTY) && !process.env.NO_COLOR;
const c = (code) => (s) => (useColor ? `\x1b[${code}m${s}\x1b[0m` : String(s));
const bold = c(1);
const gray = c(90);
const green = c(32);
const red = c(31);
const yellow = c(33);

const cfg = JSON.parse((await fs.readFile(CONFIG_FILE, 'utf8')).replace(/^\uFEFF/, ''));
let list = (cfg.provider?.bridges || []).filter((b) => b.enabled !== false && b.url);
if (only) list = list.filter((b) => only.includes(b.id));
if (!list.length) {
  console.log('没有要启动的桥。先编辑 config/config.json 的 provider.bridges。');
  process.exit(1);
}

const portOf = (b) => Number(new URL(b.url).port || 80);
const children = new Map();

// 每条桥的浏览器配置目录（老版本在程序目录里，第一次启动会搬到系统目录）
const PROFILE_DIR = new Map();
for (const b of list) {
  PROFILE_DIR.set(b.id, await migrateOldProfile(b.id));
}
if (!process.argv.includes('--quiet')) {
  console.log(`  配置目录：${profilesRoot()}`);
}
const state = new Map();
const restarts = new Map(); // id -> { count, nextAt } 自动重启退避
let closing = false;

async function health(b) {
  try {
    const res = await fetch(`${String(b.url).replace(/\/+$/, '')}/health`, { signal: AbortSignal.timeout(2000) });
    const j = await res.json();
    return j.ok ? j : null;
  } catch {
    return null;
  }
}

function start(b) {
  const port = portOf(b);
  const profile = PROFILE_DIR.get(b.id) || path.join(profilesRoot(), b.id);
  // 每个桥必须有独立的调试端口，否则会全部连到同一个浏览器（登一个号 15 条全绿）
  const index = list.findIndex((x) => x.id === b.id);
  const debugPort = 9222 + index;

  // 桥的日志单独落盘：客户出问题时，打开 logs\bridge-账号.log 就能看到它点到哪一步了
  let logFd = null;
  try {
    const logDir = path.join(PROJECT_ROOT, 'logs');
    fsSync.mkdirSync(logDir, { recursive: true });
    logFd = fsSync.openSync(path.join(logDir, `bridge-${b.id}.log`), 'a');
    fsSync.writeSync(logFd, `\n===== ${new Date().toISOString()} 启动 ${b.id} =====\n`);
  } catch {
    logFd = null;
  }

  const child = spawn(process.execPath, [BRIDGE], {
    cwd: path.join(HERE, '..'),
    env: {
      ...process.env,
      BRIDGE_PORT: String(port),
      BRIDGE_PROFILE: profile,
      DEBUG_PORT: String(debugPort),
      // 默认「启动即唤醒」：浏览器自己起来加载 cookie，画布上不用逐个点登录。
      // --lazy 可以改回按需启动（省内存，但每次都要点一下）。
      BRIDGE_NO_BROWSER: eager ? '0' : '1',
      // 错开唤醒，避免 15 个 Edge 同时抢 CPU
      BRIDGE_EAGER_DELAY: String(index * 1200),
      // 最小化启动：窗口不挡视线，DOM 照常驱动
      BRIDGE_MINIMIZED: minimized ? '1' : '0',
    },
    stdio: logFd ? ['ignore', logFd, logFd] : 'ignore',
    windowsHide: true,
  });
  child.on('exit', (code) => {
    children.delete(b.id);
    state.set(b.id, { ...(state.get(b.id) || {}), online: false, exited: true });
  });
  children.set(b.id, child);
  return child;
}

const IS_TTY = !!process.stdout.isTTY;
// 2J 清可视区，3J 连滚动缓冲一起清 —— 不然滚上去全是旧帧
const CLEAR = IS_TTY ? '\x1b[2J\x1b[3J\x1b[H' : '';
let lastFrame = '';
const notices = [];
let noticesAt = 0;

function note(msg) {
  notices.push(msg);
  noticesAt = Date.now();
  while (notices.length > 3) notices.shift();
}

function render() {
  if (Date.now() - noticesAt > 20000 && notices.length) notices.length = 0;

  const lines = [];
  const clock = new Date().toLocaleTimeString('zh-CN', { hour12: false });
  lines.push(bold(`豆包账号池 · ${list.length} 条桥`) + gray(`   ${clock}`));
  lines.push(gray('id        端口    状态      今日        账号'));
  for (const b of list) {
    const s = state.get(b.id) || {};
    const h = s.health;
    const st = !h
      ? red('未连接  ')
      : h.browserUp === false
        ? h.checked === false
          ? gray('待确认  ')
          : red('浏览器退出')
        : h.loggedIn === false
          ? yellow('未登录  ')
          : green('已登录  ');
    const used = s.usedSeconds ?? 0;
    const limit = Number(b.dailySeconds) || 0;
    const quota = `${used}/${limit || '不限'}s`.padEnd(10);
    const who = h?.fingerprint ? `#${h.fingerprint}` : h?.account || '-';
    lines.push(`${b.id.padEnd(9)} ${String(portOf(b)).padEnd(6)} ${st}  ${quota}  ${who}`);
  }
  if (notices.length) {
    lines.push('');
    for (const n of notices) lines.push(yellow('· ' + n));
  }
  lines.push(gray('Ctrl+C 停止（会关掉我启动的桥）· 浏览器会自动唤醒并恢复登录态'));

  const frame = lines.join('\n') + '\n';
  if (frame === lastFrame) return; // 没变化就不重画，减少闪烁
  lastFrame = frame;
  process.stdout.write(CLEAR + frame);
}

async function tick() {
  const pending = [];
  for (const b of list) {
    const h = await health(b);
    const prev = state.get(b.id) || {};
    const online = !!h;
    state.set(b.id, { ...prev, health: h, online, exited: online ? false : prev.exited });

    // 桥进程死了就自动拉起来（指数退避，最多 10 次，成功后计数清零）
    if (!online && !children.has(b.id) && !closing) {
      const r = restarts.get(b.id) || { count: 0, nextAt: 0 };
      if (r.count < 10 && Date.now() >= r.nextAt) {
        const delay = Math.min(60000, 2000 * 2 ** r.count);
        restarts.set(b.id, { count: r.count + 1, nextAt: Date.now() + delay });
        start(b);
        pending.push(`${b.id} 掉线，已重启（第 ${r.count + 1} 次）`);
      }
    } else if (online) {
      restarts.delete(b.id);
    }
  }
  if (pending.length) for (const p of pending) note(p);

  // 顺带从画布服务拿秒数（没起也不影响）
  try {
    const q = await fetch(`http://127.0.0.1:${process.env.PORT || 8787}/api/quota`, {
      signal: AbortSignal.timeout(2000),
    }).then((r) => r.json());
    for (const e of q.endpoints || []) {
      const s = state.get(e.id);
      if (s) s.usedSeconds = e.usedSeconds;
    }
  } catch {
    /* 画布没起，不显示秒数 */
  }
}

/* 启动 */
if (!noSpawn) {
  for (const b of list) {
    const h = await health(b);
    if (h) {
      note(`${b.id} 已经在线（${b.url}），跳过启动`);
      continue;
    }
    start(b);
  }
  // 等它们起来
  await new Promise((r) => setTimeout(r, 1500));
}

render();
await tick();
render();

const timer = setInterval(async () => {
  await tick();
  render();
}, 5000);
timer.unref?.();

/* 优雅退出：先让每条桥正常关浏览器，cookie 才会落盘，登录态才不会丢 */
const shutdown = async () => {
  if (closing) return;
  closing = true;
  clearInterval(timer);
  process.stdout.write(CLEAR + '正在关闭浏览器（把登录态写回磁盘）…\n');
  if (keepBrowsers) {
    console.log('（--keep-browsers：浏览器留着，下次启动更快）');
  } else {
    const failed = [];
    await Promise.all(
      list.map(async (b) => {
        try {
          await fetch(`${String(b.url).replace(/\/+$/, '')}/close`, {
            method: 'POST',
            signal: AbortSignal.timeout(8000),
          });
        } catch {
          failed.push(b.id);
        }
      })
    );
    if (failed.length) {
      console.log(`  ${failed.length} 个桥没来得及回话，正在按端口兜底关闭…`);
    }
    // 兜底：还开着的直接按端口关（桥被 kill 掉之后就靠这一步）
    await new Promise((r) => setTimeout(r, 800));
    let left = 0;
    for (const [i2, b2] of list.entries()) {
      const port2 = 9222 + i2;
      const ok = await closeBrowserByPort(port2, { timeoutMs: 4000 }).catch(() => false);
      if (!ok) left++;
    }
    if (left) console.log(`  还有 ${left} 个浏览器没关掉，双击「停止并关闭浏览器.bat」再关一次`);
    else console.log('  浏览器已全部关闭');
  }
  for (const [, child] of children) {
    try {
      child.kill();
    } catch {
      /* ignore */
    }
  }
  console.log('已停止所有桥。');
  process.exit(0);
};
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
