/**
 * 桥的 UI 基础操作：选择器、鼠标、键盘、窗口可见性。
 * 从 doubao-bridge.mjs 里拆出来的 —— 这些只依赖 CDP 连接，不碰任务状态。
 */

export const UI = {
  input: '.tiptap.ProseMirror',
  send: '[data-testid="chat_input_send_button"]',
  skillBadge: '[data-testid="skill_input_exit_button"]',
  panel: '[data-creation-params-panel-id]',
  slider: '[role="slider"]',
  video: 'video',
  /** 视频预览弹层右上角那个 × */
  closePreview: '[data-testid="canvas_close_btn"]',
};

export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** 真点一下：先 hover 再按下/抬起（有些胶囊要 hover 才挂上弹层） */
export async function realClick(cdp, x, y) {
  await cdp.send('Input.dispatchMouseEvent', { type: 'mouseMoved', x, y, button: 'none', buttons: 0 });
  await sleep(120);
  for (const type of ['mousePressed', 'mouseReleased']) {
    await cdp.send('Input.dispatchMouseEvent', {
      type,
      x,
      y,
      button: 'left',
      clickCount: 1,
      buttons: type === 'mousePressed' ? 1 : 0,
    });
    await sleep(60);
  }
}

export async function pressKey(cdp, key, code, vk) {
  for (const type of ['keyDown', 'keyUp']) {
    await cdp.send('Input.dispatchKeyEvent', {
      type,
      key,
      code,
      windowsVirtualKeyCode: vk,
      nativeVirtualKeyCode: vk,
    });
    await sleep(40);
  }
}

/** 保证窗口在屏幕内且不是最小化 —— 豆包很多按钮在隐藏状态下点不动 */
export async function ensureVisible(cdp) {
  try {
    const w = await cdp.send('Browser.getWindowForTarget', {});
    const windowId = w?.windowId ?? w?.result?.windowId;
    if (!windowId) return false;
    const b = await cdp.send('Browser.getWindowBounds', { windowId });
    const cur = b?.bounds || b?.result?.bounds || {};
    if (cur.windowState === 'normal' && cur.left >= 0 && cur.top >= 0) return true;

    // 摆到屏幕右下角：就算真被看见，也在角落，不挡画布中间。
    // 只改位置、不改窗口状态 —— 挪位置不会把窗口激活到前台（实测验证）。
    let left = 40;
    let top = 40;
    try {
      const box = await cdp.evaluate('({ w: window.screen.availWidth || 1920, h: window.screen.availHeight || 1080 })');
      const sw = Number(box?.w) || 1920;
      const sh = Number(box?.h) || 1080;
      left = Math.max(0, sw - 1420);
      top = Math.max(0, sh - 920);
    } catch {
      /* 拿不到屏幕尺寸就用左上角 */
    }

    await cdp.send('Browser.setWindowBounds', {
      windowId,
      bounds: { windowState: 'normal', left, top, width: 1400, height: 900 },
    });
    await sleep(500);
    return true;
  } catch {
    return false;
  }
}

/** 窗口缩到任务栏 / 恢复（只改状态，不抢焦点） */
export async function setWindowState(cdp, kind) {
  try {
    const w = await cdp.send('Browser.getWindowForTarget', {});
    const windowId = w?.windowId ?? w?.result?.windowId;
    if (!windowId) return false;
    const bounds =
      kind === 'minimized'
        ? { windowState: 'minimized' }
        : { windowState: 'normal', left: 40, top: 40, width: 1400, height: 900 };
    await cdp.send('Browser.setWindowBounds', { windowId, bounds });
    return true;
  } catch {
    return false;
  }
}

/** 把窗口挪到屏幕外（用户完全看不到，但浏览器还在） */
export async function parkWindow(cdp, pos = { left: -3000, top: -3000, width: 1400, height: 900 }) {
  try {
    const w = await cdp.send('Browser.getWindowForTarget', {});
    const windowId = w?.windowId ?? w?.result?.windowId;
    if (!windowId) return false;
    await cdp.send('Browser.setWindowBounds', { windowId, bounds: { ...pos, windowState: 'normal' } });
    return true;
  } catch {
    return false;
  }
}
